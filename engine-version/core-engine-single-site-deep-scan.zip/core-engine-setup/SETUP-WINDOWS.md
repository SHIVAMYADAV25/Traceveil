# Core Engine — Windows setup

The `core-engine/` directory is copied from the supplied `core-engine.zip`. Its application source files are unchanged. The PowerShell files in this folder are setup/run helpers only.

## Requirements

- Windows 10/11
- Python 3.10 or newer (Python 3.12 recommended)
- Internet access to install Python packages

## 1. Extract and set up

Extract this ZIP. Open PowerShell in the extracted `core-engine-setup` folder and run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup-windows.ps1
```

## 2. Start the existing web UI

```powershell
.\run-ui.ps1
```

Open `http://127.0.0.1:8000` in your browser.

## 3. Run against one permitted website

```powershell
.\run-scan.ps1 -ImagePath "C:\path\to\reference.jpg" -Domains "example.com" -OutputPath "result.json"
```

Use a website you own or have permission to test. Omit `-Domains` to use the engine's configured domain dataset.

## Important scope note

This package does not change the engine's behavior. The existing crawler discovers candidate image URLs, and `engine/http.py` fetches accessible image responses as bytes in memory. The existing scanner then continues to image decoding and comparison. It does **not** save each downloaded candidate image as a separate file. HTTP 401/403/451 responses remain blocked; this package does not bypass access controls.

The helper scripts are intended for Windows PowerShell. The original README inside `core-engine/` contains the project's other run/test commands.
