$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot\core-engine
$Python = Join-Path $PWD '.venv\Scripts\python.exe'
if (-not (Test-Path $Python)) {
    Write-Error 'Environment not set up. Run .\setup-windows.ps1 first.'
}
& $Python cli.py serve --host 127.0.0.1 --port 8000
