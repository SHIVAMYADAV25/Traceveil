# core-engine

Reverse-image leak discovery, reduced to the core: **image in → matching pages, image URLs, video URLs, contacts out.**
Uses the same 91 monitored domains and the same contact datasets as the original project (`data/`).

```
image ─► fingerprint ─► crawl 91 sites ─► fingerprint every candidate ─► tiered match
                                                         │
        removal-request draft ◄─ contacts ◄─ verify on page + video URLs ◄─┘
```

## Run

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python cli.py serve                       # UI at http://127.0.0.1:8000
python cli.py scan photo.jpg --out result.json            # all 91 sites
python cli.py scan photo.jpg --domains example.com,other.net   # specific sites
```
Python 3.10+ (tested on 3.12). First scan of all 91 sites typically takes a few minutes; progress is live.

## Why the search finds more than before

| Weakness of a one-shot crawl | What this engine does |
|---|---|
| Only homepage links, ~15 pages | Pulls candidates from **sitemaps (image + video sitemaps incl.)**, **WordPress REST API**, **RSS/Atom**, then a **score-prioritised BFS** that follows pagination and categories |
| Thumbnail found, page unknown | Thumbnails wrapped in `<a>` keep their **content-page URL + title** |
| Misses lazy-loaded images | `data-src`/`data-original`/…, `srcset`, `<picture>`, `<noscript>`, CSS backgrounds, `og:image`, JSON-LD |
| Fixed budget everywhere | **Adaptive 2nd pass**: matched sites get a big extra budget, the matched page is crawled first (related videos), and sister sites on the same network / video CDN are searched deeper |
| One hash vs one image | Hashes compared across **variants of both sides**: mirror, centre crops, 3×3 sub-windows at 2 scales, letterbox-trimmed |
| Hashes fail on heavy edits | **RootSIFT + Lowe ratio + mutual-best + RANSAC**, spread check (a shared watermark/logo can't cause a match), small thumbnails are upscaled |
| "Not found" vs "couldn't check" | Per-site coverage: checked / no_images / blocked / unreachable / skipped |
| Match = a thumbnail only | **Refine**: opens the matched page, extracts **direct / stream / embed video URLs**, re-tests the page's own main image → `verified_on_page` |

Contacts per matched domain: your datasets → live scrape (`/contact`, `/dmca`, `/abuse`, mailto links) → registrar abuse (RDAP) → hosting abuse (RDAP of the site's IP). Every address is labelled with its source. A ready removal request (text + `mailto:`) is generated per domain.

## Result shape (`GET /api/scan/{id}` → `result`)
`matches[]`: `domain, page_url, image_url, alt_image_urls, videos[{url,kind}], title, match_type (exact|near_duplicate|structural|probable), confidence, category (strong|possible), verified_on_page, found_via, contact{network, emails[{email,source}], removal_pages[]}` ·
`notices[]` · `related_domains[]` · `coverage{summary, domains{…}}` · `stats`.

## Tests (all included, all passing)
```bash
python tests/test_e2e.py       # 25 checks: 7 fake sites with different layouts, hidden edited copies, blocked/dead/clean sites
python tests/test_server.py    # API: validation, background job, polling, result
python tests/eval_matcher.py   # matcher: 26 edits x 9 targets -> 98.3% recall, 0/218 false positives
```
The tests use local fake sites because real ones can't be fetched from a build sandbox. **Real-site behaviour is the part you must verify yourself.**

## Tuning (env vars, prefix `CE_`)
`PAGES_PER_DOMAIN` (40) · `BONUS_PAGES` (80) · `MAX_CANDIDATES` (25000) · `SCAN_TIMEOUT` (900 s) · `GLOBAL_CONCURRENCY` (32) · `PER_HOST_CONCURRENCY` (6) · `LIVE_CONTACT_LOOKUP` · `RDAP_LOOKUP` · `CPU_WORKERS`.
Raise `PAGES_PER_DOMAIN` for more coverage (slower); lower `SCAN_TIMEOUT` for quicker, shallower scans.

## Known limits
* Sites that render everything with JavaScript expose no images to a plain HTTP crawler (sitemaps/RSS/API help when present). A headless browser could be added as an optional fetcher.
* Bot protection (Cloudflare challenges, 403/429) is detected and reported as `blocked`; it is not bypassed. ISP-level blocking of these domains (common in some countries) shows as `blocked`/`unreachable`: run from a network that can reach them.
* Matching uses thumbnails/posters/main images, not video frames. Video URLs are reported but the video itself is not downloaded or frame-matched.
* RDAP lookups and live contact scraping depend on third-party servers; they are best-effort.
* Scans are held in memory (last 30 kept); restart clears them.
* `SSRF guard` is on by default (public IPs only). `CE_ALLOW_PRIVATE=1` disables it and exists for the local test sites only.


## Deep inspection of exactly one website

The `single` command is an isolated inspection mode. It does **not** use the 91-site
intelligence list, does not search related domains, and does not follow external HTML
links. It accepts one website URL and crawls that exact host only. Images hosted on
external CDNs but embedded in pages on the target site can be downloaded as image
assets; those CDN hosts are never crawled as websites.

From the `core-engine` directory:

```powershell
python cli.py single .\path\to\reference.jpg https://example.com/ `
  --max-pages 500 `
  --max-images 15000 `
  --assets-per-page 250 `
  --sitemap-limit 40
```

If you omit `--outdir`, results are written to a timestamped folder under
`inspection-results/`.

The deep mode increases discovery budgets compared with the normal multi-site scan:
up to 500 HTML pages, 40 sitemap documents, 15,000 unique image URLs and 250 image
candidates per page by default. You can raise or lower these limits. The scan remains
bounded; it does not mean every URL on a site is guaranteed to be discoverable.

Output files:
- `scan-summary.json`: counts, limits and crawl statistics.
- `crawl-log.jsonl`: timestamped per-step event stream, including full page and image URLs.
- `pages.jsonl`: each visited page.
- `discovered-images.jsonl`: every unique discovered image URL, download outcome, saved file,
  pHash/dHash/aHash, hash distances and match decision.
- `matches.jsonl`: matched image records only.
- `images/`: downloaded usable candidate images.
- `reference-fingerprints.json`: reference hashes and generated variants.

The engine's existing pHash/dHash/aHash, crop/window and geometric SIFT/RANSAC matcher
is reused without changing its matching thresholds. Hash distances are Hamming distances;
lower values indicate more similar fingerprints. A missing match record does not mean
an image was not examined: check `discovered-images.jsonl` for every candidate and its
reason/status.

The crawler stays on the exact host from the supplied URL. It follows the existing
same-site link and sitemap discovery logic and uses the existing SSRF/network size
guards. It does not bypass login walls, CAPTCHAs, paywalls or access controls. Respect
the target site's robots.txt, terms and applicable law; the engine's current robots.txt
support is used for sitemap discovery, not a full Allow/Disallow policy evaluator.
