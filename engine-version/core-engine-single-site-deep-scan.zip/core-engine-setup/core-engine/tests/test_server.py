"""API test: upload -> background scan -> poll -> result.  Run with CE_ALLOW_PRIVATE=1 (local fake sites)."""
import io, os, sys, time
os.environ["CE_ALLOW_PRIVATE"] = "1"; os.environ["CE_RDAP_LOOKUP"] = "0"
sys.path.insert(0, ".")
from fastapi.testclient import TestClient
from PIL import Image
from tests.fakesites import build, TARGET_PATH
import server

target = Image.open(TARGET_PATH).convert("RGB")
sites = build(target)
try:
    with TestClient(server.app) as c:
        h = c.get("/api/health").json()
        assert h["domains"] == 91, h
        assert "core-engine" in c.get("/").text
        print("PASS health: dataset has", h["domains"], "domains; UI served")

        r = c.post("/api/scan", files={"file": ("x.txt", b"not an image", "text/plain")})
        assert r.status_code == 400, r.text
        print("PASS bad upload rejected:", r.json()["detail"][:50])
        tiny = io.BytesIO(); Image.new("RGB", (10, 10)).save(tiny, "PNG")
        assert c.post("/api/scan", files={"file": ("t.png", tiny.getvalue(), "image/png")}).status_code == 400
        print("PASS tiny image rejected")

        doms = ",".join(sites[n].domain for n in ("paginated", "sitemap", "clean", "blocked"))
        r = c.post("/api/scan", files={"file": ("t.jpg", open(TARGET_PATH, "rb").read(), "image/jpeg")}, data={"domains": doms})
        assert r.status_code == 202, r.text
        sid = r.json()["scan_id"]
        seen_progress = False
        for _ in range(120):
            j = c.get(f"/api/scan/{sid}").json()
            seen_progress |= bool(j["progress"].get("phase") and j["progress"]["phase"] != "starting")
            if j["status"] != "running":
                break
            time.sleep(1)
        assert j["status"] == "completed", j
        res = j["result"]
        found = {m["domain"] for m in res["matches"]}
        assert found == {sites["paginated"].domain, sites["sitemap"].domain}, found
        assert "task" not in j and "cancel" not in j
        print("PASS scan via API:", len(res["matches"]), "matches, progress reported:", seen_progress)
        assert c.get("/api/scan/nope").status_code == 404
        print("ALL PASSED")
finally:
    for s in sites.values(): s.stop()
