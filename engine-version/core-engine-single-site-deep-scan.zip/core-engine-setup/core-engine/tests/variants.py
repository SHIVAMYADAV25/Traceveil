"""Synthetic edits of a target image + distractor images, used to measure match quality."""
from __future__ import annotations

import io
import random

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps


def jpeg(img: Image.Image, q: int = 85) -> bytes:
    b = io.BytesIO()
    img.convert("RGB").save(b, "JPEG", quality=q)
    return b.getvalue()


def thumb(img: Image.Image, w: int) -> Image.Image:
    return img.resize((w, max(1, int(img.height * w / img.width))), Image.LANCZOS)


def watermark(img: Image.Image, text="SITE.COM") -> Image.Image:
    im = img.convert("RGBA")
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    fs = max(14, im.width // 10)
    try:
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", fs)
    except Exception:
        font = ImageFont.load_default()
    d.text((im.width * 0.55, im.height * 0.85), text, fill=(255, 255, 255, 200), font=font)
    d.rectangle((6, 6, 6 + im.width // 6, 6 + im.height // 12), fill=(255, 0, 0, 180))
    return Image.alpha_composite(im, layer).convert("RGB")


def letterbox(img: Image.Image) -> Image.Image:
    bar = img.height // 6
    out = Image.new("RGB", (img.width, img.height + 2 * bar), (0, 0, 0))
    out.paste(img, (0, bar))
    return out


def edits(target: Image.Image) -> dict[str, bytes]:
    """name -> jpeg bytes of a thumbnail-sized, edited copy of `target`."""
    w, h = target.size
    out: dict[str, bytes] = {}
    out["resize_320"] = jpeg(thumb(target, 320), 80)
    out["resize_160"] = jpeg(thumb(target, 160), 75)
    out["jpeg_q30"] = jpeg(thumb(target, 480), 30)
    out["brightness"] = jpeg(thumb(ImageEnhance.Contrast(ImageEnhance.Brightness(target).enhance(0.6)).enhance(1.3), 320), 80)
    out["blur"] = jpeg(thumb(target.filter(ImageFilter.GaussianBlur(2.0)), 320), 80)
    out["mirror"] = jpeg(thumb(ImageOps.mirror(target), 320), 80)
    out["watermark"] = jpeg(thumb(watermark(target), 320), 80)
    out["letterbox"] = jpeg(thumb(letterbox(target), 320), 80)
    out["crop_70"] = jpeg(thumb(target.crop((int(w * .15), int(h * .15), int(w * .85), int(h * .85))), 320), 80)
    out["crop_corner_50"] = jpeg(thumb(target.crop((int(w * .45), int(h * .1), w, int(h * .7))), 320), 80)
    out["zoom_40"] = jpeg(thumb(target.crop((int(w * .3), int(h * .3), int(w * .7), int(h * .7))), 320), 80)
    out["rotate_8"] = jpeg(thumb(target.rotate(8, expand=False, fillcolor=(0, 0, 0)), 320), 80)
    out["stretch_1x1"] = jpeg(target.resize((320, 320), Image.LANCZOS), 80)
    out["grayscale"] = jpeg(thumb(ImageOps.grayscale(target).convert("RGB"), 320), 80)
    out["combo_mirror_crop_wm"] = jpeg(thumb(watermark(ImageOps.mirror(target.crop((int(w * .1), int(h * .1), int(w * .9), int(h * .9))))), 260), 55)
    return out


def distractors(n: int = 14) -> dict[str, Image.Image]:
    """Unrelated photos. Bundled with scikit-image, so no download is needed."""
    from skimage import data
    names = ["astronaut", "coffee", "chelsea", "rocket", "camera", "page", "brick", "gravel", "grass",
             "hubble_deep_field", "immunohistochemistry", "moon", "horse"]
    out = {}
    for name in names:
        try:
            arr = getattr(data, name)()
        except Exception:
            continue
        if arr.dtype == bool:
            arr = (arr * 255).astype(np.uint8)
        im = Image.fromarray(arr)
        if im.mode not in ("RGB",):
            im = im.convert("RGB")
        out[name] = im
        if len(out) >= n:
            break
    return out


def hard_edits(target: Image.Image, others: list[Image.Image]) -> dict[str, bytes]:
    """Harder, realistic edits seen on leak/tube sites."""
    w, h = target.size
    o = others
    out: dict[str, bytes] = {}
    out["tiny_96"] = jpeg(thumb(target, 96), 60)
    out["tiny_120_mirror"] = jpeg(thumb(ImageOps.mirror(target), 120), 60)
    out["lowq_200"] = jpeg(thumb(target, 200), 18)
    out["crop_30_corner"] = jpeg(thumb(target.crop((int(w * .62), int(h * .48), int(w * .92), int(h * .78))), 300), 80)
    out["rotate_25"] = jpeg(thumb(target.rotate(25, expand=True, fillcolor=(20, 20, 20)), 360), 80)
    # 2x2 preview grid: target in one quadrant, unrelated images elsewhere
    grid = Image.new("RGB", (640, 360))
    cells = [thumb(target, 320).resize((320, 180)), thumb(o[0], 320).resize((320, 180)), thumb(o[1], 320).resize((320, 180)), thumb(o[2], 320).resize((320, 180))]
    for i, c in enumerate(cells):
        grid.paste(c, ((i % 2) * 320, (i // 2) * 180))
    out["collage_2x2"] = jpeg(grid, 80)
    # picture-in-picture: target as 45% inset over unrelated background
    bg = thumb(o[3], 480).resize((480, 270))
    inset = thumb(target, 216)
    bg.paste(inset, (240, 130))
    out["picture_in_picture"] = jpeg(bg, 80)
    # coloured frame + caption bar
    framed = Image.new("RGB", (int(w * 1.24), int(h * 1.30)), (200, 30, 90))
    framed.paste(target, (int(w * .12), int(h * .06)))
    d = ImageDraw.Draw(framed)
    d.rectangle((0, int(h * 1.16), framed.width, framed.height), fill=(0, 0, 0))
    out["framed_caption"] = jpeg(thumb(framed, 320), 70)
    # sepia-ish colour grade
    arr = np.asarray(thumb(target, 320), dtype=np.float32)
    mix = np.stack([arr @ [.393, .769, .189], arr @ [.349, .686, .168], arr @ [.272, .534, .131]], axis=-1)
    out["sepia"] = jpeg(Image.fromarray(np.clip(mix, 0, 255).astype(np.uint8)), 80)
    # big caption overlay over lower third
    cap = thumb(target, 320).copy()
    d = ImageDraw.Draw(cap)
    d.rectangle((0, int(cap.height * .62), cap.width, int(cap.height * .92)), fill=(10, 10, 10))
    d.text((12, int(cap.height * .70)), "WATCH FULL VIDEO ON SITE.COM >>>", fill=(255, 255, 0))
    out["caption_overlay"] = jpeg(cap, 75)
    out["stretch_crop_mirror"] = jpeg(ImageOps.mirror(target.crop((int(w * .1), 0, int(w * .8), h))).resize((300, 300)), 70)
    return out
