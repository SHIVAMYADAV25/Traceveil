"""Matcher benchmark: recall over 26 kinds of edit x 9 different target images, plus false positives.
Run:  python tests/eval_matcher.py"""
import collections, io, sys, time
sys.path.insert(0, ".")
from PIL import Image
import engine.fingerprint as fp
from tests.variants import edits, hard_edits, distractors, jpeg, thumb, watermark
from tests.fakesites import TARGET_PATH

dis = distractors()
targets = {n: dis[n] for n in ["astronaut", "coffee", "chelsea", "rocket", "camera", "hubble_deep_field", "moon", "immunohistochemistry"] if n in dis}
targets["demo"] = Image.open(TARGET_PATH).convert("RGB")
enc = lambda im: jpeg(im, 95)
hit, total, miss = collections.Counter(), collections.Counter(), collections.defaultdict(list)
fps, nneg, t0 = [], 0, time.time()
for tname, timg in targets.items():
    if max(timg.size) < 300:
        timg = timg.resize((timg.width * 2, timg.height * 2), Image.LANCZOS)
    ref = fp.build_reference(enc(timg))
    others = [v for k, v in dis.items() if k != tname]
    pos = edits(timg); pos.update(hard_edits(timg, others[:4]))
    for name, b in pos.items():
        total[name] += 1
        ok = fp.compare(ref, fp.open_image(b)) is not None
        hit[name] += ok
        if not ok: miss[name].append(tname)
    for k, v in dis.items():
        if k == tname: continue
        for b in (jpeg(thumb(v, 320), 80), jpeg(thumb(watermark(v), 320), 80)):
            nneg += 1
            if fp.compare(ref, fp.open_image(b)) is not None: fps.append(f"{tname}<-{k}")
for e in total:
    print(f"{e:24s} {hit[e]}/{total[e]}  {'misses: ' + ','.join(miss[e]) if miss[e] else ''}")
h, t = sum(hit.values()), sum(total.values())
print(f"\nRECALL {h}/{t} = {h/t:.1%}    FALSE POSITIVES {len(fps)}/{nneg} {fps}    ({time.time()-t0:.0f}s)")
