"""Builds a ready-to-send removal request (plain text + mailto link) for one domain."""
from __future__ import annotations

from urllib.parse import quote


def build_notice(domain: str, matches: list[dict], contact: dict) -> dict:
    urls = []
    for m in matches:
        for u in (m.get("page_url"), m.get("image_url")):
            if u and u not in urls:
                urls.append(u)
        for v in (m.get("videos") or [])[:2]:
            if v["url"] not in urls:
                urls.append(v["url"])
    subject = f"Urgent removal request: non-consensual intimate content on {domain}"
    body = (
        f"To the {domain} abuse / legal team,\n\n"
        "I am writing to request the immediate removal of content hosted on your service that was published "
        "without my consent and contains private/intimate imagery of me.\n\n"
        "Content to remove:\n" + "\n".join(f"  - {u}" for u in urls[:25]) + "\n\n"
        "I did not authorise the publication or distribution of this material. Please remove it, disable access "
        "to copies and mirrors, and confirm in writing once done. I reserve all legal rights, including under "
        "applicable laws on non-consensual intimate imagery and copyright.\n\n"
        "Name: [YOUR NAME OR CASE REFERENCE]\nContact: [YOUR SAFE CONTACT]\n"
    )
    emails = [e["email"] for e in (contact or {}).get("emails", [])]
    to = emails[0] if emails else ""
    mailto = f"mailto:{to}?subject={quote(subject)}&body={quote(body[:1800])}" if to else ""
    return {"domain": domain, "to": to, "cc": emails[1:3], "subject": subject, "body": body, "mailto": mailto,
            "removal_pages": [p["url"] for p in (contact or {}).get("removal_pages", [])]}
