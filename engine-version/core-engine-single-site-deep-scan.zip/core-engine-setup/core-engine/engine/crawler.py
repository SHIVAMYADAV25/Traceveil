"""
Per-domain crawler.  Goal: surface as many *distinct candidate images* (with the page and
video URL they belong to) as possible, cheaply.  Sources, best first:

  1. Sitemaps (+ robots.txt)   image / video sitemaps hand us thumbnails + video URLs directly,
                               and plain sitemaps give real content pages (newest first)
  2. WordPress REST API        one request returns 30 posts with featured images
  3. RSS / Atom feeds          latest items with thumbnails
  4. The homepage + a prioritised breadth-first crawl
                               links are scored (content slugs, pagination, categories), the best
                               are fetched first, pagination is followed, and the crawl can be
                               *resumed* with more budget (used for domains that already matched).
"""
from __future__ import annotations

import asyncio
import heapq
import itertools
import json
import re
from dataclasses import dataclass, field
from typing import AsyncIterator, Optional
from urllib.parse import urlparse

from . import config
from .extract import (Asset, Parsed, VideoRef, decode_xml, next_links, parse_feed, parse_html, parse_sitemap,
                      parse_wp_posts, same_site, score_link)
from .http import Fetched, Http

DEFAULT_SITEMAPS = ("/sitemap.xml", "/sitemap_index.xml", "/wp-sitemap.xml", "/video-sitemap.xml",
                    "/sitemap-video.xml", "/sitemap-images.xml", "/sitemap_video.xml")
DEFAULT_FEEDS = ("/feed/", "/feed", "/rss", "/rss.xml", "/atom.xml")


@dataclass
class Batch:
    domain: str
    source: str                      # home | page | sitemap | wp | rss
    page_url: str
    assets: list
    videos: list = field(default_factory=list)
    title: Optional[str] = None


class DomainCrawler:
    def __init__(self, domain: str, http: Http, start_url: Optional[str] = None):
        self.domain = domain
        self.start_url = start_url
        self.http = http
        self.base: Optional[str] = None
        self.host = ""
        self.home: Optional[Parsed] = None
        self.home_url: Optional[str] = None
        self.visited: set[str] = set()
        self.heap: list = []
        self.counter = itertools.count()
        self.started = False
        self.structured_done = False
        self.pages_fetched = 0
        self.stats = {"ok": 0, "blocked": 0, "failed": 0}
        self.sources = {"sitemap": 0, "wp": 0, "rss": 0, "page": 0}
        self.last_reason = ""
        self.sitemap_pages: list[tuple[str, str]] = []

    # ── bookkeeping ────────────────────────────────────────────────────────
    def _note(self, f: Fetched) -> None:
        if f.ok:
            self.stats["ok"] += 1
        elif f.status == "blocked":
            self.stats["blocked"] += 1
            self.last_reason = f.reason
        else:
            self.stats["failed"] += 1
            self.last_reason = f.reason

    def enqueue(self, url: str, score: int) -> None:
        if score < 0:
            return
        key = url.split("#", 1)[0]
        if key in self.visited:
            return
        heapq.heappush(self.heap, (-score, next(self.counter), key))

    def _queue_links(self, parsed: Parsed, page_url: str) -> None:
        nxt = set(next_links(parsed.links, page_url))
        for url, text in parsed.links:
            if not same_site(url, self.base or page_url):
                continue
            self.enqueue(url, score_link(url, text) + (3 if url in nxt else 0))

    # ── start: find a working origin ───────────────────────────────────────
    async def start(self) -> bool:
        self.started = True
        d = self.domain.strip().lower()
        local = d.startswith(("127.", "localhost")) or ":" in d
        if self.start_url:
            candidates = [self.start_url]
        else:
            candidates = [f"http://{d}/"] if local else [f"https://{d}/", f"http://{d}/", f"https://www.{d}/"]
        for url in candidates:
            f = await self.http.page(url)
            self._note(f)
            if f.ok:
                self.base = f.url if same_site(f.url, url) else url       # stay on the original site
                self.base = f"{urlparse(self.base).scheme}://{urlparse(self.base).netloc}/"
                self.host = urlparse(self.base).netloc
                self.visited.add(self.base.rstrip("/"))
                self.visited.add(self.base)
                self.home_url = f.url or self.base
                self.home = parse_html(f.text(), self.home_url)
                self._queue_links(self.home, f.url or self.base)
                return True
            if f.status == "blocked" and not local:
                break                                                       # a block rarely clears on another scheme
        return False

    # ── structured sources ─────────────────────────────────────────────────
    async def _sitemap_batches(self) -> list[Batch]:
        out: list[Batch] = []
        assert self.base
        robots = await self.http.get(self.base + "robots.txt", max_bytes=200_000)
        urls = [m.group(1).strip() for m in re.finditer(r"(?im)^sitemap:\s*(\S+)", robots.text())] if robots.ok else []
        queue = urls + [self.base.rstrip("/") + p for p in DEFAULT_SITEMAPS]
        seen, fetched, taken = set(), 0, 0
        while queue and fetched < config.SITEMAP_FILES and taken < config.STRUCTURED_ASSETS:
            url = queue.pop(0)
            if url in seen or not same_site(url, self.base):
                continue
            seen.add(url)
            f = await self.http.xml(url)
            fetched += 1 if f.ok else 0
            if not f.ok:
                continue
            children, entries = parse_sitemap(decode_xml(f.content or b""), self.base)
            if children:
                # newest / most relevant child sitemaps first
                hint = lambda c: (any(k in c[0].lower() for k in ("video", "post", "image", "media", "page")), c[1])
                queue = [c[0] for c in sorted(children, key=hint, reverse=True)] + queue
            entries.sort(key=lambda e: e.lastmod, reverse=True)
            assets: list[Asset] = []
            for e in entries:
                if e.images:
                    for img in e.images[:2]:
                        assets.append(Asset(img, page_url=e.loc, title=e.title, source="sitemap", videos=list(e.videos)))
                else:
                    self.sitemap_pages.append((e.loc, e.lastmod))
            if assets:
                taken += len(assets)
                self.sources["sitemap"] += len(assets)
                out.append(Batch(self.domain, "sitemap", url, assets[: config.STRUCTURED_ASSETS], []))
        # plain content pages from sitemaps go to the crawl queue, newest first
        for rank, (loc, _) in enumerate(self.sitemap_pages[: config.PAGES_PER_DOMAIN * 3]):
            self.enqueue(loc, 6 - min(rank // 10, 4))
        return out

    async def _wp_batches(self) -> list[Batch]:
        out: list[Batch] = []
        assert self.base
        for page in (1, 2, 3):
            f = await self.http.get(f"{self.base}wp-json/wp/v2/posts?per_page=30&page={page}&_embed=wp:featuredmedia",
                                    max_bytes=config.MAX_XML_BYTES, accept="application/json")
            if not f.ok or not f.text().lstrip().startswith("["):
                break
            try:
                data = json.loads(f.text())
            except ValueError:
                break
            assets = parse_wp_posts(data, self.base)
            if not assets:
                break
            self.sources["wp"] += len(assets)
            out.append(Batch(self.domain, "wp", f.url, assets))
            if len(data) < 30:
                break
        return out

    async def _rss_batches(self) -> list[Batch]:
        assert self.base
        urls = list(self.home.feeds) if self.home else []
        urls += [self.base.rstrip("/") + p for p in DEFAULT_FEEDS]
        tried = 0
        for url in dict.fromkeys(urls):
            if tried >= 3:
                break
            tried += 1
            f = await self.http.xml(url)
            if not f.ok:
                continue
            text = decode_xml(f.content or b"")
            if "<item" not in text and "<entry" not in text:
                continue
            assets = parse_feed(text, self.base)
            if assets:
                self.sources["rss"] += len(assets)
                return [Batch(self.domain, "rss", url, assets)]
        return []

    # ── main loop ──────────────────────────────────────────────────────────
    async def batches(self, page_budget: int) -> AsyncIterator[Batch]:
        if not self.started and not await self.start():
            return
        assert self.base and self.home is not None
        if not self.structured_done:
            self.structured_done = True
            yield Batch(self.domain, "home", self.home_url or self.base, self.home.assets, self.home.videos, self.home.title)
            results = await asyncio.gather(self._sitemap_batches(), self._wp_batches(), self._rss_batches(), return_exceptions=True)
            for res in results:
                if isinstance(res, list):
                    for batch in res:
                        yield batch
        fetched_here = 0
        while self.heap and fetched_here < page_budget:
            group = []
            while self.heap and len(group) < 4 and fetched_here + len(group) < page_budget:
                _, _, url = heapq.heappop(self.heap)
                if url in self.visited:
                    continue
                self.visited.add(url)
                group.append(url)
            if not group:
                continue
            pages = await asyncio.gather(*[self.http.page(u) for u in group], return_exceptions=True)
            for url, f in zip(group, pages):
                fetched_here += 1
                self.pages_fetched += 1
                if isinstance(f, Exception) or not isinstance(f, Fetched):
                    self.stats["failed"] += 1
                    continue
                self._note(f)
                if not f.ok:
                    continue
                parsed = parse_html(f.text(), url)
                self.sources["page"] += 1
                self._queue_links(parsed, url)
                yield Batch(self.domain, "page", url, parsed.assets, parsed.videos, parsed.title)
