"""
Contact + infrastructure lookup for a matched domain.

Sources, best first (every address is labelled with where it came from):
  1. your two datasets (intelligence.csv + takedown.csv)         source = dataset
  2. live scrape of the site: /, /contact, /dmca, /abuse ...      source = site
  3. registrar abuse contact via RDAP                             source = registrar
  4. hosting-provider abuse contact via RDAP (IP of the site)     source = host
"""
from __future__ import annotations

import asyncio
import csv
import json
import re
import socket
from typing import Optional
from urllib.parse import urljoin, urlparse

from . import config
from .extract import norm_host, parse_html, same_site
from .http import Http

EMAIL_RE = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+")
BAD_EMAIL = ("sentry", "example.", "noreply", "no-reply", "wixpress", "schema.org", "@2x", "@3x", "u003e", ".png", ".jpg",
             ".webp", ".gif", "domain.com", "yourdomain", "email.com", "test@", "beacon", "lazyload")
REMOVAL_WORDS = ("dmca", "removal", "remove", "takedown", "take-down", "report", "abuse", "copyright", "complaint", "legal", "ncii", "content-removal")
PROBE_PATHS = ("/", "/contact", "/contact-us", "/dmca", "/abuse", "/report", "/terms", "/privacy-policy")
CC_SLD = {"co", "com", "org", "net", "gov", "ac", "edu"}
IGNORED_PROVIDERS = {"", "unknown", "direct_cdn", "beacon.min.js", "."}


def norm_domain(domain: str) -> str:
    d = (domain or "").strip().lower()
    d = re.sub(r"^https?://", "", d).split("/")[0]
    return norm_host(d)


def registrable(domain: str) -> str:
    parts = norm_domain(domain).split(":")[0].split(".")
    if len(parts) >= 3 and parts[-2] in CC_SLD and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else ".".join(parts)


def _read(path) -> list[dict]:
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            return [{k: (v or "").strip() for k, v in row.items()} for row in csv.DictReader(fh)]
    except OSError:
        return []


def load_rows() -> list[dict]:
    """The scan targets: the intelligence dataset (91 domains)."""
    seen, rows = set(), []
    for row in _read(config.INTEL_CSV):
        d = norm_domain(row.get("domain", ""))
        if d and d not in seen:
            seen.add(d)
            row["domain"] = d
            rows.append(row)
    return rows


def rdap_abuse(data: dict) -> list[str]:
    out: list[str] = []

    def walk(entity: dict, depth: int = 0) -> None:
        if depth > 6 or not isinstance(entity, dict):
            return
        if "abuse" in (entity.get("roles") or []):
            card = entity.get("vcardArray") or [None, []]
            for item in (card[1] if len(card) > 1 else []):
                if isinstance(item, list) and item and item[0] == "email" and len(item) > 3:
                    out.append(str(item[3]).strip())
        for sub in entity.get("entities") or []:
            walk(sub, depth + 1)

    for ent in (data or {}).get("entities") or []:
        walk(ent)
    return list(dict.fromkeys(e for e in out if "@" in e))


class Contacts:
    def __init__(self) -> None:
        self.intel = {norm_domain(r.get("domain", "")): r for r in _read(config.INTEL_CSV)}
        self.takedown = {norm_domain(r.get("domain", "")): r for r in _read(config.TAKEDOWN_CSV)}
        self._cache: dict[str, dict] = {}

    # ── dataset ────────────────────────────────────────────────────────────
    def static(self, domain: str) -> dict:
        d = norm_domain(domain)
        intel, td = self.intel.get(d, {}), self.takedown.get(d, {})
        emails, pages = [], []
        for value in (td.get("contact_email"), intel.get("email")):
            if value and "@" in value and value not in [e["email"] for e in emails]:
                emails.append({"email": value, "source": "dataset"})
        if td.get("removal_page_url"):
            pages.append({"url": td["removal_page_url"], "type": td.get("removal_type") or "unknown", "source": "dataset"})
        quality = int(td["data_quality"]) if td.get("data_quality", "").isdigit() else 0
        return {
            "domain": d,
            "network": intel.get("network") or None,
            "provider_type": intel.get("provider_type") or td.get("provider_type") or None,
            "video_provider": intel.get("video_provider") or td.get("cdn_provider") or None,
            "emails": emails, "removal_pages": pages, "data_quality": quality,
        }

    # ── live ───────────────────────────────────────────────────────────────
    async def _scrape(self, http: Http, base: str) -> tuple[list[dict], list[dict]]:
        emails: list[dict] = []
        pages: list[dict] = []
        host = norm_host(urlparse(base).netloc)
        fetched = await asyncio.gather(*[http.page(urljoin(base, p)) for p in PROBE_PATHS], return_exceptions=True)
        for path, f in zip(PROBE_PATHS, fetched):
            if isinstance(f, Exception) or not getattr(f, "ok", False):
                continue
            text = f.text()
            if path != "/" and any(w in path for w in REMOVAL_WORDS):
                pages.append({"url": urljoin(base, path), "type": "page", "source": "site"})
            found = set(EMAIL_RE.findall(text))
            for m in re.findall(r"mailto:([^\"'?>\s]+)", text, re.I):
                found.add(m)
            for e in found:
                e = e.strip().strip(".,;").lower()
                if any(b in e for b in BAD_EMAIL) or e.count("@") != 1:
                    continue
                local, _, dom = e.partition("@")
                rank = 1 if any(w in path or w in local for w in ("dmca", "abuse", "legal", "copyright", "report", "removal")) else (2 if norm_host(dom) == host or host.endswith(norm_host(dom)) else 3)
                emails.append({"email": e, "source": "site", "page": urljoin(base, path), "_rank": rank})
            if path == "/":
                for url, label in parse_html(text, base).links:
                    if same_site(url, base) and any(w in (url + " " + label).lower() for w in REMOVAL_WORDS):
                        pages.append({"url": url, "type": "link", "source": "site"})
        emails.sort(key=lambda e: e["_rank"])
        seen, uniq = set(), []
        for e in emails:
            if e["email"] not in seen:
                seen.add(e["email"])
                e.pop("_rank", None)
                uniq.append(e)
        return uniq[:5], list({p["url"]: p for p in pages}.values())[:5]

    async def _rdap(self, http: Http, domain: str) -> list[dict]:
        out: list[dict] = []
        reg = registrable(domain)
        f = await http.get(f"https://rdap.org/domain/{reg}", max_bytes=800_000, accept="application/rdap+json,application/json")
        if f.ok:
            try:
                out += [{"email": e, "source": "registrar"} for e in rdap_abuse(json.loads(f.text()))]
            except ValueError:
                pass
        try:
            infos = await asyncio.get_running_loop().getaddrinfo(norm_domain(domain).split(":")[0], None, type=socket.SOCK_STREAM)
            ip = infos[0][4][0] if infos else None
        except OSError:
            ip = None
        if ip:
            f = await http.get(f"https://rdap.org/ip/{ip}", max_bytes=800_000, accept="application/rdap+json,application/json")
            if f.ok:
                try:
                    out += [{"email": e, "source": "host"} for e in rdap_abuse(json.loads(f.text()))]
                except ValueError:
                    pass
        return out

    async def lookup(self, domain: str, http: Optional[Http], base_url: Optional[str] = None) -> dict:
        d = norm_domain(domain)
        if d in self._cache:
            return self._cache[d]
        info = self.static(d)
        notes: list[str] = []
        if http is not None and config.LIVE_CONTACT_LOOKUP and not info["emails"]:
            try:
                base = base_url or (f"http://{d}/" if ":" in d else f"https://{d}/")
                emails, pages = await self._scrape(http, base)
                info["emails"] += emails
                known = {p["url"] for p in info["removal_pages"]}
                info["removal_pages"] += [p for p in pages if p["url"] not in known]
            except Exception:
                notes.append("live site lookup failed")
        if http is not None and config.RDAP_LOOKUP and ":" not in d:
            try:
                have = {e["email"] for e in info["emails"]}
                info["emails"] += [e for e in await self._rdap(http, d) if e["email"] not in have]
            except Exception:
                notes.append("registrar/host lookup failed")
        if not info["emails"] and not info["removal_pages"]:
            notes.append("no contact found: report through the host / CDN abuse form or a national cybercrime portal")
        info["notes"] = notes
        self._cache[d] = info
        return info
