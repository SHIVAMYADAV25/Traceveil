"""
Single-target deep inspection mode.

Crawls only the exact host supplied by the user. It reuses the project's existing
HTML/sitemap/WordPress/RSS extraction and pHash/dHash/aHash + geometric matcher.
Every successfully downloaded image is stored with its fingerprints and decision.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlunsplit

from . import config
from .crawler import DomainCrawler
from .extract import Asset
from .fingerprint import build_reference, compare, hashes, open_image
from .http import Http


def normalize_target(raw: str) -> tuple[str, str]:
    raw = (raw or "").strip()
    if not raw:
        raise ValueError("Enter a website URL, for example https://example.com/")
    if "://" not in raw:
        raw = "https://" + raw
    p = urlsplit(raw)
    if p.scheme.lower() not in ("http", "https") or not p.hostname:
        raise ValueError("Only valid http:// or https:// website URLs are supported.")
    if p.username or p.password:
        raise ValueError("Credentials in website URLs are not supported.")
    if p.port and p.port not in (80, 443, 8080, 8443):
        raise ValueError("This engine only allows standard web ports.")
    host = p.hostname.lower()
    netloc = host + (f":{p.port}" if p.port else "")
    path = p.path or "/"
    target = urlunsplit((p.scheme.lower(), netloc, path, p.query, ""))
    return host + (f":{p.port}" if p.port else ""), target


def _hex_hashes(values: tuple[int, int, int]) -> dict:
    return {"pHash": f"{values[0]:016x}", "dHash": f"{values[1]:016x}", "aHash": f"{values[2]:016x}"}


def _hash_dist(a: tuple[int, int, int], b: tuple[int, int, int]) -> dict:
    return {"pHash": (a[0] ^ b[0]).bit_count(),
            "dHash": (a[1] ^ b[1]).bit_count(),
            "aHash": (a[2] ^ b[2]).bit_count()}


async def inspect_single_site(image_bytes: bytes, website_url: str, output_dir: str,
                              *, max_pages: int = 500, max_images: int = 15000,
                              page_asset_limit: int = 250, sitemap_limit: int = 40) -> dict:
    """Run a deep scan constrained to one exact website host."""
    host, target = normalize_target(website_url)
    out = Path(output_dir)
    image_dir = out / "images"
    image_dir.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)

    events_path = out / "crawl-log.jsonl"
    images_path = out / "discovered-images.jsonl"
    pages_path = out / "pages.jsonl"
    matches_path = out / "matches.jsonl"
    for path in (events_path, images_path, pages_path, matches_path):
        path.write_text("", encoding="utf-8")

    def event(stage: str, message: str, **extra):
        row = {"time": time.strftime("%Y-%m-%dT%H:%M:%S"), "stage": stage, "message": message, **extra}
        with events_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"[{stage}] {message}", flush=True)

    # Deep-search budgets apply only to this isolated scan; other scan modes are unchanged.
    old = {k: getattr(config, k) for k in (
        "PAGES_PER_DOMAIN", "ASSETS_PER_PAGE", "STRUCTURED_ASSETS", "SITEMAP_FILES",
        "MAX_CANDIDATES", "SCAN_TIMEOUT", "GLOBAL_CONCURRENCY", "PER_HOST_CONCURRENCY")}
    config.PAGES_PER_DOMAIN = max_pages
    config.ASSETS_PER_PAGE = page_asset_limit
    config.STRUCTURED_ASSETS = max_images
    config.SITEMAP_FILES = sitemap_limit
    config.MAX_CANDIDATES = max_images
    config.SCAN_TIMEOUT = max(config.SCAN_TIMEOUT, 3600)
    config.GLOBAL_CONCURRENCY = min(config.GLOBAL_CONCURRENCY, 12)
    config.PER_HOST_CONCURRENCY = min(config.PER_HOST_CONCURRENCY, 3)

    started = time.time()
    http = Http()
    pool = None
    page_count = 0
    image_count = 0
    matched_count = 0
    failed_count = 0
    seen_images: set[str] = set()
    seen_css: set[str] = set()
    page_seen: set[str] = set()
    try:
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(max_workers=config.CPU_WORKERS)
        loop = asyncio.get_running_loop()
        event("INITIALIZATION", f"Target website: {target}", target_url=target, allowed_host=host)
        ref = await loop.run_in_executor(pool, build_reference, image_bytes)
        ref_hash = _hex_hashes(ref.full["original"])
        (out / "reference-fingerprints.json").write_text(
            json.dumps({"width": ref.size[0], "height": ref.size[1], "hashes": ref_hash,
                        "variants": {k: _hex_hashes(v) for k, v in ref.full.items()}}, indent=2),
            encoding="utf-8")
        event("REFERENCE_FINGERPRINT", "Reference image fingerprinted", hashes=ref_hash,
              dimensions=list(ref.size))

        crawler = DomainCrawler(host, http, start_url=target)
        event("CRAWLER", f"Starting deep crawl on exact host only: {host}")
        async for batch in crawler.batches(max_pages):
            if batch.source in ("home", "page"):
                if batch.page_url not in page_seen:
                    page_seen.add(batch.page_url)
                    page_count += 1
                    page_row = {"page_url": batch.page_url, "source": batch.source,
                                "title": batch.title, "assets_found": len(batch.assets)}
                    with pages_path.open("a", encoding="utf-8") as f:
                        f.write(json.dumps(page_row, ensure_ascii=False) + "\n")
                    event("PAGE_CRAWLING", batch.page_url, page_url=batch.page_url,
                          assets_found=len(batch.assets), source=batch.source)
            elif batch.source in ("sitemap", "wp", "rss"):
                event("STRUCTURED_DISCOVERY", f"{batch.source}: {batch.page_url}",
                      source=batch.source, source_url=batch.page_url, assets_found=len(batch.assets))

            # Expand external CSS files into background-image URLs. This is important for
            # galleries/themes where images are not represented by <img> elements.
            expanded_assets = list(batch.assets)
            css_queue = [a.url for a in batch.assets if a.source == "stylesheet" and a.url]
            css_fetched = 0
            while css_queue and css_fetched < 30:
                css_url = css_queue.pop(0)
                if css_url in seen_css:
                    continue
                seen_css.add(css_url)
                css_fetched += 1
                event("CSS_FETCH", css_url, stylesheet_url=css_url, page_url=batch.page_url)
                css_response = await http.get(css_url, max_bytes=config.MAX_HTML_BYTES,
                                              referer=batch.page_url, accept="text/css,*/*;q=0.5")
                if not css_response.ok:
                    event("CSS_FETCH_FAILED", css_url, reason=css_response.reason)
                    continue
                css_text = css_response.text()
                for match in re.finditer(r"url\(\s*['\"]?([^'\")]+)", css_text, re.I):
                    raw = match.group(1).strip()
                    if raw.startswith(("data:", "#")):
                        continue
                    absolute = urljoin(css_url, raw)
                    if urlsplit(absolute).scheme in ("http", "https"):
                        suffix = urlsplit(absolute).path.lower()
                        if re.search(r"\.(woff2?|ttf|otf|eot|svgz?)(?:$)", suffix):
                            continue
                        expanded_assets.append(Asset(absolute, page_url=batch.page_url,
                                                      source="css-background"))
                for match in re.finditer(r"@import\s+(?:url\()?['\"]?([^'\"\)\s;]+)", css_text, re.I):
                    imported = urljoin(css_url, match.group(1).strip())
                    if imported not in seen_css and len(css_queue) < 10:
                        css_queue.append(imported)

            # Preserve every unique image URL, including candidates which fail to download.
            assets = expanded_assets[:max_images]
            for asset in assets:
                if asset.source == "stylesheet":
                    continue
                if not asset.url or asset.url in seen_images or image_count >= max_images:
                    continue
                seen_images.add(asset.url)
                image_count += 1
                image_no = image_count
                event("IMAGE_DISCOVERY", asset.url, image_url=asset.url,
                      page_url=asset.page_url or batch.page_url, image_number=image_no)
                fetched = await http.image(asset.url, referer=batch.page_url)
                record = {
                    "image_number": image_no,
                    "image_url": asset.url,
                    "page_url": asset.page_url or batch.page_url,
                    "discovered_from": batch.source,
                    "asset_source": asset.source,
                    "title": asset.title or batch.title,
                    "http_status": fetched.code,
                    "download_status": fetched.status,
                    "download_reason": fetched.reason,
                    "content_type": fetched.ctype,
                    "bytes": len(fetched.content or b""),
                    "hashes": None,
                    "hash_distances": None,
                    "match": False,
                    "match_type": None,
                    "method": None,
                    "confidence": None,
                    "variant": None,
                    "saved_file": None,
                }
                if not fetched.ok or not fetched.content:
                    failed_count += 1
                    event("IMAGE_DOWNLOAD_FAILED", asset.url, reason=fetched.reason, status=fetched.status)
                else:
                    img = await loop.run_in_executor(pool, open_image, fetched.content)
                    if img is None:
                        failed_count += 1
                        record["download_reason"] = "Downloaded content is not a supported usable image"
                    else:
                        candidate_hashes = await loop.run_in_executor(pool, hashes, img)
                        distances = _hash_dist(ref.full["original"], candidate_hashes)
                        result = await loop.run_in_executor(pool, compare, ref, img)
                        digest = hashlib.sha256(fetched.content).hexdigest()
                        suffix = ".jpg"
                        ctype = (fetched.ctype or "").lower()
                        if "png" in ctype: suffix = ".png"
                        elif "webp" in ctype: suffix = ".webp"
                        elif "gif" in ctype: suffix = ".gif"
                        filename = f"{image_no:06d}-{digest[:12]}{suffix}"
                        (image_dir / filename).write_bytes(fetched.content)
                        record.update({
                            "width": img.width, "height": img.height,
                            "sha256": digest,
                            "hashes": _hex_hashes(candidate_hashes),
                            "hash_distances": distances,
                            "saved_file": f"images/{filename}",
                        })
                        event("IMAGE_FINGERPRINT", asset.url, image_number=image_no,
                              hashes=record["hashes"], distances=distances)
                        if result is not None:
                            matched_count += 1
                            record.update({"match": True, "match_type": result.match_type,
                                           "method": result.method, "confidence": result.confidence,
                                           "variant": result.variant, "inliers": result.inliers,
                                           "inlier_ratio": result.inlier_ratio, "spread": result.spread})
                            with matches_path.open("a", encoding="utf-8") as f:
                                f.write(json.dumps(record, ensure_ascii=False) + "\n")
                            event("MATCH_FOUND", asset.url, match_type=result.match_type,
                                  method=result.method, confidence=result.confidence,
                                  image_number=image_no)
                        else:
                            event("NO_MATCH", asset.url, image_number=image_no)
                with images_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
            if image_count >= max_images:
                event("LIMIT_REACHED", f"Image limit reached: {max_images}")
                break

        summary = {
            "status": "completed",
            "target_url": target,
            "allowed_host": host,
            "started_at": started,
            "duration_seconds": round(time.time() - started, 2),
            "pages_visited": page_count,
            "unique_image_urls": image_count,
            "images_download_failed_or_invalid": failed_count,
            "images_compared": image_count - failed_count,
            "matches_found": matched_count,
            "max_pages": max_pages,
            "max_images": max_images,
            "crawler_stats": crawler.stats,
            "crawler_sources": crawler.sources,
            "requests": http.requests,
            "files": {
                "pages": "pages.jsonl",
                "images_and_hashes": "discovered-images.jsonl",
                "matches": "matches.jsonl",
                "events": "crawl-log.jsonl",
                "downloaded_images": "images/",
                "reference_fingerprints": "reference-fingerprints.json",
            },
        }
        (out / "scan-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        event("COMPLETED", "Single-website inspection finished", summary=summary)
        return summary
    finally:
        await http.close()
        if pool:
            pool.shutdown(wait=False, cancel_futures=True)
        for key, value in old.items():
            setattr(config, key, value)
