"""SSRF guard: the crawler fetches URLs found inside untrusted pages, so every request
(including each redirect hop) must resolve to a public IP address."""
from __future__ import annotations

import asyncio
import ipaddress
import socket
import time

import httpx

from . import config

_ALLOWED_PORTS = {None, 80, 443, 8080, 8443}
_cache: dict[str, tuple[float, bool]] = {}


class BlockedAddress(httpx.RequestError):
    pass


def _public(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if addr.version == 6 and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    return addr.is_global and not addr.is_multicast


async def request_hook(request: httpx.Request) -> None:
    if config.ALLOW_PRIVATE:
        return
    url = request.url
    if url.scheme not in ("http", "https") or url.port not in _ALLOWED_PORTS or not url.host:
        raise BlockedAddress("blocked: scheme/port not allowed", request=request)
    host = url.host
    hit = _cache.get(host)
    if hit and time.monotonic() - hit[0] < 300:
        ok = hit[1]
    else:
        try:
            ipaddress.ip_address(host)
            addrs = [host]
        except ValueError:
            try:
                infos = await asyncio.get_running_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
                addrs = sorted({i[4][0] for i in infos})
            except OSError:
                addrs = []
        if not addrs:
            raise httpx.ConnectError("DNS lookup failed", request=request)       # unreachable, not "blocked"
        ok = all(_public(a) for a in addrs)
        if len(_cache) > 4096:
            _cache.clear()
        _cache[host] = (time.monotonic(), ok)
    if not ok:
        raise BlockedAddress("blocked: host resolves to a non-public address", request=request)
