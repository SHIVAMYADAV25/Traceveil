"""core-engine: reverse-image leak discovery (fingerprint -> crawl -> match -> contacts)."""
