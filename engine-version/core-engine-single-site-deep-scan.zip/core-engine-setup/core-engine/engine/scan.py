"""
Scan orchestrator:  reference -> crawl (pass 1) -> adaptive deepening (pass 2) -> refine -> contacts.

Why it finds more than a one-shot crawl
---------------------------------------
* Pass 1 gives every domain a normal budget, pulling candidates from sitemaps / WP API / feeds / pages.
* Pass 2 ADAPTS: a domain that matched gets a big extra budget, the matched content page is crawled
  first (its "related videos" are where re-uploads cluster), and sister sites on the same network or
  video CDN are searched deeper too.
* Refine opens each matched page, collects its video URLs and title, and re-tests the page's own main
  image (og:image / poster).  A second, independent image agreeing upgrades the match to "verified".
"""
from __future__ import annotations

import asyncio
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional

from . import config
from .contacts import IGNORED_PROVIDERS, Contacts, load_rows, norm_domain
from .crawler import Batch, DomainCrawler
from .extract import Asset, VideoRef, _dedupe_videos, parse_html
from .fingerprint import Outcome, Reference, build_reference, compare, open_image
from .http import Http
from .notice import build_notice

STRONG = ("exact", "near_duplicate", "structural")


def _compare_bytes(ref: Reference, data: bytes):
    img = open_image(data)
    if img is None:
        return None
    out = compare(ref, img)
    return (out, img.size) if out else ((None, img.size))


@dataclass
class State:
    reference: Reference
    http: Http
    pool: ThreadPoolExecutor
    progress: Optional[Callable[[dict], None]]
    cancel: asyncio.Event
    deadline: float
    seen: set = field(default_factory=set)
    matches: list = field(default_factory=list)
    dom: dict = field(default_factory=dict)
    candidates: int = 0
    domains_done: int = 0
    domains_total: int = 0
    events: list = field(default_factory=list)
    phase: str = "starting"
    truncated: Optional[str] = None

    def expired(self) -> bool:
        if self.cancel.is_set():
            self.truncated = self.truncated or "cancelled"
            return True
        if time.monotonic() > self.deadline:
            self.truncated = self.truncated or "time limit reached"
            return True
        return False

    def take(self, n: int) -> int:
        room = max(0, config.MAX_CANDIDATES - self.candidates)
        if room < n:
            self.truncated = self.truncated or "candidate limit reached"
        got = min(n, room)
        self.candidates += got
        return got

    def event(self, msg: str) -> None:
        self.events.append({"t": round(time.time(), 1), "msg": msg})
        del self.events[:-100]
        self.push()

    def push(self) -> None:
        if self.progress:
            self.progress({
                "phase": self.phase, "candidates": self.candidates, "matches": len(self.matches),
                "domains_done": self.domains_done, "domains_total": self.domains_total,
                "pages": sum(d.get("pages", 0) for d in self.dom.values()),
                "events": list(self.events[-30:]),
            })


class Scanner:
    def __init__(self, rows: Optional[list] = None, contacts: Optional[Contacts] = None):
        self.rows = rows if rows is not None else load_rows()
        self.contacts = contacts or Contacts()

    # ── public ─────────────────────────────────────────────────────────────
    async def scan(self, image_bytes: bytes, *, domains: Optional[list] = None,
                   progress: Optional[Callable[[dict], None]] = None,
                   cancel: Optional[asyncio.Event] = None) -> dict:
        started = time.time()
        loop = asyncio.get_running_loop()
        pool = ThreadPoolExecutor(max_workers=config.CPU_WORKERS)
        http = Http()
        try:
            reference = await loop.run_in_executor(pool, build_reference, image_bytes)
            rows = self._select(domains)
            st = State(reference, http, pool, progress, cancel or asyncio.Event(),
                       time.monotonic() + config.SCAN_TIMEOUT, domains_total=len(rows))
            st.dom = {r["domain"]: {"candidates": 0, "skipped": 0, "img_fail": 0, "pages": 0} for r in rows}
            crawlers = {r["domain"]: DomainCrawler(r["domain"], http) for r in rows}
            by_domain = {r["domain"]: r for r in rows}

            st.phase = "crawling"
            st.event(f"Pass 1: searching {len(rows)} sites")
            await self._run_pass(st, [(r, config.PAGES_PER_DOMAIN) for r in rows], crawlers)

            if st.matches and not st.expired():
                st.phase = "deepening"
                matched = {m["domain"] for m in st.matches}
                related = self._related(matched, rows)
                st.event(f"Pass 2: {len(matched)} matched site(s) + {len(related)} related site(s) searched deeper")
                for m in st.matches:
                    if m["page_specific"] and m["page_url"] and m["domain"] in crawlers:
                        crawlers[m["domain"]].enqueue(m["page_url"], 100)
                plan = [(by_domain[d], config.BONUS_PAGES) for d in matched if d in by_domain]
                plan += [(by_domain[d], config.BONUS_PAGES // 2) for d in related if d in by_domain]
                st.domains_done = 0
                st.domains_total = len(plan)
                await self._run_pass(st, plan, crawlers)
            else:
                related = []

            matches = self._consolidate(st.matches)
            st.phase = "verifying"
            st.event(f"Verifying {min(len(matches), 25)} match(es) on their pages")
            await asyncio.gather(*[self._refine(st, m) for m in matches[:25]], return_exceptions=True)
            matches = self._consolidate(matches)

            st.phase = "contacts"
            domains_hit = list(dict.fromkeys(m["domain"] for m in matches))
            contacts = {}
            infos = await asyncio.gather(*[self.contacts.lookup(
                d, http, base_url=(crawlers[d].base if d in crawlers else None)) for d in domains_hit], return_exceptions=True)
            for d, info in zip(domains_hit, infos):
                contacts[d] = info if isinstance(info, dict) else self.contacts.static(d)
            for m in matches:
                m["contact"] = contacts.get(m["domain"])
            notices = [build_notice(d, [m for m in matches if m["domain"] == d], contacts[d]) for d in domains_hit]

            st.phase = "done"
            st.push()
            return {
                "status": "completed",
                "duration_s": round(time.time() - started, 1),
                "reference": {"width": reference.size[0], "height": reference.size[1]},
                "matches": matches,
                "notices": notices,
                "related_domains": related,
                "coverage": self._coverage(st, crawlers),
                "stats": {"candidates_compared": st.candidates, "requests": http.requests,
                          "domains": len(rows), "truncated": st.truncated},
            }
        finally:
            await http.close()
            pool.shutdown(wait=False, cancel_futures=True)

    # ── internals ──────────────────────────────────────────────────────────
    def _select(self, domains: Optional[list]) -> list:
        if not domains:
            return list(self.rows)
        wanted = [norm_domain(d) if ":" not in d else d.strip().lower() for d in domains if d.strip()]
        known = {r["domain"]: r for r in self.rows}
        return [known.get(d, {"domain": d, "network": "", "provider_type": "", "video_provider": ""}) for d in wanted]

    def _related(self, matched: set, rows: list) -> list:
        nets = {r.get("network") for r in rows if r["domain"] in matched and r.get("network") not in (None, "", "UnknownNetwork")}
        vids = {r.get("video_provider") for r in rows if r["domain"] in matched and (r.get("video_provider") or "").lower() not in IGNORED_PROVIDERS}
        return [r["domain"] for r in rows if r["domain"] not in matched and (r.get("network") in nets or r.get("video_provider") in vids)]

    async def _run_pass(self, st: State, plan: list, crawlers: dict) -> None:
        async def one(row: dict, budget: int) -> None:
            c = crawlers[row["domain"]]
            try:
                async for batch in c.batches(budget):
                    if st.expired():
                        break
                    await self._process(st, row, c, batch)
            except Exception as exc:                               # one bad site must never stop the scan
                st.event(f"{row['domain']}: {type(exc).__name__}")
            finally:
                st.dom[row["domain"]]["pages"] = c.pages_fetched
                st.domains_done += 1
                st.push()
        await asyncio.gather(*[one(r, b) for r, b in plan])

    async def _process(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch) -> None:
        domain = row["domain"]
        cap = config.STRUCTURED_ASSETS if batch.source in ("sitemap", "wp", "rss") else config.ASSETS_PER_PAGE
        fresh: list[Asset] = []
        for a in batch.assets:
            if a.source == "stylesheet":
                continue
            if a.url and a.url not in st.seen:
                st.seen.add(a.url)
                fresh.append(a)
        fresh = fresh[:cap]
        got = st.take(len(fresh))
        st.dom[domain]["skipped"] += len(fresh) - got
        fresh = fresh[:got]
        if not fresh:
            return
        st.dom[domain]["candidates"] += len(fresh)
        results = await asyncio.gather(*[self._evaluate(st, row, crawler, batch, a) for a in fresh], return_exceptions=True)
        st.push()

    async def _evaluate(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch, asset: Asset) -> None:
        domain = row["domain"]
        f = await st.http.image(asset.url, referer=batch.page_url if batch.source in ("home", "page") else crawler.base)
        if not f.ok or not f.content:
            st.dom[domain]["img_fail"] += 1
            return
        res = await asyncio.get_running_loop().run_in_executor(st.pool, _compare_bytes, st.reference, f.content)
        if not res or res[0] is None:
            return
        outcome, size = res
        specific = bool(asset.page_url) or batch.source == "page"
        page_url = asset.page_url or batch.page_url
        videos = list(asset.videos) + (list(batch.videos) if (specific and not asset.page_url) else [])
        match = self._match(row, outcome, asset, page_url, specific, size, videos, batch.source, batch.title)
        st.matches.append(match)
        st.event(f"Match on {domain} ({outcome.match_type}, {outcome.confidence:.0f}%)")
        if specific and page_url:
            crawler.enqueue(page_url, 100)

    @staticmethod
    def _match(row, o: Outcome, asset: Asset, page_url, specific, size, videos, found_via, title) -> dict:
        return {
            "id": uuid.uuid4().hex[:8],
            "domain": row["domain"],
            "page_url": page_url,
            "page_specific": specific,
            "image_url": asset.url,
            "alt_image_urls": [],
            "videos": [{"url": v.url, "kind": v.kind} for v in _dedupe_videos(videos)][:5],
            "title": (asset.title or title or None),
            "match_type": o.match_type, "method": o.method, "variant": o.variant,
            "confidence": o.confidence, "inliers": o.inliers, "inlier_ratio": o.inlier_ratio,
            "category": "strong" if o.match_type in STRONG else "possible",
            "verified_on_page": False,
            "main_hit": asset.source in ("meta", "jsonld") and specific,
            "found_via": found_via,
            "network": row.get("network") or None,
            "image_size": list(size),
        }

    def _consolidate(self, matches: list) -> list:
        groups: dict = {}
        for m in matches:
            key = (m["domain"], m["page_url"] if m["page_specific"] else m["image_url"])
            cur = groups.get(key)
            if cur is None:
                groups[key] = m
                continue
            best, other = (m, cur) if m["confidence"] > cur["confidence"] else (cur, m)
            best["alt_image_urls"] = list(dict.fromkeys(best["alt_image_urls"] + other["alt_image_urls"] + [other["image_url"]]))[:6]
            seen = {v["url"] for v in best["videos"]}
            best["videos"] += [v for v in other["videos"] if v["url"] not in seen]
            best["main_hit"] = best["main_hit"] or other["main_hit"]
            best["title"] = best["title"] or other["title"]
            groups[key] = best
        out = list(groups.values())
        for m in out:
            self._finalize(m)
        out.sort(key=lambda m: (m["verified_on_page"], m["category"] == "strong", m["confidence"]), reverse=True)
        return out

    @staticmethod
    def _finalize(m: dict) -> None:
        """'verified' = the page's OWN main image matched AND at least one other, different image matched too."""
        distinct = {m["image_url"], *m["alt_image_urls"]}
        m["verified_on_page"] = bool(m["main_hit"] and len(distinct) >= 2)
        if m["verified_on_page"]:
            m["category"] = "strong"

    async def _refine(self, st: State, m: dict) -> None:
        """Open the matched page: collect video URLs + title, and re-test the page's own main image."""
        if not m["page_specific"] or not m["page_url"] or st.cancel.is_set():
            return
        f = await st.http.page(m["page_url"])
        if not f.ok:
            return
        parsed = parse_html(f.text(), m["page_url"])
        seen = {v["url"] for v in m["videos"]}
        m["videos"] += [{"url": v.url, "kind": v.kind} for v in parsed.videos if v.url not in seen]
        m["videos"] = m["videos"][:6]
        if not m["title"] and parsed.title:
            m["title"] = parsed.title
        mains = [a for a in parsed.assets if a.source in ("meta", "jsonld")][:4]
        loop = asyncio.get_running_loop()
        for a in mains:
            img = await st.http.image(a.url, referer=m["page_url"])
            if not img.ok or not img.content:
                continue
            res = await loop.run_in_executor(st.pool, _compare_bytes, st.reference, img.content)
            if res and res[0] is not None and res[0].match_type in STRONG:
                m["main_hit"] = True
                if a.url != m["image_url"]:
                    m["alt_image_urls"] = list(dict.fromkeys(m["alt_image_urls"] + [a.url]))[:6]
                m["confidence"] = max(m["confidence"], res[0].confidence)
                break
        self._finalize(m)

    @staticmethod
    def _coverage(st: State, crawlers: dict) -> dict:
        counts = {"checked": 0, "no_images": 0, "blocked": 0, "unreachable": 0, "skipped": 0}
        detail = {}
        for domain, d in st.dom.items():
            c = crawlers[domain]
            if d["candidates"] > 0:
                status = "checked"
            elif d["skipped"] > 0:
                status = "skipped"
            elif c.stats["ok"] > 0:
                status = "no_images"
            elif c.stats["blocked"] > 0:
                status = "blocked"
            else:
                status = "unreachable"
            counts[status] += 1
            detail[domain] = {"status": status, "pages": c.pages_fetched, "candidates": d["candidates"],
                              "image_failures": d["img_fail"], "sources": dict(c.sources),
                              "reason": c.last_reason if status in ("blocked", "unreachable") else ""}
        return {"summary": counts, "domains": detail}
