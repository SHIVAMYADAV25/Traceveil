"""Command line:   python cli.py scan photo.jpg [--domains a.com,b.com] [--out result.json]
                  python cli.py serve [--port 8000]"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import re

from engine.scan import Scanner


async def _scan(args) -> int:
    data = open(args.image, "rb").read()
    last = {"line": ""}

    def progress(p: dict) -> None:
        line = (f"[{p.get('phase','')}] sites {p.get('domains_done',0)}/{p.get('domains_total',0)}  "
                f"pages {p.get('pages',0)}  images compared {p.get('candidates',0)}  matches {p.get('matches',0)}")
        if line != last["line"]:
            last["line"] = line
            print(line, file=sys.stderr)

    result = await Scanner().scan(data, domains=[d for d in (args.domains or "").split(",") if d], progress=progress)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2)
        print(f"full result written to {args.out}", file=sys.stderr)
    print(f"\n{len(result['matches'])} match(es) in {result['duration_s']}s   coverage: {result['coverage']['summary']}")
    for m in result["matches"]:
        c = m.get("contact") or {}
        print(f"\n[{m['category'].upper()}{' / VERIFIED' if m['verified_on_page'] else ''}] {m['domain']}  {m['confidence']:.0f}%  ({m['match_type']}, {m['method']})")
        print(f"  page : {m['page_url']}")
        print(f"  image: {m['image_url']}")
        for v in m["videos"]:
            print(f"  video: {v['url']}  ({v['kind']})")
        for e in c.get("emails", [])[:3]:
            print(f"  email: {e['email']}  ({e['source']})")
        for p in c.get("removal_pages", [])[:2]:
            print(f"  form : {p['url']}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan")
    s.add_argument("image")
    s.add_argument("--domains", help="comma separated; default = all 91 dataset domains")
    s.add_argument("--out", help="write full JSON result here")
    one = sub.add_parser("single", help="deep-inspect exactly one website URL")
    one.add_argument("image", help="reference image to search for")
    one.add_argument("url", help="one target website URL, e.g. https://example.com/")
    one.add_argument("--outdir", default=None, help="output folder (default: inspection-results/<host>-<timestamp>)")
    one.add_argument("--max-pages", type=int, default=500, help="maximum HTML pages to visit")
    one.add_argument("--max-images", type=int, default=15000, help="maximum unique image URLs to inspect")
    one.add_argument("--assets-per-page", type=int, default=250, help="maximum image candidates taken from each page")
    one.add_argument("--sitemap-limit", type=int, default=40, help="maximum sitemap documents to inspect")
    v = sub.add_parser("serve")
    v.add_argument("--port", type=int, default=8000)
    v.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()
    if args.cmd == "serve":
        import uvicorn
        uvicorn.run("server:app", host=args.host, port=args.port)
        return 0
    if args.cmd == "single":
        from datetime import datetime
        from pathlib import Path
        from engine.single_site import inspect_single_site, normalize_target
        host, target = normalize_target(args.url)
        outdir = args.outdir or str(Path("inspection-results") / (
            re.sub(r"[^a-zA-Z0-9.-]+", "_", host) + "-" + datetime.now().strftime("%Y%m%d-%H%M%S")))
        async def run_single():
            data = Path(args.image).read_bytes()
            result = await inspect_single_site(
                data, target, outdir, max_pages=max(1, args.max_pages),
                max_images=max(1, args.max_images), page_asset_limit=max(1, args.assets_per_page),
                sitemap_limit=max(1, args.sitemap_limit))
            print("\n=== SINGLE WEBSITE INSPECTION SUMMARY ===")
            print(json.dumps(result, indent=2))
        asyncio.run(run_single())
        return 0
    return asyncio.run(_scan(args))


if __name__ == "__main__":
    sys.exit(main())
