$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot\core-engine

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error 'Python was not found. Install Python 3.10+ and enable Add Python to PATH, then rerun this script.'
}

python --version
if (-not (Test-Path '.venv\Scripts\python.exe')) {
    python -m venv .venv
}

& '.venv\Scripts\python.exe' -m pip install --upgrade pip
& '.venv\Scripts\python.exe' -m pip install -r requirements.txt

Write-Host ''
Write-Host 'Setup complete.'
Write-Host 'Start the UI with: .\run-ui.ps1'
Write-Host 'Run a scan with:  .\run-scan.ps1 -ImagePath "C:\path\to\reference.jpg" -Domains "example.com"'
