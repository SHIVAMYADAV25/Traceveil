param(
    [Parameter(Mandatory = $true)]
    [string]$ImagePath,
    [string]$Domains = '',
    [string]$OutputPath = 'result.json'
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot\core-engine
$Python = Join-Path $PWD '.venv\Scripts\python.exe'
if (-not (Test-Path $Python)) {
    Write-Error 'Environment not set up. Run .\setup-windows.ps1 first.'
}
if (-not (Test-Path $ImagePath)) {
    Write-Error "Reference image not found: $ImagePath"
}
$Args = @('cli.py', 'scan', $ImagePath, '--out', $OutputPath)
if ($Domains.Trim()) {
    $Args += @('--domains', $Domains)
}
& $Python @Args
exit $LASTEXITCODE
