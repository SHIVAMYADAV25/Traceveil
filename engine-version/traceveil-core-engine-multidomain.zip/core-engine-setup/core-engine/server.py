"""Minimal HTTP API + one-page UI.   Run:  uvicorn server:app --port 8000"""
from __future__ import annotations

import asyncio
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from engine.fingerprint import MIN_SIDE, open_image
from engine.scan import Scanner

STATIC = Path(__file__).parent / "static"
MAX_UPLOAD = 12 * 1024 * 1024
MAX_RUNNING = 2
KEEP_JOBS = 30

app = FastAPI(title="core-engine", docs_url="/docs")
scanner = Scanner()
JOBS: dict[str, dict] = {}


def _public(job: dict) -> dict:
    return {k: v for k, v in job.items() if k not in ("task", "cancel")}


async def _run(job_id: str, data: bytes, domains: list[str]) -> None:
    job = JOBS[job_id]

    def progress(p: dict) -> None:
        job["progress"] = p

    try:
        artifact_dir = Path(__file__).parent / "scan-results" / job_id
        job["result"] = await scanner.scan(
            data, domains=domains or None, progress=progress,
            cancel=job["cancel"], output_dir=artifact_dir,
        )
        job["status"] = "cancelled" if job["cancel"].is_set() else "completed"
    except ValueError as exc:
        job["status"], job["error"] = "failed", str(exc)
    except Exception:                                      # noqa: BLE001
        job["status"], job["error"] = "failed", "The scan failed unexpectedly."
    job["finished_at"] = time.time()


@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
async def health():
    return {"ok": True, "domains": len(scanner.rows), "default_scope": "all configured domains"}


@app.get("/api/domains")
async def domains():
    return {"count": len(scanner.rows), "domains": [
        {"domain": r["domain"], "network": r.get("network"), "provider_type": r.get("provider_type")}
        for r in scanner.rows
    ]}


@app.post("/api/scan", status_code=202)
async def start_scan(file: UploadFile = File(...), domains: str = Form("")):
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Image is larger than 12 MB.")
    img = open_image(data)
    if img is None or min(img.size) < MIN_SIDE:
        raise HTTPException(400, "That file could not be read as a usable image (JPEG, PNG or WebP).")
    if sum(1 for j in JOBS.values() if j["status"] == "running") >= MAX_RUNNING:
        raise HTTPException(429, "The server is already running the maximum number of scans. Retry in a minute.")
    job_id = uuid.uuid4().hex[:12]
    job = {"id": job_id, "status": "running", "created_at": time.time(), "finished_at": None, "progress": {"phase": "starting"},
           "result": None, "error": None, "cancel": asyncio.Event()}
    JOBS[job_id] = job
    job["task"] = asyncio.create_task(_run(job_id, data, [d.strip() for d in domains.split(",") if d.strip()]))
    for old in sorted((j for j in JOBS.values() if j["status"] != "running"), key=lambda j: j["created_at"])[:-KEEP_JOBS]:
        JOBS.pop(old["id"], None)
    return {"scan_id": job_id}


@app.get("/api/scan/{scan_id}")
async def get_scan(scan_id: str):
    job = JOBS.get(scan_id)
    if job is None:
        raise HTTPException(404, "Unknown scan id.")
    return _public(job)


@app.post("/api/scan/{scan_id}/cancel")
async def cancel_scan(scan_id: str):
    job = JOBS.get(scan_id)
    if job is None:
        raise HTTPException(404, "Unknown scan id.")
    job["cancel"].set()
    return {"ok": True}
