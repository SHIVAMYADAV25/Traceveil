"""Persistent, privacy-minimal cache for candidate image comparison results.

Only SHA-256 digests, dimensions, perceptual hashes and matcher outcomes are stored.
Candidate image bytes are never written to this cache.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Optional

from .fingerprint import Outcome

CACHE_VERSION = "matcher-v2"


class FingerprintCache:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.path), timeout=10)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS comparisons (
                ref_key TEXT NOT NULL,
                image_sha256 TEXT NOT NULL,
                version TEXT NOT NULL,
                width INTEGER NOT NULL,
                height INTEGER NOT NULL,
                hashes_json TEXT NOT NULL,
                outcome_json TEXT,
                created_at REAL NOT NULL,
                PRIMARY KEY(ref_key, image_sha256, version)
            )
        """)
        self.db.commit()
        self.pending = 0
        self.total_since_prune = 0

    def get(self, ref_key: str, image_sha256: str):
        row = self.db.execute(
            "SELECT width,height,hashes_json,outcome_json FROM comparisons "
            "WHERE ref_key=? AND image_sha256=? AND version=?",
            (ref_key, image_sha256, CACHE_VERSION),
        ).fetchone()
        if not row:
            return None
        width, height, hashes_json, outcome_json = row
        payload = json.loads(outcome_json) if outcome_json else None
        outcome = Outcome(**payload) if payload else None
        return outcome, (width, height), json.loads(hashes_json)

    def put(self, ref_key: str, image_sha256: str, size: tuple[int, int], hashes: dict,
            outcome: Optional[Outcome]) -> None:
        payload = outcome.__dict__ if outcome is not None else None
        self.db.execute(
            "INSERT OR REPLACE INTO comparisons "
            "(ref_key,image_sha256,version,width,height,hashes_json,outcome_json,created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (ref_key, image_sha256, CACHE_VERSION, int(size[0]), int(size[1]),
             json.dumps(hashes, separators=(",", ":")),
             json.dumps(payload, separators=(",", ":")) if payload else None, time.time()),
        )
        self.pending += 1
        self.total_since_prune += 1
        if self.pending >= 100:
            self.db.commit()
            self.pending = 0
        if self.total_since_prune >= 5000:
            self.db.execute(
                "DELETE FROM comparisons WHERE rowid NOT IN "
                "(SELECT rowid FROM comparisons ORDER BY created_at DESC LIMIT 200000)"
            )
            self.db.commit()
            self.total_since_prune = 0
        self.total_since_prune = 0

    def close(self):
        self.db.commit()
        self.db.close()
