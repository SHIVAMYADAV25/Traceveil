"""Polite, bounded, retrying async HTTP client used for every request the engine makes."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

import httpx

from . import config, netguard

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0.0.0 Safari/537.36")
BOT_MARKERS = (b"just a moment", b"cf-chl", b"attention required", b"captcha", b"access denied", b"ddos protection")


@dataclass
class Fetched:
    status: str                       # ok | blocked | error | timeout
    content: Optional[bytes] = None
    url: str = ""
    code: Optional[int] = None
    ctype: str = ""
    reason: str = ""

    @property
    def ok(self) -> bool:
        return self.status == "ok" and self.content is not None

    def text(self) -> str:
        if not self.content:
            return ""
        for enc in ("utf-8", "latin-1"):
            try:
                return self.content.decode(enc)
            except UnicodeDecodeError:
                continue
        return ""


class Http:
    def __init__(self):
        self.client = httpx.AsyncClient(
            headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"},
            timeout=httpx.Timeout(config.HTTP_TIMEOUT),
            follow_redirects=True,
            limits=httpx.Limits(max_connections=config.GLOBAL_CONCURRENCY * 2, max_keepalive_connections=24),
            event_hooks={"request": [netguard.request_hook]},
        )
        self._global = asyncio.Semaphore(config.GLOBAL_CONCURRENCY)
        self._hosts: dict[str, asyncio.Semaphore] = {}
        self._host_delay: dict[str, float] = {}
        self._host_next: dict[str, float] = {}
        self.requests = 0

    async def close(self) -> None:
        await self.client.aclose()

    def _host_sem(self, host: str) -> asyncio.Semaphore:
        sem = self._hosts.get(host)
        if sem is None:
            sem = self._hosts[host] = asyncio.Semaphore(config.PER_HOST_CONCURRENCY)
        return sem

    async def get(self, url: str, *, max_bytes: int, referer: Optional[str] = None,
                  accept: str = "*/*", want_image: bool = False) -> Fetched:
        headers = {"Accept": accept}
        if referer:
            headers["Referer"] = referer
        host = urlparse(url).netloc
        last = Fetched("error", url=url, reason="no attempt")
        async with self._host_sem(host), self._global:           # host first: never hog global slots while queued
            for attempt in range(config.RETRIES + 1):
                delay = self._host_delay.get(host, 0.15)
                wait = self._host_next.get(host, 0.0) - asyncio.get_running_loop().time()
                if wait > 0:
                    await asyncio.sleep(wait)
                self._host_next[host] = asyncio.get_running_loop().time() + delay
                self.requests += 1
                try:
                    async with self.client.stream("GET", url, headers=headers) as r:
                        code = r.status_code
                        ctype = r.headers.get("content-type", "").lower()
                        if code in (401, 403, 451):
                            return Fetched("blocked", url=str(r.url), code=code, reason=f"HTTP {code}")
                        if code in (429, 502, 503, 504):
                            last = Fetched("blocked" if code in (429, 503) else "error", url=str(r.url), code=code, reason=f"HTTP {code}")
                            if code in (429, 503):
                                self._host_delay[host] = min(8.0, max(0.5, delay * 2))
                            await asyncio.sleep(0.6 * (2 ** attempt))
                            continue
                        if code >= 400:
                            return Fetched("error", url=str(r.url), code=code, reason=f"HTTP {code}")
                        if want_image and ("text/html" in ctype or "json" in ctype):
                            return Fetched("error", url=str(r.url), code=code, ctype=ctype, reason="not an image")
                        chunks, total = [], 0
                        async for chunk in r.aiter_bytes():
                            total += len(chunk)
                            if total > max_bytes:
                                if want_image:
                                    return Fetched("error", url=str(r.url), code=code, reason="too large")
                                chunks.append(chunk[: len(chunk) - (total - max_bytes)])
                                break
                            chunks.append(chunk)
                        body = b"".join(chunks)
                        head = body[:4000].lower()
                        if not want_image and code == 200 and any(m in head for m in BOT_MARKERS) and len(body) < 60_000:
                            return Fetched("blocked", url=str(r.url), code=code, reason="bot protection page")
                        return Fetched("ok", content=body, url=str(r.url), code=code, ctype=ctype)
                except netguard.BlockedAddress as exc:
                    return Fetched("blocked", url=url, reason=str(exc))
                except httpx.TimeoutException:
                    last = Fetched("timeout", url=url, reason="timeout")
                except httpx.HTTPError as exc:
                    last = Fetched("error", url=url, reason=type(exc).__name__)
                await asyncio.sleep(0.4 * (2 ** attempt))
        return last

    async def page(self, url: str) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_HTML_BYTES,
                              accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

    async def xml(self, url: str) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_XML_BYTES, accept="application/xml,text/xml,*/*")

    async def image(self, url: str, referer: Optional[str] = None) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_IMAGE_BYTES, referer=referer,
                              accept="image/avif,image/webp,image/apng,image/*,*/*;q=0.8", want_image=True)
