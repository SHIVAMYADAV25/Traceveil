"""
Turn pages, sitemaps, feeds and JSON APIs into candidate images, video URLs and links.

A thumbnail on a listing page is useless without the page it links to, so every
asset keeps `page_url` (the content page its thumbnail is wrapped in) and `title`.
"""
from __future__ import annotations

import gzip
import html as htmllib
import json
import re
from dataclasses import dataclass, field
from typing import Iterable, Optional
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

try:
    import lxml  # noqa: F401
    _PARSER = "lxml"
except ImportError:  # pragma: no cover
    _PARSER = "html.parser"

LAZY_ATTRS = ("data-src", "data-original", "data-lazy-src", "data-lazy", "data-thumb", "data-thumbnail",
              "data-image", "data-img", "data-echo", "data-url", "data-full", "data-poster", "data-preview")
JUNK_PARTS = ("favicon", "sprite", "pixel", "spacer", "blank.", "/logo", "logo.", "/icon", "icon-", "avatar",
              "emoji", "loader", "loading.", "placeholder", "badge", "/flags/", "1x1", "transparent.", "/ads/", "banner-ad")
JUNK_EXT = (".svg", ".ico", ".css", ".js", ".woff", ".woff2", ".ttf", ".mp4", ".webm", ".m3u8")
VIDEO_RE = re.compile(r"https?:(?:\\?/){2}[^\s\"'<>\\]+?\.(?:mp4|webm|m3u8|mpd|mov|m4v)(?:\?[^\s\"'<>\\]*)?", re.I)
CONTENT_WORDS = ("video", "watch", "clip", "mms", "gallery", "post", "view", "play", "photo", "pic", "leak", "scandal", "viral", "mms", "full")
LISTING_WORDS = ("page", "category", "categories", "tag", "tags", "latest", "popular", "new", "trending", "search", "videos", "porn", "indian", "desi")
SKIP_PATH = ("login", "register", "signup", "sign-up", "contact", "privacy", "terms", "about", "dmca", "cookie", "wp-admin",
             "cart", "checkout", "account", "logout", "feed", "xmlrpc", "wp-json", "mailto:", "javascript:", "tel:", "#")
PAGINATION_RE = re.compile(r"(/page/\d+|/p/\d+|[?&](?:page|paged|p|pg)=\d+|/\d+/?$)", re.I)


@dataclass
class VideoRef:
    url: str
    kind: str                      # direct | stream | embed


@dataclass
class Asset:
    url: str
    page_url: Optional[str] = None     # the content page this image belongs to (None = the page it was found on)
    title: Optional[str] = None
    source: str = "html"               # html | meta | jsonld | sitemap | wp | rss
    videos: list = field(default_factory=list)


@dataclass
class Parsed:
    title: Optional[str] = None
    assets: list = field(default_factory=list)
    videos: list = field(default_factory=list)
    links: list = field(default_factory=list)          # [(url, text)]
    feeds: list = field(default_factory=list)


# ── URL helpers ────────────────────────────────────────────────────────────

def norm_host(host: str) -> str:
    host = (host or "").lower()
    return host[4:] if host.startswith("www.") else host


def same_site(a: str, b: str) -> bool:
    return norm_host(urlparse(a).netloc) == norm_host(urlparse(b).netloc)


def clean(url: str, base: str) -> Optional[str]:
    if not url:
        return None
    url = htmllib.unescape(url.strip()).replace("\\/", "/")
    if url.startswith("data:") or url.startswith("javascript:") or url.startswith("#"):
        return None
    if url.startswith("//"):
        url = urlparse(base).scheme + ":" + url
    absolute = urljoin(base, url).split("#", 1)[0]
    return absolute if urlparse(absolute).scheme in ("http", "https") else None


def is_junk(url: str) -> bool:
    low = urlparse(url).path.lower()
    if low.endswith(JUNK_EXT):
        return True
    full = url.lower()
    return any(p in full for p in JUNK_PARTS)


def best_srcset(value: str) -> Optional[str]:
    """Pick the entry closest to (not above) ~800px wide; thumbnails are matched at <=640px anyway."""
    best, best_w = None, -1
    smallest, smallest_w = None, 10 ** 9
    for part in value.split(","):
        bits = part.strip().split()
        if not bits:
            continue
        url, w = bits[0], 0
        if len(bits) > 1:
            m = re.match(r"(\d+(?:\.\d+)?)([wx])", bits[1])
            if m:
                w = int(float(m.group(1)) * (1000 if m.group(2) == "x" else 1)) if m.group(2) == "w" else int(float(m.group(1)) * 400)
        if w <= 800 and w > best_w:
            best, best_w = url, w
        if w < smallest_w:
            smallest, smallest_w = url, w
    return best or smallest


def classify_video(url: str) -> Optional[str]:
    path = urlparse(url).path.lower()
    if path.endswith((".mp4", ".webm", ".mov", ".m4v")):
        return "direct"
    if path.endswith((".m3u8", ".mpd")):
        return "stream"
    return None


# ── HTML ───────────────────────────────────────────────────────────────────

def _img_src(tag, base: str) -> Optional[str]:
    for attr in LAZY_ATTRS:
        v = tag.get(attr)
        if v and not v.startswith("data:"):
            if " " in v.strip() and ("w," in v or "x," in v or v.strip().endswith(("w", "x"))):
                v = best_srcset(v) or v
            return clean(v.split()[0] if " " in v.strip() and "," not in v else v, base)
    for attr in ("data-srcset", "srcset"):
        v = tag.get(attr)
        if v:
            picked = best_srcset(v)
            if picked:
                return clean(picked, base)
    return clean(tag.get("src", ""), base)


def _walk_jsonld(node, out: list, page: str, depth: int = 0) -> None:
    if depth > 6:
        return
    if isinstance(node, list):
        for n in node:
            _walk_jsonld(n, out, page, depth + 1)
    elif isinstance(node, dict):
        types = node.get("@type")
        types = types if isinstance(types, list) else [types]
        if "VideoObject" in types or "ImageObject" in types or "Article" in types or "NewsArticle" in types or "BlogPosting" in types:
            out.append(node)
        for v in node.values():
            if isinstance(v, (dict, list)):
                _walk_jsonld(v, out, page, depth + 1)


def _jsonld(soup, base: str, res: Parsed) -> None:
    for script in soup.find_all("script", attrs={"type": re.compile("ld\\+json", re.I)}):
        try:
            data = json.loads(script.string or script.get_text() or "")
        except Exception:
            continue
        nodes: list = []
        _walk_jsonld(data, nodes, base)
        for n in nodes:
            title = n.get("name") or n.get("headline")
            page = clean(n.get("url") or "", base) or None
            vids = []
            for key, kind in (("contentUrl", None), ("embedUrl", "embed")):
                v = n.get(key)
                if isinstance(v, str):
                    u = clean(v, base)
                    if u:
                        vids.append(VideoRef(u, kind or classify_video(u) or "embed"))
            res.videos.extend(vids)
            imgs = []
            for key in ("thumbnailUrl", "thumbnail", "image"):
                v = n.get(key)
                vs = v if isinstance(v, list) else [v]
                for item in vs:
                    if isinstance(item, dict):
                        item = item.get("url") or item.get("contentUrl")
                    if isinstance(item, str):
                        u = clean(item, base)
                        if u and not is_junk(u):
                            imgs.append(u)
            for u in imgs:
                res.assets.append(Asset(u, page_url=page if page and page != base else None, title=title, source="jsonld", videos=list(vids)))


def parse_html(html: str, base: str) -> Parsed:
    soup = BeautifulSoup(html, _PARSER)
    res = Parsed()
    base_tag = soup.find("base", href=True)
    if base_tag:
        base = clean(base_tag["href"], base) or base
    if soup.title and soup.title.string:
        res.title = soup.title.string.strip()[:200]
    seen_tags: set[int] = set()
    seen_urls: set[str] = set()

    def add(asset: Optional[Asset]):
        if asset and asset.url not in seen_urls and not is_junk(asset.url):
            seen_urls.add(asset.url)
            res.assets.append(asset)

    # links + thumbnails wrapped in links (thumbnail -> content page)
    for a in soup.find_all("a", href=True):
        href = clean(a["href"], base)
        if not href:
            continue
        text = (a.get("title") or a.get_text(" ", strip=True) or "")[:140]
        wraps = False
        for media in a.find_all(["img", "video", "source"], limit=6):
            src = None
            if media.name == "img":
                src = _img_src(media, base)
                title = media.get("alt") or media.get("title") or text
            else:
                src = clean(media.get("poster") or media.get("data-poster") or "", base)
                title = text
            if src:
                seen_tags.add(id(media))
                wraps = True
                same = same_site(href, base)
                add(Asset(src, page_url=href if same and href.rstrip("/") != base.rstrip("/") else None, title=(title or None) and title[:140], source="html"))
        if same_site(href, base):
            res.links.append((href, text))

    for img in soup.find_all("img"):
        if id(img) in seen_tags:
            continue
        src = _img_src(img, base)
        if src:
            add(Asset(src, title=(img.get("alt") or img.get("title") or "")[:140] or None))
    for source in soup.select("picture source[srcset], picture source[data-srcset]"):
        picked = best_srcset(source.get("srcset") or source.get("data-srcset") or "")
        if picked:
            add(Asset(clean(picked, base) or "", source="html"))
    for video in soup.find_all("video"):
        poster = clean(video.get("poster") or video.get("data-poster") or "", base)
        if poster and id(video) not in seen_tags:
            add(Asset(poster, source="html"))
    css_blocks = [tag.get("style", "") for tag in soup.find_all(style=True)]
    css_blocks += [tag.get_text(" ", strip=False) for tag in soup.find_all("style")]
    for css in css_blocks:
        for m in re.finditer(r"url\(\s*['\"]?([^'\")]+)", css, re.I):
            u = clean(m.group(1).strip(), base)
            if u:
                add(Asset(u, source="css-background"))
    # Deep-inspection mode fetches these as CSS, then extracts their image URLs.
    for link in soup.find_all("link", href=True):
        rel = " ".join(link.get("rel", [])).lower()
        if "stylesheet" in rel:
            css_url = clean(link.get("href", ""), base)
            if css_url and css_url not in seen_urls:
                seen_urls.add(css_url)
                res.assets.append(Asset(css_url, source="stylesheet"))
    for ns in soup.find_all("noscript"):
        inner = ns.decode_contents() if ns.string is None else ns.string
        if inner and "<img" in inner:
            for img in BeautifulSoup(inner, _PARSER).find_all("img"):
                src = _img_src(img, base)
                if src:
                    add(Asset(src))

    # page-level metadata: the main image of THIS page
    for meta in soup.find_all("meta"):
        key = (meta.get("property") or meta.get("name") or meta.get("itemprop") or "").lower()
        val = meta.get("content") or ""
        if key in ("og:image", "og:image:url", "og:image:secure_url", "twitter:image", "twitter:image:src", "thumbnailurl", "image"):
            u = clean(val, base)
            if u:
                add(Asset(u, source="meta", title=res.title))
        elif key in ("og:video", "og:video:url", "og:video:secure_url", "twitter:player:stream", "contenturl"):
            u = clean(val, base)
            if u:
                res.videos.append(VideoRef(u, classify_video(u) or "embed"))
        elif key in ("twitter:player", "embedurl"):
            u = clean(val, base)
            if u:
                res.videos.append(VideoRef(u, "embed"))
    link_img = soup.find("link", rel=re.compile("image_src", re.I))
    if link_img and link_img.get("href"):
        u = clean(link_img["href"], base)
        if u:
            add(Asset(u, source="meta", title=res.title))
    for link in soup.find_all("link", attrs={"type": re.compile("rss|atom", re.I)}):
        u = clean(link.get("href", ""), base)
        if u:
            res.feeds.append(u)

    _jsonld(soup, base, res)
    for a in res.assets:
        if a.url in seen_urls or not is_junk(a.url):
            seen_urls.add(a.url)

    # video URLs
    for tag in soup.find_all(["video", "source"]):
        u = clean(tag.get("src") or tag.get("data-src") or "", base)
        if u and classify_video(u):
            res.videos.append(VideoRef(u, classify_video(u)))  # type: ignore[arg-type]
    for m in VIDEO_RE.finditer(html):
        u = clean(m.group(0), base)
        if u and classify_video(u):
            res.videos.append(VideoRef(u, classify_video(u)))  # type: ignore[arg-type]
    for iframe in soup.find_all("iframe"):
        u = clean(iframe.get("src") or iframe.get("data-src") or "", base)
        if u and not same_site(u, base) or (u and re.search(r"embed|player|video", u, re.I)):
            res.videos.append(VideoRef(u, "embed"))  # type: ignore[arg-type]
    res.videos = _dedupe_videos(res.videos)
    return res


def _dedupe_videos(videos: Iterable[VideoRef]) -> list:
    order = {"direct": 0, "stream": 1, "embed": 2}
    seen, out = set(), []
    for v in sorted(videos, key=lambda v: order.get(v.kind, 3)):
        if v.url not in seen:
            seen.add(v.url)
            out.append(v)
    return out


def score_link(url: str, text: str = "") -> int:
    """Higher = more likely to lead to content or more listings. Negative = skip."""
    parsed = urlparse(url)
    low = (parsed.path + ("?" + parsed.query if parsed.query else "")).lower()
    if any(s in low for s in SKIP_PATH) or re.search(r"\.(jpg|jpeg|png|gif|webp|pdf|zip|css|js|mp4)$", low):
        return -1
    score = 0
    if any(k in low for k in CONTENT_WORDS):
        score += 3
    if PAGINATION_RE.search(low):
        score += 2
    if any(k in low for k in LISTING_WORDS):
        score += 1
    last = low.rstrip("/").rsplit("/", 1)[-1]
    if "-" in last and len(last) > 14:
        score += 2                                   # looks like a content slug
    if re.search(r"\d{3,}", last):
        score += 1
    if len((text or "").strip()) > 12:
        score += 1
    return score


def next_links(html_links: list, base: str) -> list:
    return [u for u, t in html_links if PAGINATION_RE.search(urlparse(u).path + "?" + urlparse(u).query)
            or (t or "").strip().lower() in ("next", "next »", "»", "›", "older", "older posts", ">")]


# ── Sitemaps ───────────────────────────────────────────────────────────────

def decode_xml(content: bytes) -> str:
    if content[:2] == b"\x1f\x8b":
        try:
            content = gzip.decompress(content)[: 16 * 1024 * 1024]
        except Exception:
            return ""
    for enc in ("utf-8", "latin-1"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    return ""


def _tag(block: str, name: str) -> list[str]:
    return [htmllib.unescape(re.sub(r"<!\[CDATA\[|\]\]>", "", m)).strip()
            for m in re.findall(rf"<{name}[^>]*>(.*?)</{name}>", block, re.S | re.I)]


@dataclass
class SitemapEntry:
    loc: str
    lastmod: str = ""
    title: Optional[str] = None
    images: list = field(default_factory=list)
    videos: list = field(default_factory=list)


def parse_sitemap(text: str, base: str) -> tuple[list, list]:
    """-> (child sitemap urls with lastmod, page entries)."""
    children, entries = [], []
    for block in re.findall(r"<sitemap>(.*?)</sitemap>", text, re.S | re.I):
        loc = (_tag(block, "loc") or [""])[0]
        if loc:
            children.append((clean(loc, base) or loc, (_tag(block, "lastmod") or [""])[0]))
    for block in re.findall(r"<url>(.*?)</url>", text, re.S | re.I):
        loc = (_tag(block, "loc") or [""])[0]
        if not loc:
            continue
        e = SitemapEntry(clean(loc, base) or loc, (_tag(block, "lastmod") or [""])[0])
        for img in _tag(block, "image:loc"):
            u = clean(img, base)
            if u and not is_junk(u):
                e.images.append(u)
        titles = _tag(block, "video:title") or _tag(block, "image:title")
        e.title = titles[0][:140] if titles else None
        for thumb in _tag(block, "video:thumbnail_loc"):
            u = clean(thumb, base)
            if u and not is_junk(u):
                e.images.append(u)
        for tagname, kind in (("video:content_loc", None), ("video:player_loc", "embed")):
            for v in _tag(block, tagname):
                u = clean(v, base)
                if u:
                    e.videos.append(VideoRef(u, kind or classify_video(u) or "embed"))
        entries.append(e)
    return children, entries


# ── RSS / Atom ─────────────────────────────────────────────────────────────

def parse_feed(text: str, base: str) -> list:
    assets = []
    for block in re.findall(r"<(?:item|entry)[ >](.*?)</(?:item|entry)>", text, re.S | re.I):
        link = (_tag(block, "link") or [""])[0]
        if not link:
            m = re.search(r"<link[^>]+href=[\"']([^\"']+)", block, re.I)
            link = m.group(1) if m else ""
        page = clean(link, base) or None
        title = (_tag(block, "title") or [None])[0]
        urls = re.findall(r"<(?:media:thumbnail|media:content|enclosure)[^>]+url=[\"']([^\"']+)", block, re.I)
        vids = []
        for body in _tag(block, "description") + _tag(block, "content:encoded") + _tag(block, "content") + _tag(block, "summary"):
            if "<" in body:
                inner = parse_html(body, page or base)
                urls.extend(a.url for a in inner.assets)
                vids.extend(inner.videos)
        for u in urls:
            absu = clean(u, base)
            if not absu:
                continue
            kind = classify_video(absu)
            if kind:
                vids.append(VideoRef(absu, kind))
            elif not is_junk(absu):
                assets.append(Asset(absu, page_url=page, title=title[:140] if title else None, source="rss", videos=_dedupe_videos(vids)))
    return assets


# ── WordPress REST ─────────────────────────────────────────────────────────

def parse_wp_posts(data, base: str) -> list:
    assets = []
    if not isinstance(data, list):
        return assets
    for post in data:
        if not isinstance(post, dict):
            continue
        link = clean(post.get("link", ""), base)
        title = (post.get("title") or {}).get("rendered") if isinstance(post.get("title"), dict) else None
        title = re.sub(r"<[^>]+>", "", htmllib.unescape(title))[:140] if title else None
        vids = []
        urls = []
        media = ((post.get("_embedded") or {}).get("wp:featuredmedia") or [])
        for m in media:
            if isinstance(m, dict):
                sizes = ((m.get("media_details") or {}).get("sizes") or {})
                pick = sizes.get("medium_large") or sizes.get("large") or sizes.get("medium") or {}
                u = pick.get("source_url") or m.get("source_url")
                if u:
                    urls.append(u)
        content = (post.get("content") or {}).get("rendered") if isinstance(post.get("content"), dict) else ""
        if content:
            inner = parse_html(content, link or base)
            urls.extend(a.url for a in inner.assets)
            vids.extend(inner.videos)
        for u in urls:
            absu = clean(u, base)
            if absu and not is_junk(absu):
                assets.append(Asset(absu, page_url=link, title=title, source="wp", videos=_dedupe_videos(vids)))
    return assets
