"""
Image fingerprinting and matching.  Pure computation: no network, no web framework.

Why this finds more than a single-hash comparison
-------------------------------------------------
Leaked images are rarely byte-identical.  They are resized, recompressed, cropped,
letter-boxed, mirrored, watermarked, colour-graded or stretched.  So matching is done
in two tiers, cheapest first, and each tier is built to survive a different edit:

 Tier 1 - perceptual hashes (pHash + dHash + aHash, 64-bit each, compared by Hamming
          distance) against many *variants* of both sides:
            reference : original, mirrored, centre crops, and a grid of sub-windows
            candidate : full image, border-trimmed (removes letterbox bars), sub-windows
          This catches resize / recompress / brightness / mirror / crop either way round.

 Tier 2 - local features: RootSIFT keypoints, Lowe ratio test, RANSAC similarity
          transform.  Matches must agree on ONE geometric transform, and must be spread
          over the image (so a shared watermark or logo cannot cause a false match).
          Catches heavy crops, rotation, stretching, overlays, screenshots.
"""
from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Optional

import cv2
import imagehash
import numpy as np
from PIL import Image, ImageOps

cv2.setNumThreads(1)              # we parallelise across candidates instead
Image.MAX_IMAGE_PIXELS = 60_000_000

MIN_SIDE = 40                      # ignore icons / tracking pixels
FLAT_STD = 9.0                     # ignore blank / near-black frames (they all hash alike)

# ── Tier 1 thresholds ──────────────────────────────────────────────────────
HASH_AVG_MAX = 6.0                 # mean Hamming distance of the 3 hashes
HASH_PHASH_MAX = 9                 # and pHash alone must be close too
WINDOW_SCALES = (0.75, 0.5)

# ── Tier 2 thresholds ──────────────────────────────────────────────────────
SIFT_FEATURES = 1000
RATIO = 0.78
RANSAC_PX = 5.0
SCALE_RANGE = (0.12, 8.0)
MIN_GOOD = 8
STRUCTURAL_INLIERS = 14
PROBABLE_INLIERS = 9
MIN_INLIER_RATIO = 0.22
MIN_SPREAD = 0.045                 # inlier convex-hull area / image area (on the better side)


# ── Image helpers ──────────────────────────────────────────────────────────

def open_image(data: bytes) -> Optional[Image.Image]:
    try:
        img = Image.open(io.BytesIO(data))
        if img.width * img.height > 60_000_000:
            return None
        img = ImageOps.exif_transpose(img)
        if getattr(img, "is_animated", False):
            img.seek(0)
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGBA")
            bg = Image.new("RGB", img.size, (0, 0, 0))
            bg.paste(img, mask=img.split()[-1])
            return bg
        return img.convert("RGB")
    except Exception:
        return None


def is_flat(img: Image.Image) -> bool:
    small = np.asarray(img.convert("L").resize((48, 48)), dtype=np.float32)
    return float(small.std()) < FLAT_STD


def trim_borders(img: Image.Image) -> Optional[Image.Image]:
    """Remove solid black/white bars (letter-boxing, screenshots).  None if nothing to trim."""
    g = np.asarray(img.convert("L"), dtype=np.uint8)
    h, w = g.shape

    def solid(line: np.ndarray) -> bool:
        return line.max() < 28 or line.min() > 228 or line.std() < 3.0

    top = 0
    while top < h // 3 and solid(g[top]):
        top += 1
    bottom = h
    while bottom > h - h // 3 and solid(g[bottom - 1]):
        bottom -= 1
    left = 0
    while left < w // 3 and solid(g[:, left]):
        left += 1
    right = w
    while right > w - w // 3 and solid(g[:, right - 1]):
        right -= 1
    if (right - left) * (bottom - top) > 0.96 * w * h or right - left < MIN_SIDE or bottom - top < MIN_SIDE:
        return None
    return img.crop((left, top, right, bottom))


def center_crop(img: Image.Image, ratio: float) -> Image.Image:
    w, h = img.size
    if w / h > ratio:
        nw = int(h * ratio)
        x = (w - nw) // 2
        return img.crop((x, 0, x + nw, h))
    nh = int(w / ratio)
    y = (h - nh) // 2
    return img.crop((0, y, w, y + nh))


def windows(img: Image.Image) -> list[tuple[str, Image.Image]]:
    """Overlapping sub-windows (3x3 grid at each scale) - makes hashing crop-resistant."""
    w, h = img.size
    out = []
    for s in WINDOW_SCALES:
        ww, hh = int(w * s), int(h * s)
        if ww < MIN_SIDE or hh < MIN_SIDE:
            continue
        for iy in range(3):
            for ix in range(3):
                x = int((w - ww) * ix / 2)
                y = int((h - hh) * iy / 2)
                out.append((f"window_{s}@{ix}{iy}", img.crop((x, y, x + ww, y + hh))))
    return out


# ── Hashing ────────────────────────────────────────────────────────────────

def _int_hash(h: imagehash.ImageHash) -> int:
    value = 0
    for bit in h.hash.flatten():
        value = (value << 1) | int(bit)
    return value


def hashes(img: Image.Image) -> tuple[int, int, int]:
    return (_int_hash(imagehash.phash(img)), _int_hash(imagehash.dhash(img)), _int_hash(imagehash.average_hash(img)))


def _dist(a: tuple[int, int, int], b: tuple[int, int, int]) -> tuple[int, int, int]:
    return ((a[0] ^ b[0]).bit_count(), (a[1] ^ b[1]).bit_count(), (a[2] ^ b[2]).bit_count())


# ── Local features ─────────────────────────────────────────────────────────

@dataclass
class Features:
    points: np.ndarray          # (N,2) in normalised coordinates
    descriptors: np.ndarray     # (N,128) RootSIFT
    size: tuple[int, int]       # normalised (w,h)


def _normalise(gray: np.ndarray, small_up: bool) -> np.ndarray:
    h, w = gray.shape[:2]
    longest = max(h, w)
    target = 640 if longest > 640 else (320 if small_up and longest < 320 else None)
    if target:
        scale = target / longest
        scale = min(scale, 3.0)
        interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
        gray = cv2.resize(gray, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=interp)
    return cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)


def extract_features(img: Image.Image, small_up: bool = True) -> Optional[Features]:
    try:
        gray = _normalise(np.asarray(img.convert("L"), dtype=np.uint8), small_up)
        sift = cv2.SIFT_create(nfeatures=SIFT_FEATURES, contrastThreshold=0.03)
        kps, des = sift.detectAndCompute(gray, None)
        if des is None or len(kps) < 8:
            return None
        des = des.astype(np.float32)
        des /= des.sum(axis=1, keepdims=True) + 1e-7      # RootSIFT: L1-normalise ...
        des = np.sqrt(des)                                 # ... then square-root (Hellinger kernel)
        pts = np.float32([k.pt for k in kps])
        return Features(points=pts, descriptors=des, size=(gray.shape[1], gray.shape[0]))
    except cv2.error:
        return None


def _hull_fraction(points: np.ndarray, size: tuple[int, int]) -> float:
    if len(points) < 3:
        return 0.0
    hull = cv2.convexHull(points.astype(np.float32))
    return float(cv2.contourArea(hull)) / float(size[0] * size[1])


@dataclass
class Geo:
    inliers: int = 0
    good: int = 0
    ratio: float = 0.0
    spread: float = 0.0
    scale: float = 1.0
    kps: int = 0


def geometric_match(ref: Optional[Features], cand: Optional[Features]) -> Geo:
    if ref is None or cand is None:
        return Geo()
    try:
        pairs = cv2.BFMatcher(cv2.NORM_L2).knnMatch(ref.descriptors, cand.descriptors, k=2)
        good = [m for m, n in (p for p in pairs if len(p) == 2) if m.distance < RATIO * n.distance]
        # keep only mutual best matches: a match both sides agree on is far less likely random
        back = cv2.BFMatcher(cv2.NORM_L2).match(cand.descriptors, ref.descriptors)
        best_back = {m.queryIdx: m.trainIdx for m in back}
        good = [m for m in good if best_back.get(m.trainIdx) == m.queryIdx]
        if len(good) < MIN_GOOD:
            return Geo(good=len(good), kps=len(cand.points))
        src = np.float32([ref.points[m.queryIdx] for m in good]).reshape(-1, 1, 2)
        dst = np.float32([cand.points[m.trainIdx] for m in good]).reshape(-1, 1, 2)
        matrix, mask = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=RANSAC_PX)
        if matrix is None or mask is None:
            return Geo(good=len(good), kps=len(cand.points))
        scale = float(np.sqrt(abs(np.linalg.det(matrix[:, :2]))))
        if not (SCALE_RANGE[0] <= scale <= SCALE_RANGE[1]):
            return Geo(good=len(good), kps=len(cand.points))
        keep = mask.ravel().astype(bool)
        inliers = int(keep.sum())
        spread = max(_hull_fraction(src[keep].reshape(-1, 2), ref.size), _hull_fraction(dst[keep].reshape(-1, 2), cand.size))
        return Geo(inliers=inliers, good=len(good), ratio=inliers / len(good), spread=spread, scale=scale, kps=len(cand.points))
    except cv2.error:
        return Geo()


# ── Reference ──────────────────────────────────────────────────────────────

@dataclass
class Reference:
    full: dict[str, tuple[int, int, int]]          # variant name -> hashes of the whole variant
    windows: dict[str, tuple[int, int, int]]       # sub-window name -> hashes
    features: dict[str, Optional[Features]]        # "original" | "mirrored"
    image: Image.Image
    size: tuple[int, int] = (0, 0)


def build_reference(data: bytes) -> Reference:
    base = open_image(data)
    if base is None or min(base.size) < MIN_SIDE:
        raise ValueError("The file could not be read as a usable image.")
    if max(base.size) > 1600:
        scale = 1600 / max(base.size)
        base = base.resize((int(base.width * scale), int(base.height * scale)), Image.LANCZOS)
    mirror = ImageOps.mirror(base)
    variants: dict[str, Image.Image] = {"original": base, "mirrored": mirror}
    aspect = base.width / base.height
    for name, ratio in (("crop_16x9", 16 / 9), ("crop_4x3", 4 / 3), ("crop_1x1", 1.0), ("crop_9x16", 9 / 16), ("crop_3x4", 3 / 4)):
        if abs(aspect - ratio) / ratio > 0.05:
            variants[name] = center_crop(base, ratio)
    trimmed = trim_borders(base)
    if trimmed is not None:
        variants["trimmed"] = trimmed
    full = {name: hashes(img) for name, img in variants.items()}
    wins = {}
    for src_name, src in (("original", base), ("mirrored", mirror)):
        for wname, wimg in windows(src):
            wins[f"{src_name}:{wname}"] = hashes(wimg)
    feats = {"original": extract_features(base, small_up=False), "mirrored": extract_features(mirror, small_up=False)}
    return Reference(full=full, windows=wins, features=feats, image=base, size=base.size)


# ── Comparison ─────────────────────────────────────────────────────────────

@dataclass
class Outcome:
    match_type: str            # exact | near_duplicate | structural | probable
    confidence: float
    method: str                # hash | geometric
    variant: str
    inliers: int = 0
    inlier_ratio: float = 0.0
    spread: float = 0.0
    distances: tuple = (64, 64, 64)


def _hash_stage(ref: Reference, cand_full: tuple, cand_wins: dict, cand_trim: Optional[tuple]) -> Optional[Outcome]:
    best: Optional[tuple[float, str, tuple]] = None

    def consider(label: str, a: tuple, b: tuple):
        nonlocal best
        d = _dist(a, b)
        avg = sum(d) / 3
        if avg <= HASH_AVG_MAX and d[0] <= HASH_PHASH_MAX and (best is None or avg < best[0]):
            best = (avg, label, d)

    for name, rh in ref.full.items():
        consider(name, rh, cand_full)
        if cand_trim is not None:
            consider(f"{name}+trimmed", rh, cand_trim)
    # candidate is a CROP of the reference  -> compare candidate to reference windows
    for name, rh in ref.windows.items():
        consider(f"ref_{name}", rh, cand_full)
    # reference is a CROP of the candidate  -> compare reference to candidate windows
    for name, ch in cand_wins.items():
        consider(f"cand_{name}", ref.full["original"], ch)
        consider(f"cand_{name}:mirrored", ref.full["mirrored"], ch)

    if best is None:
        return None
    avg, label, d = best
    kind = "exact" if label in ("original", "original+trimmed") else "near_duplicate"
    return Outcome(kind, min(round((1 - avg / 16.0) * 100, 1), 99.0), "hash", label, distances=d)


def compare(ref: Reference, cand: Image.Image, candidate_full: Optional[tuple] = None) -> Optional[Outcome]:
    """Compare one candidate image against the reference. None = not a match."""
    if min(cand.size) < MIN_SIDE or is_flat(cand):
        return None
    cand_full = candidate_full if candidate_full is not None else hashes(cand)
    trimmed = trim_borders(cand)
    cand_trim = hashes(trimmed) if trimmed is not None and not is_flat(trimmed) else None
    cand_wins = {n: hashes(w) for n, w in windows(cand)}

    out = _hash_stage(ref, cand_full, cand_wins, cand_trim)
    if out is not None:
        return out

    feats = extract_features(trimmed if trimmed is not None else cand, small_up=True)
    results = {name: geometric_match(rf, feats) for name, rf in ref.features.items()}
    variant = max(results, key=lambda n: results[n].inliers)
    g = results[variant]
    if g.inliers < PROBABLE_INLIERS or g.ratio < MIN_INLIER_RATIO or g.spread < MIN_SPREAD:
        return None
    common = dict(method="geometric", variant=variant, inliers=g.inliers, inlier_ratio=round(g.ratio, 3), spread=round(g.spread, 3))
    if g.inliers >= STRUCTURAL_INLIERS:
        return Outcome("structural", min(round(70 + min(g.inliers, 60) / 60 * 25, 1), 95.0), **common)
    return Outcome("probable", min(round(40 + g.inliers * 2.5, 1), 69.0), **common)
