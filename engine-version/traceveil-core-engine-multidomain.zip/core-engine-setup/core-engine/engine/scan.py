"""
Scan orchestrator:  reference -> crawl (pass 1) -> adaptive deepening (pass 2) -> refine -> contacts.

Why it finds more than a one-shot crawl
---------------------------------------
* Pass 1 gives every domain a normal budget, pulling candidates from sitemaps / WP API / feeds / pages.
* Pass 2 ADAPTS: a domain that matched gets a big extra budget, the matched content page is crawled
  first (its "related videos" are where re-uploads cluster), and sister sites on the same network or
  video CDN are searched deeper too.
* Refine opens each matched page, collects its video URLs and title, and re-tests the page's own main
  image (og:image / poster).  A second, independent image agreeing upgrades the match to "verified".
"""
from __future__ import annotations

import asyncio
import time
import uuid
import hashlib
import json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional

from . import config
from .contacts import IGNORED_PROVIDERS, Contacts, load_rows, norm_domain
from .crawler import Batch, DomainCrawler
from .extract import Asset, VideoRef, _dedupe_videos, parse_html
from .fingerprint import Outcome, Reference, build_reference, compare, hashes, open_image
from .http import Http
from .notice import build_notice

STRONG = ("exact", "near_duplicate", "structural")


def _compare_bytes(ref: Reference, data: bytes):
    img = open_image(data)
    if img is None:
        return None
    values = hashes(img)
    out = compare(ref, img, values)
    hash_text = {"pHash": f"{values[0]:016x}", "dHash": f"{values[1]:016x}", "aHash": f"{values[2]:016x}"}
    return out, img.size, hash_text


def _tier(row: dict) -> str:
    kind = (row.get("provider_type") or "").strip().lower()
    if any(x in kind for x in ("self_or_private", "direct_cdn")):
        return "tier1"
    if any(x in kind for x in ("embedded", "external_cdn")):
        return "tier2"
    return "tier3"


def _tier_limits(row: dict) -> tuple[int, int]:
    return {"tier1": (200, 1000), "tier2": (100, 500), "tier3": (50, 200)}[_tier(row)]


@dataclass
class State:
    reference: Reference
    http: Http
    pool: ThreadPoolExecutor
    progress: Optional[Callable[[dict], None]]
    cancel: asyncio.Event
    deadline: float
    seen: set = field(default_factory=set)
    matches: list = field(default_factory=list)
    dom: dict = field(default_factory=dict)
    candidates: int = 0
    domains_done: int = 0
    domains_total: int = 0
    events: list = field(default_factory=list)
    phase: str = "starting"
    truncated: Optional[str] = None
    output_dir: Optional[Path] = None
    event_path: Optional[Path] = None
    candidate_path: Optional[Path] = None
    discovered_path: Optional[Path] = None
    discovered_seen: set = field(default_factory=set)
    cache: object = None
    ref_key: str = ""
    cache_hits: int = 0
    cache_misses: int = 0
    pages_total: int = 0
    images_downloaded: int = 0
    images_compared: int = 0
    pending_assets: dict = field(default_factory=dict)
    sha_urls: dict = field(default_factory=dict)

    def expired(self) -> bool:
        if self.cancel.is_set():
            self.truncated = self.truncated or "cancelled"
            return True
        if time.monotonic() > self.deadline:
            self.truncated = self.truncated or "time limit reached"
            return True
        return False

    def take(self, n: int) -> int:
        room = max(0, config.MAX_CANDIDATES - self.candidates)
        if room < n:
            self.truncated = self.truncated or "candidate limit reached"
        got = min(n, room)
        self.candidates += got
        return got

    def event(self, msg: str, stage: str = "ENGINE", domain: Optional[str] = None, **extra) -> None:
        item = {"t": round(time.time(), 3), "stage": stage, "msg": msg}
        if domain:
            item["domain"] = domain
        item.update(extra)
        self.events.append(item)
        del self.events[:-150]
        if self.event_path:
            with self.event_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\\n")
        self.push()

    def push(self) -> None:
        if self.progress:
            self.progress({
                "phase": self.phase, "candidates": self.candidates, "matches": len(self.matches),
                "domains_done": self.domains_done, "domains_total": self.domains_total,
                "pages": self.pages_total, "images_downloaded": self.images_downloaded,
                "images_compared": self.images_compared, "cache_hits": self.cache_hits,
                "events": list(self.events[-30:]),
                "domains": {d: {k: v for k, v in stats.items() if k != "candidate_limit"}
                            for d, stats in self.dom.items()},
            })



class Scanner:
    def __init__(self, rows: Optional[list] = None, contacts: Optional[Contacts] = None):
        self.rows = rows if rows is not None else load_rows()
        self.contacts = contacts or Contacts()

    # ── public ─────────────────────────────────────────────────────────────
    async def scan(self, image_bytes: bytes, *, domains: Optional[list] = None,
                   progress: Optional[Callable[[dict], None]] = None,
                   cancel: Optional[asyncio.Event] = None,
                   output_dir: Optional[str | Path] = None) -> dict:
        started = time.time()
        loop = asyncio.get_running_loop()
        pool = ThreadPoolExecutor(max_workers=config.CPU_WORKERS)
        http = Http()
        cache = None
        try:
            reference = await loop.run_in_executor(pool, build_reference, image_bytes)
            rows = self._select(domains)
            outdir = Path(output_dir) if output_dir else None
            if outdir:
                outdir.mkdir(parents=True, exist_ok=True)
                for name in ("events.jsonl", "candidates.jsonl", "discovered-assets.jsonl"):
                    (outdir / name).write_text("", encoding="utf-8")
                ref_hashes = reference.full["original"]
                (outdir / "reference-fingerprints.json").write_text(json.dumps({
                    "width": reference.size[0], "height": reference.size[1],
                    "hashes": dict(zip(("pHash", "dHash", "aHash"), [f"{v:016x}" for v in ref_hashes])),
                    "variants": {k: [f"{v:016x}" for v in vals] for k, vals in reference.full.items()},
                }, indent=2), encoding="utf-8")
            from .cache import FingerprintCache
            cache = FingerprintCache(config.ROOT / "data" / "fingerprint-cache.sqlite3")
            st = State(reference, http, pool, progress, cancel or asyncio.Event(),
                       time.monotonic() + config.SCAN_TIMEOUT, domains_total=len(rows))
            st.output_dir = outdir
            st.event_path = outdir / "events.jsonl" if outdir else None
            st.candidate_path = outdir / "candidates.jsonl" if outdir else None
            st.discovered_path = outdir / "discovered-assets.jsonl" if outdir else None
            st.cache = cache
            st.ref_key = hashlib.sha256(image_bytes).hexdigest()
            st.dom = {
                r["domain"]: {
                    "candidates": 0, "skipped": 0, "img_fail": 0, "pages": 0,
                    "matches": 0, "unique_images": 0, "candidate_limit": config.INITIAL_CANDIDATES_PER_DOMAIN,
                    "tier": _tier(r), "errors": 0,
                } for r in rows
            }
            crawlers = {r["domain"]: DomainCrawler(r["domain"], http) for r in rows}
            by_domain = {r["domain"]: r for r in rows}

            st.phase = "quick_discovery"
            st.event(f"Pass 1: quick discovery across all {len(rows)} configured domains", "SCHEDULER")
            await self._run_pass(st, [(r, config.PAGES_PER_DOMAIN) for r in rows], crawlers)

            related = []
            if not st.expired():
                st.phase = "adaptive_deepening"
                matched = {m["domain"] for m in st.matches}
                related = self._related(matched, rows)
                ranked = sorted(
                    rows,
                    key=lambda r: (
                        st.dom[r["domain"]]["candidates"] / max(1, st.dom[r["domain"]]["pages"]),
                        st.dom[r["domain"]]["candidates"],
                    ),
                    reverse=True,
                )
                high_yield = {
                    r["domain"] for r in ranked[:max(5, min(20, len(rows) // 4))]
                    if st.dom[r["domain"]]["candidates"] >= 10
                }
                expand = matched | set(related) | high_yield
                plan = []
                for d in expand:
                    if d not in by_domain:
                        continue
                    row = by_domain[d]
                    max_pages, max_images = _tier_limits(row)
                    page_extra = min(config.BONUS_PAGES, max(0, max_pages - crawlers[d].pages_fetched))
                    if page_extra <= 0:
                        continue
                    st.dom[d]["candidate_limit"] = max_images
                    for match in st.matches:
                        if match["domain"] == d and match["page_specific"] and match["page_url"]:
                            crawlers[d].enqueue(match["page_url"], 100)
                    plan.append((row, page_extra))
                if plan:
                    st.event(
                        f"Pass 2: adaptive deepening for {len(plan)} domains "
                        f"({len(matched)} matched, {len(related)} related, {len(high_yield)} high-yield)",
                        "SCHEDULER",
                    )
                    st.domains_done = 0
                    st.domains_total = len(plan)
                    # Revisit candidates held back by the initial per-domain budget.
                    for row, _budget in plan:
                        domain = row["domain"]
                        held = st.pending_assets.pop(domain, [])
                        for held_batch, held_asset in held:
                            await self._process(
                                st, row, crawlers[domain],
                                Batch(domain, held_batch.source, held_batch.page_url, [held_asset],
                                      held_batch.videos, held_batch.title, held_batch.depth),
                            )
                    await self._run_pass(st, plan, crawlers)

            matches = self._consolidate(st.matches)
            st.phase = "verifying"
            st.event(f"Verifying {min(len(matches), 25)} match(es) on their pages", "VERIFICATION")
            await asyncio.gather(*[self._refine(st, m) for m in matches[:25]], return_exceptions=True)
            matches = self._consolidate(matches)

            st.phase = "contacts"
            domains_hit = list(dict.fromkeys(m["domain"] for m in matches))
            contacts = {}
            infos = await asyncio.gather(*[
                self.contacts.lookup(d, http, base_url=(crawlers[d].base if d in crawlers else None))
                for d in domains_hit
            ], return_exceptions=True)
            for d, info in zip(domains_hit, infos):
                contacts[d] = info if isinstance(info, dict) else self.contacts.static(d)
            for match in matches:
                match["contact"] = contacts.get(match["domain"])
            notices = [
                build_notice(d, [m for m in matches if m["domain"] == d], contacts[d])
                for d in domains_hit
            ]

            st.phase = "done"
            st.push()
            coverage = self._coverage(st, crawlers)
            result = {
                "status": "completed",
                "duration_s": round(time.time() - started, 1),
                "reference": {"width": reference.size[0], "height": reference.size[1]},
                "matches": matches,
                "notices": notices,
                "related_domains": related,
                "coverage": coverage,
                "stats": {
                    "candidates_queued": st.candidates, "candidates_compared": st.images_compared,
                    "images_downloaded": st.images_downloaded, "requests": http.requests,
                    "domains": len(rows), "pages": st.pages_total,
                    "cache_hits": st.cache_hits, "cache_misses": st.cache_misses,
                    "truncated": st.truncated,
                },
                "artifacts": str(outdir) if outdir else None,
            }
            if outdir:
                (outdir / "matches.json").write_text(json.dumps(matches, indent=2, ensure_ascii=False), encoding="utf-8")
                (outdir / "domains.json").write_text(json.dumps(coverage["domains"], indent=2, ensure_ascii=False), encoding="utf-8")
                (outdir / "scan-summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
            return result
        finally:
            await http.close()
            if cache:
                cache.close()
            pool.shutdown(wait=False, cancel_futures=True)

    # ── internals ──────────────────────────────────────────────────────────
    def _select(self, domains: Optional[list]) -> list:
        if not domains:
            return list(self.rows)
        wanted = [norm_domain(d) if ":" not in d else d.strip().lower() for d in domains if d.strip()]
        known = {r["domain"]: r for r in self.rows}
        return [known.get(d, {"domain": d, "network": "", "provider_type": "", "video_provider": ""}) for d in wanted]

    def _related(self, matched: set, rows: list) -> list:
        nets = {r.get("network") for r in rows if r["domain"] in matched and r.get("network") not in (None, "", "UnknownNetwork")}
        vids = {r.get("video_provider") for r in rows if r["domain"] in matched and (r.get("video_provider") or "").lower() not in IGNORED_PROVIDERS}
        return [r["domain"] for r in rows if r["domain"] not in matched and (r.get("network") in nets or r.get("video_provider") in vids)]

    async def _run_pass(self, st: State, plan: list, crawlers: dict) -> None:
        domain_slots = asyncio.Semaphore(max(1, config.CONCURRENT_DOMAINS))

        async def one(row: dict, budget: int) -> None:
            c = crawlers[row["domain"]]
            domain = row["domain"]
            async with domain_slots:
                try:
                    async for batch in c.batches(budget):
                        if st.expired():
                            break
                        if batch.source in ("home", "page"):
                            if st.pages_total >= config.MAX_TOTAL_PAGES:
                                st.truncated = st.truncated or "global page limit reached"
                                break
                            st.pages_total += 1
                            st.dom[domain]["pages"] = c.pages_fetched
                            st.event(f"Crawling page (depth {batch.depth}): {batch.page_url}", "PAGE_CRAWLING", domain=domain,
                                     url=batch.page_url, source=batch.source, depth=batch.depth)
                        elif batch.source in ("sitemap", "wp", "rss"):
                            st.event(f"Structured discovery: {batch.page_url}", "STRUCTURED_DISCOVERY",
                                     domain=domain, url=batch.page_url, source=batch.source)
                        await self._process(st, row, c, batch)
                except Exception as exc:  # one bad site must never stop the scan
                    st.dom[domain]["errors"] += 1
                    st.event(f"{domain}: {type(exc).__name__}", "DOMAIN_ERROR", domain=domain)
                finally:
                    st.dom[domain]["pages"] = c.pages_fetched
                    st.domains_done += 1
                    st.push()

        await asyncio.gather(*[one(r, b) for r, b in plan])

    async def _process(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch) -> None:
        domain = row["domain"]
        # Expand externally hosted CSS stylesheets into their directly referenced image URLs.
        assets: list[Asset] = []
        for asset in batch.assets:
            if asset.source != "stylesheet":
                assets.append(asset)
                continue
            css = await st.http.get(asset.url, max_bytes=config.MAX_CSS_BYTES, referer=batch.page_url)
            if not css.ok:
                st.event(f"Stylesheet unavailable: {asset.url} ({css.reason})", "CSS_ERROR", domain=domain)
                continue
            import re
            from urllib.parse import urljoin
            for match in re.finditer(r"url\\(\\s*['\\\"]?([^'\\\")]+)", css.text(), re.I):
                image_url = urljoin(asset.url, match.group(1).strip())
                if image_url.startswith(("http://", "https://")):
                    assets.append(Asset(image_url, page_url=batch.page_url, source="css-background", title=batch.title))

        # Preserve every discovered image URL, even when budgets defer its download.
        if st.discovered_path:
            with st.discovered_path.open("a", encoding="utf-8") as fh:
                for asset in assets:
                    discovered_key = f"{domain}|{asset.url}"
                    if asset.url and discovered_key not in st.discovered_seen:
                        st.discovered_seen.add(discovered_key)
                        fh.write(json.dumps({
                            "domain": domain, "page_url": asset.page_url or batch.page_url,
                            "discovered_on": batch.page_url, "asset_url": asset.url,
                            "source": asset.source, "title": asset.title or batch.title,
                            "state": "discovered",
                        }, ensure_ascii=False, separators=(",", ":")) + "\\n")

        cap = config.STRUCTURED_ASSETS if batch.source in ("sitemap", "wp", "rss") else config.ASSETS_PER_PAGE
        fresh: list[Asset] = []
        local_keys = set()
        for asset in assets:
            key = f"{domain}|{asset.url}"
            if asset.url and key not in st.seen and key not in local_keys:
                local_keys.add(key)
                fresh.append(asset)
        page_overflow = fresh[cap:]
        fresh = fresh[:cap]
        domain_room = max(0, st.dom[domain]["candidate_limit"] - st.dom[domain]["candidates"])
        global_room = max(0, config.MAX_CANDIDATES - st.candidates)
        got = min(len(fresh), domain_room, global_room)
        if got < len(fresh):
            st.dom[domain]["skipped"] += len(fresh) - got
            if global_room <= 0:
                st.truncated = st.truncated or "global candidate limit reached"
        # Preserve domain-budget overflow for the adaptive pass instead of losing it.
        held = fresh[got:] + page_overflow
        if held and global_room > 0:
            st.pending_assets.setdefault(domain, []).extend((batch, item) for item in held)
        fresh = fresh[:got]
        for asset in fresh:
            st.seen.add(f"{domain}|{asset.url}")
        if not fresh:
            return
        st.dom[domain]["candidates"] += len(fresh)
        st.candidates += len(fresh)
        st.event(f"{domain}: queued {len(fresh)} image candidates from {batch.page_url}", "IMAGE_DISCOVERY", domain=domain)
        # Bounded batches prevent thousands of coroutine objects from accumulating.
        for offset in range(0, len(fresh), 20):
            group = fresh[offset:offset + 20]
            await asyncio.gather(*[
                self._evaluate(st, row, crawler, batch, asset) for asset in group
            ], return_exceptions=True)
        st.push()

    async def _evaluate(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch, asset: Asset) -> None:
        domain = row["domain"]
        page_url = asset.page_url or batch.page_url
        record = {
            "domain": domain, "page_url": page_url, "discovered_on": batch.page_url,
            "asset_url": asset.url, "source": asset.source, "title": asset.title or batch.title,
            "status": "pending",
        }
        f = await st.http.image(asset.url, referer=batch.page_url if batch.source in ("home", "page") else crawler.base)
        if not f.ok or not f.content:
            st.dom[domain]["img_fail"] += 1
            record.update({"status": f.status, "http_status": f.code, "reason": f.reason})
            if st.candidate_path:
                with st.candidate_path.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\\n")
            st.event(f"Image fetch {f.status}: {asset.url}", "IMAGE_DOWNLOAD", domain=domain, url=asset.url)
            return

        digest = hashlib.sha256(f.content).hexdigest()
        duplicate_of = st.sha_urls.get(digest)
        if not duplicate_of:
            st.sha_urls[digest] = asset.url
        st.images_downloaded += 1
        cached = st.cache.get(st.ref_key, digest) if st.cache else None
        if cached:
            outcome, size, hash_text = cached
            st.cache_hits += 1
        else:
            st.cache_misses += 1
            res = await asyncio.get_running_loop().run_in_executor(st.pool, _compare_bytes, st.reference, f.content)
            if not res:
                record.update({"status": "invalid_image", "sha256": digest})
                if st.candidate_path:
                    with st.candidate_path.open("a", encoding="utf-8") as fh:
                        fh.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\\n")
                return
            outcome, size, hash_text = res
            if st.cache:
                st.cache.put(st.ref_key, digest, size, hash_text, outcome)
        st.images_compared += 1

        ref_base = st.reference.full["original"]
        candidate_values = tuple(int(hash_text[k], 16) for k in ("pHash", "dHash", "aHash"))
        base_distances = {
            "pHash": (ref_base[0] ^ candidate_values[0]).bit_count(),
            "dHash": (ref_base[1] ^ candidate_values[1]).bit_count(),
            "aHash": (ref_base[2] ^ candidate_values[2]).bit_count(),
        }
        record.update({
            "status": "matched" if outcome else "not_matched",
            "sha256": digest, "width": size[0], "height": size[1],
            "bytes": len(f.content), "hashes": hash_text,
            "exact_duplicate_of": duplicate_of,
            "hash_distances_to_reference_original": base_distances,
            "match": ({
                "type": outcome.match_type, "method": outcome.method,
                "variant": outcome.variant, "confidence": outcome.confidence,
                "distances": list(outcome.distances), "inliers": outcome.inliers,
                "inlier_ratio": outcome.inlier_ratio, "spread": outcome.spread,
            } if outcome else None),
        })
        if st.candidate_path:
            with st.candidate_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\\n")
        st.dom[domain]["unique_images"] += 1
        st.event(f"Fingerprinted {asset.url} ({'MATCH' if outcome else 'no match'})", "FINGERPRINT", domain=domain,
                 url=asset.url, sha256=digest, hashes=hash_text)

        if not outcome:
            return
        specific = bool(asset.page_url) or batch.source == "page"
        videos = list(asset.videos) + (list(batch.videos) if (specific and not asset.page_url) else [])
        match = self._match(row, outcome, asset, page_url, specific, size, videos, batch.source, batch.title)
        match["sha256"] = digest
        match["candidate_hashes"] = hash_text
        match["match_hash_distances"] = list(outcome.distances)
        match["hash_distances_to_reference_original"] = base_distances
        st.matches.append(match)
        st.dom[domain]["matches"] += 1
        st.event(f"Match on {domain} ({outcome.match_type}, {outcome.confidence:.0f}%)", "MATCH",
                 domain=domain, confidence=outcome.confidence, method=outcome.method, url=asset.url)
        if specific and page_url:
            crawler.enqueue(page_url, 100)

    @staticmethod
    def _match(row, o: Outcome, asset: Asset, page_url, specific, size, videos, found_via, title) -> dict:
        return {
            "id": uuid.uuid4().hex[:8],
            "domain": row["domain"],
            "page_url": page_url,
            "page_specific": specific,
            "image_url": asset.url,
            "alt_image_urls": [],
            "videos": [{"url": v.url, "kind": v.kind} for v in _dedupe_videos(videos)][:5],
            "title": (asset.title or title or None),
            "match_type": o.match_type, "method": o.method, "variant": o.variant,
            "confidence": o.confidence, "inliers": o.inliers, "inlier_ratio": o.inlier_ratio,
            "category": "strong" if o.match_type in STRONG else "possible",
            "verified_on_page": False,
            "main_hit": asset.source in ("meta", "jsonld") and specific,
            "found_via": found_via,
            "network": row.get("network") or None,
            "image_size": list(size),
        }

    def _consolidate(self, matches: list) -> list:
        groups: dict = {}
        for m in matches:
            key = (m["domain"], m["page_url"] if m["page_specific"] else m["image_url"])
            cur = groups.get(key)
            if cur is None:
                groups[key] = m
                continue
            best, other = (m, cur) if m["confidence"] > cur["confidence"] else (cur, m)
            best["alt_image_urls"] = list(dict.fromkeys(best["alt_image_urls"] + other["alt_image_urls"] + [other["image_url"]]))[:6]
            seen = {v["url"] for v in best["videos"]}
            best["videos"] += [v for v in other["videos"] if v["url"] not in seen]
            best["main_hit"] = best["main_hit"] or other["main_hit"]
            best["title"] = best["title"] or other["title"]
            groups[key] = best
        out = list(groups.values())
        for m in out:
            self._finalize(m)
        out.sort(key=lambda m: (m["verified_on_page"], m["category"] == "strong", m["confidence"]), reverse=True)
        return out

    @staticmethod
    def _finalize(m: dict) -> None:
        """'verified' = the page's OWN main image matched AND at least one other, different image matched too."""
        distinct = {m["image_url"], *m["alt_image_urls"]}
        m["verified_on_page"] = bool(m["main_hit"] and len(distinct) >= 2)
        if m["verified_on_page"]:
            m["category"] = "strong"

    async def _refine(self, st: State, m: dict) -> None:
        """Open the matched page: collect video URLs + title, and re-test the page's own main image."""
        if not m["page_specific"] or not m["page_url"] or st.cancel.is_set():
            return
        f = await st.http.page(m["page_url"])
        if not f.ok:
            return
        parsed = parse_html(f.text(), m["page_url"])
        seen = {v["url"] for v in m["videos"]}
        m["videos"] += [{"url": v.url, "kind": v.kind} for v in parsed.videos if v.url not in seen]
        m["videos"] = m["videos"][:6]
        if not m["title"] and parsed.title:
            m["title"] = parsed.title
        mains = [a for a in parsed.assets if a.source in ("meta", "jsonld")][:4]
        loop = asyncio.get_running_loop()
        for a in mains:
            img = await st.http.image(a.url, referer=m["page_url"])
            if not img.ok or not img.content:
                continue
            res = await loop.run_in_executor(st.pool, _compare_bytes, st.reference, img.content)
            if res and res[0] is not None and res[0].match_type in STRONG:
                m["main_hit"] = True
                if a.url != m["image_url"]:
                    m["alt_image_urls"] = list(dict.fromkeys(m["alt_image_urls"] + [a.url]))[:6]
                m["confidence"] = max(m["confidence"], res[0].confidence)
                break
        self._finalize(m)

    @staticmethod
    def _coverage(st: State, crawlers: dict) -> dict:
        counts = {"checked": 0, "no_images": 0, "blocked": 0, "unreachable": 0, "skipped": 0}
        detail = {}
        for domain, d in st.dom.items():
            c = crawlers[domain]
            if d["candidates"] > 0:
                status = "checked"
            elif d["skipped"] > 0:
                status = "skipped"
            elif c.stats["ok"] > 0:
                status = "no_images"
            elif c.stats["blocked"] > 0:
                status = "blocked"
            else:
                status = "unreachable"
            counts[status] += 1
            detail[domain] = {
                "status": status, "tier": d.get("tier"), "pages": c.pages_fetched,
                "candidates": d["candidates"], "images_downloaded": d.get("unique_images", 0),
                "matches": d.get("matches", 0), "image_failures": d["img_fail"],
                "errors": d.get("errors", 0), "sources": dict(c.sources),
                "reason": c.last_reason if status in ("blocked", "unreachable") else "",
            }
        return {"summary": counts, "domains": detail}
