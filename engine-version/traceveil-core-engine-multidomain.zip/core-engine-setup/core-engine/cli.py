"""Command line:
  python cli.py scan photo.jpg                 # searches every domain in data/intelligence.csv
  python cli.py scan photo.jpg --domains a.com,b.com
  python cli.py single photo.jpg https://example.com/
  python cli.py serve --port 8000
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import re
from datetime import datetime
from pathlib import Path

from engine.scan import Scanner


async def _scan(args) -> int:
    data = Path(args.image).read_bytes()
    scanner = Scanner()
    selected = [d.strip() for d in (args.domains or "").split(",") if d.strip()] or None
    domain_count = len(scanner._select(selected))
    outdir = Path(args.outdir or "scan-results") / ("scan-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    last = {"line": "", "events": set()}

    def progress(p: dict) -> None:
        line = (
            f"[{p.get('phase','')}] domains {p.get('domains_done',0)}/{p.get('domains_total',0)}  "
            f"pages {p.get('pages',0)}  images {p.get('candidates',0)}  "
            f"matches {p.get('matches',0)}  cache hits {p.get('cache_hits',0)}"
        )
        if line != last["line"]:
            last["line"] = line
            print(line, file=sys.stderr)
        for event in p.get("events", []):
            key = (event.get("t"), event.get("stage"), event.get("msg"))
            if key in last["events"]:
                continue
            last["events"].add(key)
            if event.get("stage") in (
                "PAGE_CRAWLING", "STRUCTURED_DISCOVERY", "IMAGE_DISCOVERY",
                "IMAGE_DOWNLOAD", "FINGERPRINT", "MATCH", "DOMAIN_ERROR", "CSS_ERROR",
            ):
                print(f"[{event.get('stage')}] {event.get('msg')}", file=sys.stderr)
        if len(last["events"]) > 5000:
            last["events"] = set(list(last["events"])[-2000:])

    print(f"Starting all-domain scan across {domain_count} configured domains.", file=sys.stderr)
    result = await scanner.scan(data, domains=selected, progress=progress, output_dir=outdir)
    if args.out:
        Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Full result written to {args.out}", file=sys.stderr)
    print(f"\\n{len(result['matches'])} match(es) in {result['duration_s']}s")
    print("Stats:", json.dumps(result["stats"], ensure_ascii=False))
    print("Coverage:", json.dumps(result["coverage"]["summary"], ensure_ascii=False))
    print(f"Artifacts: {outdir.resolve()}")
    for m in result["matches"]:
        print(f"\\n[{m['category'].upper()}] {m['domain']} {m['confidence']:.0f}% ({m['match_type']}, {m['method']})")
        print(f"  page : {m['page_url']}")
        print(f"  image: {m['image_url']}")
        print(f"  sha256: {m.get('sha256','')}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Traceveil multi-domain image matching engine")
    sub = ap.add_subparsers(dest="cmd", required=True)
    scan = sub.add_parser("scan", help="search all configured domains (default) or a supplied subset")
    scan.add_argument("image", help="reference image path")
    scan.add_argument("--domains", help="optional comma-separated subset; omit to scan every configured domain")
    scan.add_argument("--outdir", default="scan-results", help="base directory for JSONL evidence artifacts")
    scan.add_argument("--out", help="optional extra JSON result path")

    one = sub.add_parser("single", help="deep-inspect exactly one website URL")
    one.add_argument("image", help="reference image to search for")
    one.add_argument("url", help="one target website URL, e.g. https://example.com/")
    one.add_argument("--outdir", default=None, help="output folder")
    one.add_argument("--max-pages", type=int, default=500)
    one.add_argument("--max-images", type=int, default=15000)
    one.add_argument("--assets-per-page", type=int, default=250)
    one.add_argument("--sitemap-limit", type=int, default=40)

    serve = sub.add_parser("serve", help="start the local web dashboard")
    serve.add_argument("--port", type=int, default=8000)
    serve.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()

    if args.cmd == "serve":
        import uvicorn
        uvicorn.run("server:app", host=args.host, port=args.port)
        return 0
    if args.cmd == "single":
        from engine.single_site import inspect_single_site, normalize_target
        host, target = normalize_target(args.url)
        outdir = args.outdir or str(Path("inspection-results") / (
            re.sub(r"[^a-zA-Z0-9.-]+", "_", host) + "-" + datetime.now().strftime("%Y%m%d-%H%M%S")))
        async def run_single():
            data = Path(args.image).read_bytes()
            result = await inspect_single_site(
                data, target, outdir, max_pages=max(1, args.max_pages),
                max_images=max(1, args.max_images), page_asset_limit=max(1, args.assets_per_page),
                sitemap_limit=max(1, args.sitemap_limit))
            print(json.dumps(result, indent=2))
        asyncio.run(run_single())
        return 0
    return asyncio.run(_scan(args))


if __name__ == "__main__":
    sys.exit(main())
