# Traceveil Core Engine — Multi-domain image discovery

Upload one reference image and search **all 91 configured domains** in `data/intelligence.csv` by default. The scan progressively discovers public pages and image URLs, fingerprints downloaded image candidates, matches transformed copies, and records evidence metadata.

The engine retains the existing pHash/dHash/aHash + crop/window + mirrored + RootSIFT/RANSAC matcher. It does not download full videos or retain candidate image files. Candidate bytes are processed in memory; the persistent cache stores SHA-256 digests, dimensions, hashes and comparison outcomes only.

## Windows setup

```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run a scan across ALL configured domains

From this `core-engine` folder:

```powershell
python cli.py scan "D:\\images\\reference.jpg"
```

The default scan uses all 91 unique domains from `data/intelligence.csv`. Do not pass `--domains` when you want the complete domain list.

Optional subset scan:

```powershell
python cli.py scan "D:\\images\\reference.jpg" --domains example.com,other.net
```

Results are written to a timestamped directory under `scan-results/`:

```text
scan-results/
  scan-YYYYMMDD-HHMMSS/
    scan-summary.json
    matches.json
    domains.json
    events.jsonl
    discovered-assets.jsonl
    candidates.jsonl
    reference-fingerprints.json
```

### Evidence files

- `scan-summary.json` — complete summary, matches, stats and coverage.
- `matches.json` — matched source pages and image URLs, confidence, method, hashes and contact/removal details.
- `domains.json` — status, tier, pages, candidates, downloaded images, matches and failures per domain.
- `events.jsonl` — timestamped engine event stream with full page/image URLs and stage names.
- `discovered-assets.jsonl` — every unique image URL discovered, including candidates deferred by budgets.
- `candidates.jsonl` — download status, SHA-256, dimensions, byte size, pHash/dHash/aHash, Hamming distances to the reference and match decision for each attempted candidate.
- `reference-fingerprints.json` — reference image hashes and reference variants.

Candidate image bytes are not saved to disk. This reduces unnecessary retention of unrelated sensitive media. A successful match record preserves the source URL and matching evidence.

## Run the local dashboard

```powershell
python cli.py serve --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. The dashboard scans all configured domains by default and shows global progress, recent events, domain coverage and matches. It also exposes:
- `GET /api/health`
- `GET /api/domains`
- `POST /api/scan`
- `GET /api/scan/{scan_id}`
- `POST /api/scan/{scan_id}/cancel`

## Default multi-domain strategy

The defaults are deliberately bounded and adaptive. They are initial tuning values, not guarantees of complete coverage.

| Setting | Default |
|---|---:|
| Domains in dataset | 91 |
| Initial pages/domain | 30 |
| Initial image candidates/domain | 100 |
| Initial page depth | 3 |
| Expanded page depth | 5 |
| Tier 1 hard ceiling | 200 pages / 1,000 candidates |
| Tier 2 hard ceiling | 100 pages / 500 candidates |
| Tier 3 hard ceiling | 50 pages / 200 candidates |
| Concurrent domains | 10 |
| Global concurrent HTTP requests | 20 |
| Requests per host | 2 |
| Total page hard cap | 15,000 |
| Total candidate hard cap | 50,000 |
| Queued URLs hard cap | 20,000 |
| Sitemap documents/domain | 20 |
| HTML response limit | 2 MB |
| Image response limit | 4 MB |
| Request timeout | 12 seconds |
| Retries | 2 |
| Scan time budget | 15 minutes |
| CPU workers | up to 8 |

### Tier assignment

The CSV's `provider_type` is treated as a heuristic:
- Tier 1: self/private CDN and direct CDN.
- Tier 2: embedded player/tube and external CDN.
- Tier 3: API stream and unknown provider types.

The provider metadata is not independently verified. The crawler follows only same-site HTML links and same-site sitemap/page references. An external CDN image is fetched only when directly referenced by a page on the configured domain; the crawler does not navigate or discover other pages on the CDN.

### Progressive/adaptive passes

1. **Quick discovery:** all configured domains receive a first pass, with BFS page discovery, sitemap, WordPress REST and RSS/Atom extraction.
2. **Fingerprint immediately:** each image candidate is downloaded within limits, SHA-256 deduplicated through the persistent cache, then checked using perceptual hashes.
3. **Adaptive deepening:** matched domains, related domains (based on dataset network/provider hints), and high-yield domains receive extra crawl budget. Candidates held back by the initial per-domain budget are reconsidered.
4. **Verification and reporting:** matched pages are revisited to collect page title/video references and verify the page's own main image. Removal contacts and notice drafts are generated for matched domains.

The persistent SQLite cache is stored at `data/fingerprint-cache.sqlite3`. It stores only digest/hash/matcher metadata, never candidate image bytes. Cache keys include the reference image digest and matcher version; old rows are pruned to keep the newest 200,000 entries. The cache can reduce repeated CPU work on later scans, but the engine still needs to download a candidate to compute its SHA-256.

## Matching pipeline

1. SHA-256 — exact file duplicate/cache key.
2. pHash, dHash and aHash — fast perceptual comparison.
3. Mirrored and centre-crop reference variants.
4. Candidate border trimming and multi-scale windows.
5. RootSIFT feature matching, mutual-best filtering and RANSAC geometric verification for likely transformed copies.

The existing thresholds are retained. A `probable` result is not the same as a confirmed exact match; inspect its evidence before acting.

## Single-website mode remains available

```powershell
python cli.py single "D:\\images\\reference.jpg" "https://example.com/" `
  --max-pages 500 `
  --max-images 15000 `
  --assets-per-page 250 `
  --sitemap-limit 40
```

This mode is isolated to the supplied host. It does not run the full domain dataset.

## Tests

```powershell
python tests/test_e2e.py
python tests/test_server.py
python tests/eval_matcher.py
```

The included fake-site tests cover sitemap, WordPress, RSS, pagination, lazy loading, blocked/dead sites, adaptive related-domain deepening and API upload/polling. Real-site reachability and site-specific rendering must still be checked in your own environment.

## Safety, network and coverage limitations

- The crawler does not bypass logins, paywalls, CAPTCHAs, bot challenges or other access controls.
- It does not download full videos or extract video frames.
- It only follows same-site HTML links. External image CDNs are used only for assets directly embedded/referenced by a scanned page.
- `robots.txt` is used for sitemap discovery; this is not a complete robots Allow/Disallow policy evaluator. Respect the target site's terms, applicable law and authorization.
- JavaScript-only content may not be visible to the plain HTTP parser. No browser automation or challenge bypass is included.
- Blocked, unreachable, skipped and no-image domains are reported separately. A scan with no matches is not proof that no copy exists.
- Use the tool only for images you are authorized to search for. Keep access to reports restricted and apply a retention policy appropriate for sensitive evidence.
- SSRF protection is enabled by default. `CE_ALLOW_PRIVATE=1` exists only for local fake-site tests and should not be enabled for public scans.

## Configuration overrides

Settings can be overridden with environment variables prefixed by `CE_`, for example:

```powershell
$env:CE_CONCURRENT_DOMAINS="8"
$env:CE_GLOBAL_CONCURRENCY="16"
$env:CE_MAX_CANDIDATES="30000"
$env:CE_SCAN_TIMEOUT="900"
python cli.py scan "D:\\images\\reference.jpg"
```

Start with defaults. Raise budgets only after measuring match recall, false positives, site response rates and scan duration on a representative test set.
