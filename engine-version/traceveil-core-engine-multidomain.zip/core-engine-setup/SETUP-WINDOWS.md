# Traceveil Core Engine — Windows setup

This package includes the multi-domain scanner. By default, it searches all **91 unique domains** listed in `core-engine/data/intelligence.csv`.

## Requirements
- Windows 10/11
- Python 3.10+ (Python 3.12 recommended)
- Internet access to install dependencies

## 1. Install

Extract the ZIP, open PowerShell in `core-engine-setup`, then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\\setup-windows.ps1
```

## 2. Start the dashboard

```powershell
.\\run-ui.ps1
```

Open `http://127.0.0.1:8000`. Upload your reference image and press Search. The dashboard searches all configured domains by default.

## 3. Run all domains from PowerShell

```powershell
cd .\\core-engine
.\\.venv\\Scripts\\Activate.ps1
python cli.py scan "C:\\path\\to\\reference.jpg"
```

Do not supply `--domains` when you want all 91 domains.

To scan a subset only:

```powershell
python cli.py scan "C:\\path\\to\\reference.jpg" --domains "example.com,other.net"
```

## 4. Where results are stored

Every scan creates a timestamped folder under `core-engine/scan-results/` containing:
- `scan-summary.json`
- `matches.json`
- `domains.json`
- `events.jsonl`
- `discovered-assets.jsonl`
- `candidates.jsonl`
- `reference-fingerprints.json`

The persistent fingerprint cache is stored in `core-engine/data/fingerprint-cache.sqlite3`. It stores SHA-256 digests, dimensions, hashes and match outcomes—not image bytes.

## 5. Tests

```powershell
cd .\\core-engine
.\\.venv\\Scripts\\Activate.ps1
python tests\\test_e2e.py
python tests\\test_server.py
python tests\\eval_matcher.py
```

## Important limitations

The crawler does not bypass logins, paywalls, CAPTCHAs or other access controls. It does not download full videos. External CDN images are fetched only when directly referenced by a scanned page; CDN domains are not crawled independently. JavaScript-only content may not be visible to the plain HTTP crawler. Blocked or unreachable websites are reported separately; no-match is not proof that an image is absent.
