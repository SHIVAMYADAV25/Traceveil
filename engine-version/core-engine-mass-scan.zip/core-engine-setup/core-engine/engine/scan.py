"""
Scan orchestrator:  reference -> crawl (pass 1) -> adaptive deepening (pass 2) -> refine -> contacts.

Why it finds more than a one-shot crawl
---------------------------------------
* Pass 1 gives every domain a normal budget, pulling candidates from sitemaps / WP API / feeds / pages.
* Pass 2 ADAPTS: a domain that matched gets a big extra budget, the matched content page is crawled
  first (its "related videos" are where re-uploads cluster), and sister sites on the same network or
  video CDN are searched deeper too.
* Refine opens each matched page, collects its video URLs and title, and re-tests the page's own main
  image (og:image / poster).  A second, independent image agreeing upgrades the match to "verified".
"""
from __future__ import annotations

import asyncio
import hashlib
import random
import os
import re
import shutil
import tempfile
import time
import uuid
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional
from urllib.parse import urljoin, urlsplit

from . import config
from .contacts import IGNORED_PROVIDERS, Contacts, load_rows, norm_domain
from .crawler import Batch, DomainCrawler
from .extract import Asset, VideoRef, _dedupe_videos, is_junk, parse_html
from .fingerprint import Outcome, Reference, build_reference, compare, compare_geometric, open_image, viable
from .http import Http
from .notice import build_notice
from .options import Options

STRONG = ("exact", "near_duplicate", "structural")
_SIZE_SUFFIX = re.compile(r"-\d{2,4}x\d{2,4}(?=\.\w{2,5}$)")


def _variant_key(url: str) -> str:
    """WordPress-style resized copies (name-300x200.jpg) of one upload count as one candidate."""
    sp = urlsplit(url)
    return sp.netloc + _SIZE_SUFFIX.sub("", sp.path) + ("?" + sp.query if sp.query and len(sp.query) < 40 else "")


def _compare_bytes(ref: Reference, data: bytes, geometric: bool = True):
    """-> (outcome | None, size, worth_a_second_look) or None if the bytes are not an image."""
    img = open_image(data)
    if img is None:
        return None
    out = compare(ref, img, geometric)
    return (out, img.size, out is None and viable(img))


def _geo_file(ref: Reference, path: str):
    try:
        with open(path, "rb") as fh:
            img = open_image(fh.read())
        return compare_geometric(ref, img) if img is not None else None
    except Exception:
        return None


def _rank(a: Asset) -> int:
    """Likeliest-to-matter first: thumbnails tied to a content page, page's main image, then the rest."""
    return (0 if a.page_url else 2) + (0 if a.source in ("meta", "jsonld", "sitemap", "wp", "rss") else 1)


@dataclass
class State:
    reference: Reference
    http: Http
    pool: ThreadPoolExecutor
    opts: Options
    progress: Optional[Callable[[dict], None]]
    cancel: asyncio.Event
    started: float
    deadline: float                                   # crawl deadline (monotonic) - the hard stop for fetching
    seen: dict = field(default_factory=dict)          # domain -> image keys already taken
    verdict: dict = field(default_factory=dict)       # image url -> (Outcome|None, size) shared across sites
    by_sha: dict = field(default_factory=dict)        # sha1 of image bytes -> verdict (mirror sites serve identical files)
    matches: list = field(default_factory=list)
    dom: dict = field(default_factory=dict)
    queue: deque = field(default_factory=deque)
    running: set = field(default_factory=set)
    candidates: int = 0
    domains_done: int = 0
    domains_total: int = 0
    events: list = field(default_factory=list)
    phase: str = "starting"
    truncated: Optional[str] = None
    stop: bool = False
    second: dict = field(default_factory=dict)        # sha1 -> {path, rank, occ[...]}: images queued for the SIFT re-check
    second_done: int = 0
    recheck_seen: set = field(default_factory=set)
    tmpdir: Optional[str] = None

    def expired(self) -> bool:
        if self.cancel.is_set():
            self.truncated = self.truncated or "cancelled"
            return True
        if self.stop:
            return True
        if time.monotonic() > self.deadline:
            self.truncated = self.truncated or "time limit reached"
            return True
        return False

    def time_left(self) -> float:
        return max(0.0, self.deadline - time.monotonic())

    def event(self, msg: str) -> None:
        self.events.append({"t": round(time.time(), 1), "msg": msg})
        del self.events[:-100]
        self.push()

    def push(self) -> None:
        if self.progress:
            self.progress({
                "phase": self.phase, "candidates": self.candidates, "matches": len(self.matches),
                "domains_done": self.domains_done, "domains_total": self.domains_total,
                "domains_running": len(self.running), "domains_remaining": len(self.queue),
                "recheck_total": len(self.second), "recheck_done": self.second_done,
                "elapsed": round(time.monotonic() - self.started, 1), "time_left": round(self.time_left(), 1),
                "pages": sum(d.get("pages", 0) for d in self.dom.values()),
                "events": list(self.events[-30:]),
            })


class Scanner:
    def __init__(self, rows: Optional[list] = None, contacts: Optional[Contacts] = None):
        self.rows = rows if rows is not None else load_rows()
        self.contacts = contacts or Contacts()

    # ── public ─────────────────────────────────────────────────────────────
    async def scan(self, image_bytes: bytes, *, domains: Optional[list] = None,
                   progress: Optional[Callable[[dict], None]] = None,
                   cancel: Optional[asyncio.Event] = None, options: Optional[Options] = None) -> dict:
        opts = (options or Options.make()).clamped()
        started = time.time()
        t0 = time.monotonic()
        loop = asyncio.get_running_loop()
        pool = ThreadPoolExecutor(max_workers=config.CPU_WORKERS)
        http = Http()
        st = None
        try:
            reference = await loop.run_in_executor(pool, build_reference, image_bytes)
            chosen, later, skipped = self._plan_sites(domains, opts)
            reserve = min(25.0, max(4.0, opts.time_budget * 0.12))        # kept for verification + contacts
            st = State(reference, http, pool, opts, progress, cancel or asyncio.Event(), t0,
                       t0 + max(3.0, opts.time_budget - reserve), domains_total=len(chosen))
            st.dom = {r["domain"]: {"candidates": 0, "skipped": 0, "img_fail": 0, "small": 0, "pages": 0, "state": "queued",
                                    "cut_by": None, "seconds": 0.0} for r in chosen}
            st.seen = {r["domain"]: set() for r in chosen}
            crawlers = {r["domain"]: DomainCrawler(r["domain"], http, opts=opts) for r in chosen}
            by_domain = {r["domain"]: r for r in chosen}

            # ── pass 1: every selected site, time-boxed, many at once ──
            st.phase = "crawling"
            st.queue = deque(chosen)
            pass1 = st.time_left() * (opts.pass1_share / 100)
            site_time = opts.auto_site_time(len(chosen), pass1)
            st.event(f"Pass 1: {len(chosen)} site(s), {opts.site_parallel} at a time, ~{site_time:.0f}s each, "
                     f"budget {opts.time_budget}s ({len(later)} more not selected, {skipped} skipped)")
            soft_stop = time.monotonic() + pass1
            limit = st.deadline - (opts.time_budget * 0.25 if opts.geometric == 2 else 0)   # keep time for the second look
            await self._run_pass(st, crawlers, by_domain, pages=opts.site_pages, images=opts.site_images,
                                 site_time=site_time, soft_stop=soft_stop, limit=limit)
            not_reached = [r["domain"] for r in st.queue]
            crawl_done = asyncio.Event()
            recheck = asyncio.create_task(self._second_look(st, crawl_done)) if opts.geometric == 2 else None

            # ── pass 2: dig deeper where it already matched (+ sister sites) ──
            related: list = []
            if st.matches and not st.expired() and st.time_left() > 6:
                st.phase = "deepening"
                matched = {m["domain"] for m in st.matches}
                related = self._related(matched, chosen)
                for m in st.matches:
                    if m["page_specific"] and m["page_url"] and m["domain"] in crawlers:
                        crawlers[m["domain"]].enqueue(m["page_url"], 100)
                plan = [by_domain[d] for d in matched if d in by_domain]
                plan += [by_domain[d] for d in related if d in by_domain and d not in matched]
                st.domains_done, st.domains_total = 0, len(plan)
                st.queue = deque(plan)
                st.stop = False
                site_time2 = opts.auto_site_time(len(plan), st.time_left())
                st.event(f"Pass 2: {len(matched)} matched + {len(related)} related site(s) searched deeper")
                await self._run_pass(st, crawlers, by_domain, pages=opts.bonus_pages, images=opts.bonus_images,
                                     site_time=max(site_time2, 10.0), soft_stop=st.deadline, deepen=True)

            # ── continuation rounds: resume sites that were cut short, best-yielding first, until time is up ──
            rounds = 0
            while rounds < 6 and not st.expired() and st.time_left() > 8:
                todo = self._unfinished(st, crawlers)
                if not todo:
                    break
                rounds += 1
                st.phase = "deepening"
                st.queue = deque(by_domain[d] for d in todo)
                st.domains_done, st.domains_total = 0, len(todo)
                st.stop = False
                st.event(f"Round {rounds + 1}: resuming {len(todo)} site(s) that were cut short")
                await self._run_pass(st, crawlers, by_domain, pages=opts.site_pages, images=opts.site_images,
                                     site_time=6.0, soft_stop=st.deadline, deepen=True)
            crawl_done.set()
            if recheck is not None:
                st.phase = "rechecking"
                st.event(f"Second look: {len(st.second)} cached image(s) queued for the geometric matcher")
                await recheck

            # ── verify + contacts (bounded by what is left of the budget) ──
            matches = self._consolidate(st.matches)
            hard = t0 + opts.time_budget
            st.deadline = hard                                  # fetch window for the final steps
            st.phase = "verifying"
            st.event(f"Verifying {min(len(matches), 25)} match(es) on their pages")
            await self._bounded(asyncio.gather(*[self._refine(st, m) for m in matches[:25]], return_exceptions=True), hard)
            matches = self._consolidate(matches)

            st.phase = "contacts"
            domains_hit = list(dict.fromkeys(m["domain"] for m in matches))
            contacts = {d: self.contacts.static(d) for d in domains_hit}
            infos = await self._bounded(asyncio.gather(*[self.contacts.lookup(
                d, http, base_url=(crawlers[d].base if d in crawlers else None)) for d in domains_hit], return_exceptions=True), hard)
            for d, info in zip(domains_hit, infos or []):
                if isinstance(info, dict):
                    contacts[d] = info
            for m in matches:
                m["contact"] = contacts.get(m["domain"])
            notices = [build_notice(d, [m for m in matches if m["domain"] == d], contacts[d]) for d in domains_hit]

            st.phase = "done"
            st.push()
            cov = self._coverage(st, crawlers)
            remaining = not_reached + [r["domain"] for r in later]
            return {
                "status": "completed",
                "duration_s": round(time.time() - started, 1),
                "reference": {"width": reference.size[0], "height": reference.size[1]},
                "matches": matches,
                "notices": notices,
                "related_domains": related,
                "coverage": cov,
                "sites": {"selected": len(chosen), "scanned": len(chosen) - len(not_reached),
                          "not_reached": not_reached, "not_selected": [r["domain"] for r in later],
                          "skipped_by_offset": skipped},
                "remaining_domains": remaining,          # feed these to the next scan to continue where this one stopped
                "options": opts.public(),
                "stats": {"candidates_compared": st.candidates, "requests": http.requests,
                          "second_look": {"queued": len(st.second), "checked": st.second_done},
                          "domains": len(chosen), "truncated": st.truncated},
            }
        finally:
            await http.close()
            pool.shutdown(wait=False, cancel_futures=True)
            if st is not None and st.tmpdir:
                shutil.rmtree(st.tmpdir, ignore_errors=True)

    # ── internals ──────────────────────────────────────────────────────────
    @staticmethod
    async def _bounded(aw, hard_deadline: float):
        try:
            return await asyncio.wait_for(aw, timeout=max(1.0, hard_deadline - time.monotonic()))
        except asyncio.TimeoutError:
            return None

    def _select(self, domains: Optional[list]) -> list:
        if not domains:
            return list(self.rows)
        wanted = [norm_domain(d) if ":" not in d else d.strip().lower() for d in domains if d.strip()]
        known = {r["domain"]: r for r in self.rows}
        return [known.get(d, {"domain": d, "network": "", "provider_type": "", "video_provider": ""}) for d in wanted]

    def _plan_sites(self, domains: Optional[list], opts: Options):
        rows = self._select(domains)
        if opts.order == "shuffle":
            rows = random.Random(7).sample(rows, len(rows))
        skipped = min(opts.skip_sites, len(rows))
        rows = rows[skipped:]
        if opts.max_sites and len(rows) > opts.max_sites:
            return rows[: opts.max_sites], rows[opts.max_sites:], skipped
        return rows, [], skipped

    def _related(self, matched: set, rows: list) -> list:
        nets = {r.get("network") for r in rows if r["domain"] in matched and r.get("network") not in (None, "", "UnknownNetwork")}
        vids = {r.get("video_provider") for r in rows if r["domain"] in matched and (r.get("video_provider") or "").lower() not in IGNORED_PROVIDERS}
        return [r["domain"] for r in rows if r["domain"] not in matched and (r.get("network") in nets or r.get("video_provider") in vids)]

    @staticmethod
    def _unfinished(st: State, crawlers: dict) -> list:
        """Sites stopped by a limit (not because they ran out of pages), most productive first."""
        out = []
        for dom, d in st.dom.items():
            c = crawlers[dom]
            if d["state"] == "done" and d["cut_by"] in ("time", "pages", "images") and c.base and (c.heap or d["cut_by"] == "images"):
                out.append((d["candidates"] / max(1, d["pages"]), dom))
        return [dom for _, dom in sorted(out, reverse=True)]

    async def _run_pass(self, st: State, crawlers: dict, by_domain: dict, *, pages: int, images: int,
                        site_time: float, soft_stop: float, deepen: bool = False, limit: Optional[float] = None) -> None:
        """Worker pool: `site_parallel` sites at once; a worker takes the next site the moment it is free.
        Past `soft_stop` no NEW site starts - unless nothing has matched yet (coverage beats depth)."""
        async def worker() -> None:
            while st.queue and not st.expired():
                if time.monotonic() > soft_stop and (st.matches or deepen):
                    return
                if st.time_left() < 4 or (limit is not None and time.monotonic() > limit):
                    return
                row = st.queue.popleft()
                share = site_time
                if not st.opts.site_time:                          # fair share of the time that is actually LEFT
                    window = (limit if limit is not None else st.deadline) - time.monotonic()
                    share = max(site_time, min(60.0, window * st.opts.site_parallel / (len(st.queue) + st.opts.site_parallel)))
                await self._site(st, row, crawlers[row["domain"]], pages, images, share, deepen, limit)
        await asyncio.gather(*[worker() for _ in range(min(st.opts.site_parallel, max(1, len(st.queue))))])

    async def _site(self, st: State, row: dict, c: DomainCrawler, pages: int, images: int,
                    site_time: float, deepen: bool, limit: Optional[float] = None) -> None:
        domain = row["domain"]
        d = st.dom[domain]
        t_start = time.monotonic()
        site_deadline = min(t_start + site_time, st.deadline if limit is None else limit)
        cap = d["candidates"] + images                       # pass 2 adds to what pass 1 already spent
        d["state"] = "running"
        st.running.add(domain)
        sem = asyncio.Semaphore(st.opts.image_parallel)
        tasks: set = set()
        pages_before = c.pages_fetched
        try:
            async for batch in c.batches(pages, deadline=site_deadline):
                if st.expired() or time.monotonic() > site_deadline or d["candidates"] >= cap:
                    break
                t = asyncio.create_task(self._process(st, row, c, batch, sem, site_deadline, cap))
                tasks.add(t)
                t.add_done_callback(tasks.discard)
                while len(tasks) >= 6 and not st.expired():       # backpressure: crawl no faster than we can check
                    await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED, timeout=1.0)
                    if time.monotonic() > site_deadline:
                        break
        except Exception as exc:                                   # one bad site must never stop the scan
            st.event(f"{domain}: {type(exc).__name__}")
        finally:
            if tasks:
                _, pending = await asyncio.wait(tasks, timeout=max(1.0, site_deadline - time.monotonic() + 2.0))
                for t in pending:
                    t.cancel()
            now = time.monotonic()
            d["pages"] = c.pages_fetched
            d["seconds"] = round(d["seconds"] + now - t_start, 1)
            if d["candidates"] >= cap:
                d["cut_by"] = "images"
            elif now >= site_deadline - 0.05:
                d["cut_by"] = "time"
            elif c.heap and c.pages_fetched - pages_before >= pages:
                d["cut_by"] = "pages"
            else:
                d["cut_by"] = None
            d["state"] = "done"
            st.running.discard(domain)
            st.domains_done += 1
            st.push()

    async def _process(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch,
                       sem: asyncio.Semaphore, site_deadline: float, cap: int) -> None:
        domain = row["domain"]
        d, seen = st.dom[domain], st.seen[domain]
        structured = batch.source in ("sitemap", "wp", "rss")
        per_batch = st.opts.structured_assets if structured else st.opts.page_assets
        assets = list(batch.assets)
        if st.opts.css_backgrounds:
            assets += await self._css_assets(st, crawler, batch)
        fresh: list = []
        for a in sorted((a for a in assets if a.source != "stylesheet" and a.url), key=_rank):
            if len(fresh) >= per_batch:
                break                                           # over the per-page cap: NOT marked seen (may be found elsewhere)
            key = _variant_key(a.url)
            if key in seen:
                continue
            if a.source == "html" and is_junk(a.url):
                continue
            seen.add(key)
            fresh.append(a)
        if batch.source == "page":
            crawler.feedback(batch.page_url, len(fresh))        # teach the crawler which link patterns are worth following
        room = max(0, cap - d["candidates"])
        if len(fresh) > room:
            d["skipped"] += len(fresh) - room
            fresh = fresh[:room]
        if not fresh:
            return
        d["candidates"] += len(fresh)
        st.candidates += len(fresh)
        await asyncio.gather(*[self._evaluate(st, row, crawler, batch, a, sem, site_deadline) for a in fresh], return_exceptions=True)
        st.push()

    async def _css_assets(self, st: State, crawler: DomainCrawler, batch: Batch) -> list:
        out: list = []
        sheets = [a.url for a in batch.assets if a.source == "stylesheet" and a.url]
        done = crawler.__dict__.setdefault("_css_done", set())
        for url in sheets[:2]:
            if url in done or len(done) >= 6:
                continue
            done.add(url)
            f = await st.http.get(url, max_bytes=config.MAX_HTML_BYTES, referer=batch.page_url, accept="text/css,*/*;q=0.5", retries=0, timeout=6)
            if not f.ok:
                continue
            for m in re.finditer(r"url\(\s*['\"]?([^'\")]+)", f.text(), re.I):
                raw = m.group(1).strip()
                if raw.startswith(("data:", "#")) or re.search(r"\.(woff2?|ttf|otf|eot|svgz?)(?:$|\?)", raw, re.I):
                    continue
                absu = urljoin(url, raw)
                if urlsplit(absu).scheme in ("http", "https"):
                    out.append(Asset(absu, page_url=batch.page_url, source="css-background"))
        return out[:200]

    async def _evaluate(self, st: State, row: dict, crawler: DomainCrawler, batch: Batch, asset: Asset,
                        sem: asyncio.Semaphore, site_deadline: float) -> None:
        domain = row["domain"]
        d = st.dom[domain]
        mode = st.opts.geometric
        async with sem:
            if st.expired() or time.monotonic() > site_deadline:
                d["skipped"] += 1
                return
            cached = st.verdict.get(asset.url)
            if cached is None:
                f = await st.http.image(asset.url, referer=batch.page_url if batch.source in ("home", "page") else crawler.base,
                                        min_side=st.opts.min_side_px)
                if not f.ok or not f.content:
                    d["small" if f.reason == "too small" else "img_fail"] += 1
                    return
                sha = hashlib.sha1(f.content).digest()
                res = st.by_sha.get(sha)
                if res is None:
                    res = await asyncio.get_running_loop().run_in_executor(
                        st.pool, _compare_bytes, st.reference, f.content, mode == 1)
                    if res is None:
                        d["img_fail"] += 1
                        return
                    st.by_sha[sha] = res
                    if res[2] and mode == 2:
                        self._queue_second_look(st, sha, f.content, res[1])
                cached = st.verdict[asset.url] = (res, sha)           # same URL on a sister site / CDN: reuse, don't redo
        (outcome, size, worth_recheck), sha = cached
        if outcome is None:
            if worth_recheck and mode == 2:
                it = st.second.get(sha)
                if it is not None and len(it["occ"]) < 20:
                    it["occ"].append((row, asset, batch.page_url, batch.source, batch.title, list(batch.videos)))
                    it["rank"] = min(it["rank"], _rank(asset))
            return
        specific = bool(asset.page_url) or batch.source == "page"
        page_url = asset.page_url or batch.page_url
        videos = list(asset.videos) + (list(batch.videos) if (specific and not asset.page_url) else [])
        match = self._match(row, outcome, asset, page_url, specific, size, videos, batch.source, batch.title)
        st.matches.append(match)
        st.event(f"Match on {domain} ({outcome.match_type}, {outcome.confidence:.0f}%)")
        if specific and page_url:
            crawler.enqueue(page_url, 100)
        n = st.opts.stop_after_strong
        if n and sum(1 for m in st.matches if m["category"] == "strong") >= n:
            st.truncated = st.truncated or "stop_after_strong reached"
            st.stop = True

    # ── deferred SIFT re-check ("second look") ─────────────────────────────
    @staticmethod
    def _queue_second_look(st: State, sha: bytes, content: bytes, size: tuple) -> None:
        if sha in st.second or len(st.second) >= 30000:
            return
        if st.tmpdir is None:
            st.tmpdir = tempfile.mkdtemp(prefix="ce-recheck-")
        path = os.path.join(st.tmpdir, sha.hex())
        try:
            with open(path, "wb") as fh:
                fh.write(content)
        except OSError:
            return
        st.second[sha] = {"path": path, "size": size, "rank": 9, "occ": []}

    async def _second_look(self, st: State, crawl_done: asyncio.Event) -> None:
        """Runs the expensive local-feature matcher over images the fast hash sweep did not match, best candidates
        first, from the local cache (no network), for as long as the time budget allows."""
        loop = asyncio.get_running_loop()
        sem = asyncio.Semaphore(max(2, config.CPU_WORKERS))
        tasks: set = set()

        async def one(it: dict) -> None:
            try:
                out = await loop.run_in_executor(st.pool, _geo_file, st.reference, it["path"])
                st.second_done += 1
                if out is None:
                    return
                for row, asset, page_url, source, title, vids in it["occ"]:
                    specific = bool(asset.page_url) or source == "page"
                    pu = asset.page_url or page_url
                    videos = list(asset.videos) + (list(vids) if (specific and not asset.page_url) else [])
                    st.matches.append(self._match(row, out, asset, pu, specific, it["size"], videos, source, title))
                    st.event(f"Match on {row['domain']} ({out.match_type}, {out.confidence:.0f}%, second look)")
            finally:
                sem.release()

        while not st.expired():
            todo = [(k, v) for k, v in st.second.items() if k not in st.recheck_seen and v["occ"]]
            if not todo:
                if crawl_done.is_set():
                    break
                await asyncio.sleep(0.25)
                continue
            todo.sort(key=lambda kv: kv[1]["rank"])
            for k, v in todo[:64]:
                if st.expired():
                    break
                st.recheck_seen.add(k)
                await sem.acquire()
                t = asyncio.create_task(one(v))
                tasks.add(t)
                t.add_done_callback(tasks.discard)
            st.push()
        if tasks:
            _, pending = await asyncio.wait(tasks, timeout=max(1.0, st.time_left() + 2.0))
            for t in pending:
                t.cancel()

    @staticmethod
    def _match(row, o: Outcome, asset: Asset, page_url, specific, size, videos, found_via, title) -> dict:
        return {
            "id": uuid.uuid4().hex[:8],
            "domain": row["domain"],
            "page_url": page_url,
            "page_specific": specific,
            "image_url": asset.url,
            "alt_image_urls": [],
            "videos": [{"url": v.url, "kind": v.kind} for v in _dedupe_videos(videos)][:5],
            "title": (asset.title or title or None),
            "match_type": o.match_type, "method": o.method, "variant": o.variant,
            "confidence": o.confidence, "inliers": o.inliers, "inlier_ratio": o.inlier_ratio,
            "category": "strong" if o.match_type in STRONG else "possible",
            "verified_on_page": False,
            "main_hit": asset.source in ("meta", "jsonld") and specific,
            "found_via": found_via,
            "network": row.get("network") or None,
            "image_size": list(size),
        }

    def _consolidate(self, matches: list) -> list:
        groups: dict = {}
        for m in matches:
            key = (m["domain"], m["page_url"] if m["page_specific"] else m["image_url"])
            cur = groups.get(key)
            if cur is None:
                groups[key] = m
                continue
            best, other = (m, cur) if m["confidence"] > cur["confidence"] else (cur, m)
            best["alt_image_urls"] = list(dict.fromkeys(best["alt_image_urls"] + other["alt_image_urls"] + [other["image_url"]]))[:6]
            seen = {v["url"] for v in best["videos"]}
            best["videos"] += [v for v in other["videos"] if v["url"] not in seen]
            best["main_hit"] = best["main_hit"] or other["main_hit"]
            best["title"] = best["title"] or other["title"]
            groups[key] = best
        out = list(groups.values())
        for m in out:
            self._finalize(m)
        out.sort(key=lambda m: (m["verified_on_page"], m["category"] == "strong", m["confidence"]), reverse=True)
        return out

    @staticmethod
    def _finalize(m: dict) -> None:
        """'verified' = the page's OWN main image matched AND at least one other, different image matched too."""
        distinct = {m["image_url"], *m["alt_image_urls"]}
        m["verified_on_page"] = bool(m["main_hit"] and len(distinct) >= 2)
        if m["verified_on_page"]:
            m["category"] = "strong"

    async def _refine(self, st: State, m: dict) -> None:
        """Open the matched page: collect video URLs + title, and re-test the page's own main image."""
        if not m["page_specific"] or not m["page_url"] or st.cancel.is_set():
            return
        f = await st.http.page(m["page_url"])
        if not f.ok:
            return
        parsed = parse_html(f.text(), m["page_url"])
        seen = {v["url"] for v in m["videos"]}
        m["videos"] += [{"url": v.url, "kind": v.kind} for v in parsed.videos if v.url not in seen]
        m["videos"] = m["videos"][:6]
        if not m["title"] and parsed.title:
            m["title"] = parsed.title
        mains = [a for a in parsed.assets if a.source in ("meta", "jsonld")][:4]
        loop = asyncio.get_running_loop()
        for a in mains:
            img = await st.http.image(a.url, referer=m["page_url"])
            if not img.ok or not img.content:
                continue
            res = await loop.run_in_executor(st.pool, _compare_bytes, st.reference, img.content)
            if res and res[0] is not None and res[0].match_type in STRONG:
                m["main_hit"] = True
                if a.url != m["image_url"]:
                    m["alt_image_urls"] = list(dict.fromkeys(m["alt_image_urls"] + [a.url]))[:6]
                m["confidence"] = max(m["confidence"], res[0].confidence)
                break
        self._finalize(m)

    @staticmethod
    def _coverage(st: State, crawlers: dict) -> dict:
        counts = {"checked": 0, "no_images": 0, "blocked": 0, "unreachable": 0, "skipped": 0, "not_reached": 0}
        detail = {}
        for domain, d in st.dom.items():
            c = crawlers[domain]
            if d["state"] == "queued":
                status = "not_reached"
            elif d["candidates"] > 0:
                status = "checked"
            elif d["skipped"] > 0:
                status = "skipped"
            elif c.stats["ok"] > 0:
                status = "no_images"
            elif c.stats["blocked"] > 0:
                status = "blocked"
            else:
                status = "unreachable"
            counts[status] += 1
            detail[domain] = {"status": status, "pages": c.pages_fetched, "candidates": d["candidates"],
                              "image_failures": d["img_fail"], "too_small": d["small"], "seconds": d["seconds"],
                              "cut_by": d["cut_by"],            # time | images | pages | None (= finished within limits)
                              "sources": dict(c.sources),
                              "reason": c.last_reason if status in ("blocked", "unreachable") else ""}
        return {"summary": counts, "domains": detail}
