"""All tunables in one place. Every value can be overridden with an env var (CE_<NAME>)."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(f"CE_{name}", default))
    except ValueError:
        return default


def _flag(name: str, default: bool = False) -> bool:
    return os.getenv(f"CE_{name}", "1" if default else "0") == "1"


INTEL_CSV = Path(os.getenv("CE_INTEL_CSV", ROOT / "data" / "intelligence.csv"))
TAKEDOWN_CSV = Path(os.getenv("CE_TAKEDOWN_CSV", ROOT / "data" / "takedown.csv"))

# ── Crawl budgets ──────────────────────────────────────────────────────────
PAGES_PER_DOMAIN = _int("PAGES_PER_DOMAIN", 40)        # HTML pages fetched per domain in pass 1
BONUS_PAGES = _int("BONUS_PAGES", 80)                  # extra pages for domains that produced a match (pass 2)
ASSETS_PER_PAGE = _int("ASSETS_PER_PAGE", 60)
STRUCTURED_ASSETS = _int("STRUCTURED_ASSETS", 600)     # assets taken from sitemaps / WP API / feeds per domain
SITEMAP_FILES = _int("SITEMAP_FILES", 8)
MAX_CANDIDATES = _int("MAX_CANDIDATES", 25000)         # total images compared per scan
SCAN_TIMEOUT = _int("SCAN_TIMEOUT", 900)               # seconds

# ── Network ────────────────────────────────────────────────────────────────
HTTP_TIMEOUT = _int("HTTP_TIMEOUT", 12)
GLOBAL_CONCURRENCY = _int("GLOBAL_CONCURRENCY", 64)
PER_HOST_CONCURRENCY = _int("PER_HOST_CONCURRENCY", 6)
MAX_IMAGE_BYTES = 4 * 1024 * 1024
MAX_HTML_BYTES = 3 * 1024 * 1024
MAX_XML_BYTES = 8 * 1024 * 1024
RETRIES = _int("RETRIES", 2)
ALLOW_PRIVATE = _flag("ALLOW_PRIVATE")                 # tests only: disables the SSRF guard
LIVE_CONTACT_LOOKUP = _flag("LIVE_CONTACT_LOOKUP", True)
RDAP_LOOKUP = _flag("RDAP_LOOKUP", True)

# ── CPU ────────────────────────────────────────────────────────────────────
CPU_WORKERS = _int("CPU_WORKERS", max(2, os.cpu_count() or 2))
