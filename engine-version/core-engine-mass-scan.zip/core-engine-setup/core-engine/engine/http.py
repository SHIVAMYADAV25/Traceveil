"""Polite, bounded, retrying async HTTP client used for every request the engine makes."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import io
from typing import Optional
from urllib.parse import urlparse

import httpx
from PIL import Image

from . import config, netguard

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0.0.0 Safari/537.36")
BOT_MARKERS = (b"just a moment", b"cf-chl", b"attention required", b"captcha", b"access denied", b"ddos protection")


DEAD_AFTER = 5                      # consecutive failed requests before a host is skipped for the rest of the scan
_PEEK_AT = (1024, 8192, 65536)      # byte counts at which we try to read the image size from the header


def _peek_size(buf: bytes):
    try:
        return Image.open(io.BytesIO(buf)).size
    except Exception:
        return None


@dataclass
class Fetched:
    status: str                       # ok | blocked | error | timeout
    content: Optional[bytes] = None
    url: str = ""
    code: Optional[int] = None
    ctype: str = ""
    reason: str = ""

    @property
    def ok(self) -> bool:
        return self.status == "ok" and self.content is not None

    def text(self) -> str:
        if not self.content:
            return ""
        for enc in ("utf-8", "latin-1"):
            try:
                return self.content.decode(enc)
            except UnicodeDecodeError:
                continue
        return ""


class Http:
    def __init__(self):
        self.client = httpx.AsyncClient(
            headers={"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"},
            timeout=httpx.Timeout(config.HTTP_TIMEOUT),
            follow_redirects=True,
            limits=httpx.Limits(max_connections=config.GLOBAL_CONCURRENCY * 2, max_keepalive_connections=24),
            event_hooks={"request": [netguard.request_hook]},
        )
        self._global = asyncio.Semaphore(config.GLOBAL_CONCURRENCY)
        self._hosts: dict[str, asyncio.Semaphore] = {}
        self._fails: dict[str, int] = {}              # consecutive transport failures per host
        self._dead: dict[str, Fetched] = {}           # circuit breaker: host gave up -> fail instantly
        self.requests = 0

    async def close(self) -> None:
        await self.client.aclose()

    def _host_sem(self, host: str) -> asyncio.Semaphore:
        sem = self._hosts.get(host)
        if sem is None:
            sem = self._hosts[host] = asyncio.Semaphore(config.PER_HOST_CONCURRENCY)
        return sem

    def _bad(self, host: str, f: Fetched) -> Fetched:
        n = self._fails[host] = self._fails.get(host, 0) + 1
        if n >= DEAD_AFTER:
            self._dead[host] = Fetched(f.status, url=f.url, code=f.code, reason=f.reason + " (host skipped)")
        return f

    async def get(self, url: str, *, max_bytes: int, referer: Optional[str] = None,
                  accept: str = "*/*", want_image: bool = False, retries: Optional[int] = None,
                  timeout: Optional[float] = None, min_side: int = 0) -> Fetched:
        headers = {"Accept": accept}
        if referer:
            headers["Referer"] = referer
        host = urlparse(url).netloc
        dead = self._dead.get(host)
        if dead is not None:
            return dead                                           # circuit open: don't burn time on a dead host
        tries = config.RETRIES if retries is None else retries
        req_timeout = httpx.Timeout(timeout) if timeout else None
        last = Fetched("error", url=url, reason="no attempt")
        async with self._host_sem(host), self._global:           # host first: never hog global slots while queued
            for attempt in range(tries + 1):
                self.requests += 1
                try:
                    async with self.client.stream("GET", url, headers=headers, **({"timeout": req_timeout} if req_timeout else {})) as r:
                        code = r.status_code
                        ctype = r.headers.get("content-type", "").lower()
                        if code in (401, 403, 451):
                            return Fetched("blocked", url=str(r.url), code=code, reason=f"HTTP {code}")
                        if code in (429, 502, 503, 504):
                            last = Fetched("blocked" if code in (429, 503) else "error", url=str(r.url), code=code, reason=f"HTTP {code}")
                            await asyncio.sleep(0.6 * (2 ** attempt))
                            continue
                        if code >= 400:
                            return Fetched("error", url=str(r.url), code=code, reason=f"HTTP {code}")
                        if want_image and ("text/html" in ctype or "json" in ctype):
                            return Fetched("error", url=str(r.url), code=code, ctype=ctype, reason="not an image")
                        if want_image:
                            try:
                                if int(r.headers.get("content-length", "0")) > max_bytes:
                                    return Fetched("error", url=str(r.url), code=code, reason="too large")
                            except ValueError:
                                pass
                        chunks, total = [], 0
                        peeked = 0
                        async for chunk in r.aiter_bytes():
                            total += len(chunk)
                            if total > max_bytes:
                                if want_image:
                                    return Fetched("error", url=str(r.url), code=code, reason="too large")
                                chunks.append(chunk[: len(chunk) - (total - max_bytes)])
                                break
                            chunks.append(chunk)
                            if want_image and min_side and peeked < len(_PEEK_AT) and total >= _PEEK_AT[peeked]:
                                peeked += 1
                                size = _peek_size(b"".join(chunks))
                                if size is not None:
                                    peeked = len(_PEEK_AT)
                                    if min(size) < min_side:      # icon / spacer: stop downloading right here
                                        self._fails[host] = 0
                                        return Fetched("error", url=str(r.url), code=code, reason="too small")
                        body = b"".join(chunks)
                        head = body[:4000].lower()
                        if not want_image and code == 200 and any(m in head for m in BOT_MARKERS) and len(body) < 60_000:
                            return Fetched("blocked", url=str(r.url), code=code, reason="bot protection page")
                        self._fails[host] = 0
                        return Fetched("ok", content=body, url=str(r.url), code=code, ctype=ctype)
                except netguard.BlockedAddress as exc:
                    return Fetched("blocked", url=url, reason=str(exc))
                except httpx.TimeoutException:
                    last = Fetched("timeout", url=url, reason="timeout")
                    if req_timeout is not None:
                        break                                   # caller asked for a short timeout: a retry would just double the wait
                except httpx.HTTPError as exc:
                    last = Fetched("error", url=url, reason=type(exc).__name__)
                await asyncio.sleep(0.4 * (2 ** attempt))
        return self._bad(host, last)

    async def page(self, url: str) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_HTML_BYTES,
                              accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

    async def xml(self, url: str) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_XML_BYTES, accept="application/xml,text/xml,*/*")

    async def image(self, url: str, referer: Optional[str] = None, min_side: int = 0) -> Fetched:
        return await self.get(url, max_bytes=config.MAX_IMAGE_BYTES, referer=referer, retries=1, min_side=min_side,
                              accept="image/avif,image/webp,image/apng,image/*,*/*;q=0.8", want_image=True)
