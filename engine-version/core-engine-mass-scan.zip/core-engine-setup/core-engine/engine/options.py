"""
All scan limits in ONE object.  Every value can be set three ways (later wins):

    1. profile            quick | balanced | deep
    2. env var            CE_<NAME>=...            (see config.py for network settings)
    3. per-scan override  CLI flag / API field / Options(**kw)

Master control is `time_budget` (seconds, hard wall-clock limit for the whole scan).
Everything else shapes how that time is spent.
"""
from __future__ import annotations

import os
from dataclasses import asdict, dataclass, fields, replace
from typing import Optional

# name -> (quick, balanced, deep)
_PROFILES = {
    #                     quick  balanced  deep
    "time_budget":        (90,   240,      900),    # whole scan, seconds (HARD limit)
    "max_sites":          (0,    0,        0),      # 0 = every selected site
    "site_parallel":      (20,   16,       12),     # sites crawled at the same time
    "site_time":          (0,    0,        0),      # seconds per site, 0 = auto-fit to time_budget
    "site_pages":         (12,   30,       120),    # HTML pages per site, pass 1
    "site_images":        (150,  400,      1500),   # candidate images per site, pass 1
    "page_assets":        (40,   60,       150),    # images taken from one page
    "structured_assets":  (150,  400,      1000),   # images taken from sitemaps / WP API / RSS per site
    "sitemap_files":      (3,    6,        15),
    "image_parallel":     (6,    8,        6),      # concurrent image downloads per site
    "bonus_pages":        (30,   80,       250),    # extra pages for a site that matched (pass 2)
    "bonus_images":       (300,  800,      3000),
    "pass1_share":        (70,   65,       60),     # % of time_budget given to pass 1
    "min_side_px":        (64,   48,       40),     # skip images smaller than this (read from header)
    "geometric":          (0,    2,        1),      # 0 hash only | 1 hash+SIFT on every image | 2 hash sweep first, SIFT re-check of cached images with leftover time
    "stop_after_strong":  (0,    0,        0),      # stop early once N strong matches exist (0 = never)
    "css_backgrounds":    (0,    0,        1),      # fetch stylesheets to find CSS background images
}
_PROFILE_INDEX = {"quick": 0, "balanced": 1, "deep": 2}
_FIELDS = tuple(_PROFILES)


@dataclass(frozen=True)
class Options:
    profile: str = "balanced"
    time_budget: int = 240
    max_sites: int = 0
    site_parallel: int = 16
    site_time: int = 0
    site_pages: int = 30
    site_images: int = 400
    page_assets: int = 60
    structured_assets: int = 400
    sitemap_files: int = 6
    image_parallel: int = 8
    bonus_pages: int = 80
    bonus_images: int = 800
    pass1_share: int = 65
    min_side_px: int = 48
    geometric: int = 1
    stop_after_strong: int = 0
    css_backgrounds: int = 0
    # site selection (not part of profiles)
    skip_sites: int = 0                      # skip the first N selected sites (scan "the next batch")
    order: str = "dataset"                   # dataset | shuffle | smallest_first (reserved)

    # ── build ──────────────────────────────────────────────────────────────
    @classmethod
    def make(cls, profile: Optional[str] = None, **overrides) -> "Options":
        profile = (profile or os.getenv("CE_PROFILE") or "balanced").lower()
        if profile not in _PROFILE_INDEX:
            raise ValueError(f"profile must be one of {', '.join(_PROFILE_INDEX)}")
        i = _PROFILE_INDEX[profile]
        values = {k: _PROFILES[k][i] for k in _FIELDS}
        for k in _FIELDS:                                         # env overrides the profile
            raw = os.getenv(f"CE_{k.upper()}")
            if raw not in (None, ""):
                try:
                    values[k] = int(raw)
                except ValueError:
                    pass
        for k, v in overrides.items():                            # explicit overrides win
            if v is None:
                continue
            if k not in {f.name for f in fields(cls)} or k == "profile":
                raise ValueError(f"unknown option: {k}")
            values[k] = v if k == "order" else int(v)
        return cls(profile=profile, **values).clamped()

    def clamped(self) -> "Options":
        c = lambda v, lo, hi: max(lo, min(hi, int(v)))
        return replace(
            self,
            time_budget=c(self.time_budget, 5, 7200), max_sites=c(self.max_sites, 0, 100000),
            site_parallel=c(self.site_parallel, 1, 64), site_time=c(self.site_time, 0, 3600),
            site_pages=c(self.site_pages, 1, 2000), site_images=c(self.site_images, 1, 50000),
            page_assets=c(self.page_assets, 1, 1000), structured_assets=c(self.structured_assets, 1, 50000),
            sitemap_files=c(self.sitemap_files, 0, 100), image_parallel=c(self.image_parallel, 1, 32),
            bonus_pages=c(self.bonus_pages, 0, 5000), bonus_images=c(self.bonus_images, 0, 100000),
            pass1_share=c(self.pass1_share, 20, 100), min_side_px=c(self.min_side_px, 16, 400),
            geometric=c(self.geometric, 0, 2), stop_after_strong=c(self.stop_after_strong, 0, 1000),
            css_backgrounds=1 if self.css_backgrounds else 0, skip_sites=c(self.skip_sites, 0, 100000),
        )

    @classmethod
    def from_config(cls) -> "Options":
        """Back-compat: the legacy single-site mode tunes engine.config directly."""
        from . import config
        return cls.make("balanced", site_pages=config.PAGES_PER_DOMAIN, page_assets=config.ASSETS_PER_PAGE,
                        structured_assets=config.STRUCTURED_ASSETS, sitemap_files=config.SITEMAP_FILES,
                        bonus_pages=config.BONUS_PAGES)

    def public(self) -> dict:
        return asdict(self)

    # ── derived ────────────────────────────────────────────────────────────
    def pass1_seconds(self, will_deepen: bool = True) -> float:
        return self.time_budget * (self.pass1_share / 100 if will_deepen else 1.0)

    def auto_site_time(self, n_sites: int, pass_seconds: float) -> float:
        """Seconds each site may use so that n_sites fit into pass_seconds at the given parallelism."""
        if self.site_time:
            return float(self.site_time)
        waves = max(1.0, n_sites / self.site_parallel)
        return max(6.0, min(60.0, pass_seconds / waves))


def profiles_table() -> dict:
    return {name: {k: _PROFILES[k][i] for k in _FIELDS} for name, i in _PROFILE_INDEX.items()}
