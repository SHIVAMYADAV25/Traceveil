"""Command line:   python cli.py scan photo.jpg [--domains a.com,b.com] [--out result.json]
                  python cli.py serve [--port 8000]"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import re

from engine.options import Options, profiles_table
from engine.scan import Scanner

# CLI flag -> Options field.  Every one is optional; omitted = value from --profile (or CE_<NAME> env var).
OPTION_FLAGS = {
    "time_budget": "total seconds for the whole scan (hard limit)",
    "max_sites": "scan at most N sites (0 = all selected)",
    "skip_sites": "skip the first N sites (scan the next batch)",
    "site_parallel": "sites crawled at the same time",
    "site_time": "max seconds per site (0 = auto-fit to the time budget)",
    "site_pages": "HTML pages per site (pass 1)",
    "site_images": "candidate images per site (pass 1)",
    "page_assets": "images taken from one page",
    "structured_assets": "images taken from sitemaps / WP API / RSS per site",
    "sitemap_files": "sitemap files read per site",
    "image_parallel": "concurrent image downloads per site",
    "bonus_pages": "extra pages for sites that matched (pass 2)",
    "bonus_images": "extra images for sites that matched (pass 2)",
    "min_side_px": "skip images smaller than this many pixels",
    "geometric": "0 hash only | 1 hash+SIFT on every image | 2 hash sweep then SIFT re-check with leftover time",
    "stop_after_strong": "stop early after N strong matches (0 = never)",
    "css_backgrounds": "1 = also read stylesheets for CSS background images",
    "pass1_share": "percent of the time budget for the first sweep",
}


def _options(args) -> Options:
    over = {k: getattr(args, k) for k in OPTION_FLAGS if getattr(args, k, None) is not None}
    return Options.make(args.profile, **over)


async def _scan(args) -> int:
    data = open(args.image, "rb").read()
    opts = _options(args)
    last = {"line": ""}

    def progress(p: dict) -> None:
        line = (f"[{p.get('phase','')}] sites {p.get('domains_done',0)}/{p.get('domains_total',0)} "
                f"(running {p.get('domains_running',0)}, waiting {p.get('domains_remaining',0)})  "
                f"pages {p.get('pages',0)}  images {p.get('candidates',0)}  matches {p.get('matches',0)}  "
                f"time left {int(p.get('time_left',0))}s")
        if line != last["line"]:
            last["line"] = line
            print(line, file=sys.stderr)

    domains = [d for d in (args.domains or "").split(",") if d]
    if args.resume:                                     # continue with what an earlier scan did not reach
        prev = json.load(open(args.resume, encoding="utf-8"))
        domains = prev.get("remaining_domains") or []
        if not domains:
            print("Nothing remaining in that result file.", file=sys.stderr)
            return 0
    result = await Scanner().scan(data, domains=domains, progress=progress, options=opts)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2)
        print(f"full result written to {args.out}", file=sys.stderr)
    sites = result["sites"]
    print(f"\n{len(result['matches'])} match(es) in {result['duration_s']}s   coverage: {result['coverage']['summary']}")
    print(f"sites: {sites['scanned']}/{sites['selected']} scanned this run, {len(result['remaining_domains'])} remaining"
          f"{'  (continue with: --resume ' + args.out + ')' if result['remaining_domains'] and args.out else ''}")
    cut = [d for d, v in result["coverage"]["domains"].items() if v.get("cut_by")]
    if cut:
        print(f"{len(cut)} site(s) stopped by a limit (raise --time-budget / --site-pages / --site-images to go deeper)")
    for m in result["matches"]:
        c = m.get("contact") or {}
        print(f"\n[{m['category'].upper()}{' / VERIFIED' if m['verified_on_page'] else ''}] {m['domain']}  {m['confidence']:.0f}%  ({m['match_type']}, {m['method']})")
        print(f"  page : {m['page_url']}")
        print(f"  image: {m['image_url']}")
        for v in m["videos"]:
            print(f"  video: {v['url']}  ({v['kind']})")
        for e in c.get("emails", [])[:3]:
            print(f"  email: {e['email']}  ({e['source']})")
        for p in c.get("removal_pages", [])[:2]:
            print(f"  form : {p['url']}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan")
    s.add_argument("image")
    s.add_argument("--domains", help="comma separated; default = all 91 dataset domains")
    s.add_argument("--out", help="write full JSON result here")
    s.add_argument("--profile", default=None, choices=list(profiles_table()), help="quick | balanced | deep (default balanced)")
    s.add_argument("--resume", help="a previous --out file: scan only the sites it did not reach")
    for name, helptext in OPTION_FLAGS.items():
        s.add_argument("--" + name.replace("_", "-"), dest=name, type=int, default=None, help=helptext)
    sub.add_parser("profiles", help="show what quick / balanced / deep set")
    one = sub.add_parser("single", help="deep-inspect exactly one website URL")
    one.add_argument("image", help="reference image to search for")
    one.add_argument("url", help="one target website URL, e.g. https://example.com/")
    one.add_argument("--outdir", default=None, help="output folder (default: inspection-results/<host>-<timestamp>)")
    one.add_argument("--max-pages", type=int, default=500, help="maximum HTML pages to visit")
    one.add_argument("--max-images", type=int, default=15000, help="maximum unique image URLs to inspect")
    one.add_argument("--assets-per-page", type=int, default=250, help="maximum image candidates taken from each page")
    one.add_argument("--sitemap-limit", type=int, default=40, help="maximum sitemap documents to inspect")
    v = sub.add_parser("serve")
    v.add_argument("--port", type=int, default=8000)
    v.add_argument("--host", default="127.0.0.1")
    args = ap.parse_args()
    if args.cmd == "profiles":
        table = profiles_table()
        names = list(table)
        print(f"{'option':20s}" + "".join(f"{n:>10s}" for n in names))
        for k in table[names[0]]:
            print(f"{k:20s}" + "".join(f"{table[n][k]:>10}" for n in names))
        return 0
    if args.cmd == "serve":
        import uvicorn
        uvicorn.run("server:app", host=args.host, port=args.port)
        return 0
    if args.cmd == "single":
        from datetime import datetime
        from pathlib import Path
        from engine.single_site import inspect_single_site, normalize_target
        host, target = normalize_target(args.url)
        outdir = args.outdir or str(Path("inspection-results") / (
            re.sub(r"[^a-zA-Z0-9.-]+", "_", host) + "-" + datetime.now().strftime("%Y%m%d-%H%M%S")))
        async def run_single():
            data = Path(args.image).read_bytes()
            result = await inspect_single_site(
                data, target, outdir, max_pages=max(1, args.max_pages),
                max_images=max(1, args.max_images), page_asset_limit=max(1, args.assets_per_page),
                sitemap_limit=max(1, args.sitemap_limit))
            print("\n=== SINGLE WEBSITE INSPECTION SUMMARY ===")
            print(json.dumps(result, indent=2))
        asyncio.run(run_single())
        return 0
    return asyncio.run(_scan(args))


if __name__ == "__main__":
    sys.exit(main())
