"""Minimal HTTP API + one-page UI.   Run:  uvicorn server:app --port 8000"""
from __future__ import annotations

import asyncio
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from engine.fingerprint import MIN_SIDE, open_image
from engine.options import Options, profiles_table
from engine.scan import Scanner

STATIC = Path(__file__).parent / "static"
MAX_UPLOAD = 12 * 1024 * 1024
MAX_RUNNING = 2
KEEP_JOBS = 30

app = FastAPI(title="core-engine", docs_url="/docs")
scanner = Scanner()
JOBS: dict[str, dict] = {}


def _public(job: dict) -> dict:
    return {k: v for k, v in job.items() if k not in ("task", "cancel")}


OPTION_FIELDS = ("time_budget", "max_sites", "skip_sites", "site_parallel", "site_time", "site_pages", "site_images",
                 "page_assets", "structured_assets", "image_parallel", "bonus_pages", "bonus_images", "min_side_px",
                 "geometric", "stop_after_strong", "css_backgrounds", "pass1_share", "sitemap_files")


async def _run(job_id: str, data: bytes, domains: list[str], options: Options) -> None:
    job = JOBS[job_id]

    def progress(p: dict) -> None:
        job["progress"] = p

    try:
        job["result"] = await scanner.scan(data, domains=domains or None, progress=progress, cancel=job["cancel"], options=options)
        job["status"] = "cancelled" if job["cancel"].is_set() else "completed"
    except ValueError as exc:
        job["status"], job["error"] = "failed", str(exc)
    except Exception:                                      # noqa: BLE001
        job["status"], job["error"] = "failed", "The scan failed unexpectedly."
    job["finished_at"] = time.time()


@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
async def health():
    return {"ok": True, "domains": len(scanner.rows)}


@app.get("/api/options")
async def get_options():
    """Profiles and every tunable (with the balanced defaults) - the UI/clients build their controls from this."""
    return {"profiles": profiles_table(), "defaults": Options.make("balanced").public(), "total_sites": len(scanner.rows)}


@app.post("/api/scan", status_code=202)
async def start_scan(request: Request, file: UploadFile = File(...), domains: str = Form(""), profile: str = Form("balanced"),
                     resume_scan_id: str = Form("")):
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Image is larger than 12 MB.")
    img = open_image(data)
    if img is None or min(img.size) < MIN_SIDE:
        raise HTTPException(400, "That file could not be read as a usable image (JPEG, PNG or WebP).")
    form = await request.form()
    overrides = {}
    for k in OPTION_FIELDS:                       # any tunable can be sent as a plain form field; blank = profile default
        v = form.get(k)
        if v not in (None, ""):
            try:
                overrides[k] = int(v)
            except ValueError:
                raise HTTPException(400, f"{k} must be a whole number.")
    try:
        options = Options.make(profile, **overrides)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    wanted = [d.strip() for d in domains.split(",") if d.strip()]
    if resume_scan_id:                            # continue with the sites an earlier scan did not get to
        prev = JOBS.get(resume_scan_id)
        if prev is None or not prev.get("result"):
            raise HTTPException(404, "That earlier scan has no result to resume from.")
        wanted = list(prev["result"].get("remaining_domains") or [])
        if not wanted:
            raise HTTPException(400, "Nothing remaining: the earlier scan covered every selected site.")
    if sum(1 for j in JOBS.values() if j["status"] == "running") >= MAX_RUNNING:
        raise HTTPException(429, "The server is already running the maximum number of scans. Retry in a minute.")
    job_id = uuid.uuid4().hex[:12]
    job = {"id": job_id, "status": "running", "created_at": time.time(), "finished_at": None, "progress": {"phase": "starting"},
           "result": None, "error": None, "cancel": asyncio.Event(), "options": options.public()}
    JOBS[job_id] = job
    job["task"] = asyncio.create_task(_run(job_id, data, wanted, options))
    for old in sorted((j for j in JOBS.values() if j["status"] != "running"), key=lambda j: j["created_at"])[:-KEEP_JOBS]:
        JOBS.pop(old["id"], None)
    return {"scan_id": job_id, "options": options.public()}


@app.get("/api/scan/{scan_id}")
async def get_scan(scan_id: str):
    job = JOBS.get(scan_id)
    if job is None:
        raise HTTPException(404, "Unknown scan id.")
    return _public(job)


@app.post("/api/scan/{scan_id}/cancel")
async def cancel_scan(scan_id: str):
    job = JOBS.get(scan_id)
    if job is None:
        raise HTTPException(404, "Unknown scan id.")
    job["cancel"].set()
    return {"ok": True}
