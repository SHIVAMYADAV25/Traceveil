# core-engine

Reverse-image leak discovery, reduced to the core: **image in → matching pages, image URLs, video URLs, contacts out.**
Uses the same 91 monitored domains and the same contact datasets as the original project (`data/`).

```
image ─► fingerprint ─► crawl 91 sites ─► fingerprint every candidate ─► tiered match
                                                         │
        removal-request draft ◄─ contacts ◄─ verify on page + video URLs ◄─┘
```

## Run

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python cli.py serve                       # UI at http://127.0.0.1:8000
python cli.py scan photo.jpg --out result.json            # all 91 sites
python cli.py scan photo.jpg --domains example.com,other.net   # specific sites
```
Python 3.10+ (tested on 3.12). Default scan of all 91 sites is limited to 240 s (`--profile quick` = 90 s); progress is live.

## Why the search finds more than before

| Weakness of a one-shot crawl | What this engine does |
|---|---|
| Only homepage links, ~15 pages | Pulls candidates from **sitemaps (image + video sitemaps incl.)**, **WordPress REST API**, **RSS/Atom**, then a **score-prioritised BFS** that follows pagination and categories |
| Thumbnail found, page unknown | Thumbnails wrapped in `<a>` keep their **content-page URL + title** |
| Misses lazy-loaded images | `data-src`/`data-original`/…, `srcset`, `<picture>`, `<noscript>`, CSS backgrounds, `og:image`, JSON-LD |
| Fixed budget everywhere | **Adaptive 2nd pass**: matched sites get a big extra budget, the matched page is crawled first (related videos), and sister sites on the same network / video CDN are searched deeper |
| One hash vs one image | Hashes compared across **variants of both sides**: mirror, centre crops, 3×3 sub-windows at 2 scales, letterbox-trimmed |
| Hashes fail on heavy edits | **RootSIFT + Lowe ratio + mutual-best + RANSAC**, spread check (a shared watermark/logo can't cause a match), small thumbnails are upscaled |
| "Not found" vs "couldn't check" | Per-site coverage: checked / no_images / blocked / unreachable / skipped |
| Match = a thumbnail only | **Refine**: opens the matched page, extracts **direct / stream / embed video URLs**, re-tests the page's own main image → `verified_on_page` |

Contacts per matched domain: your datasets → live scrape (`/contact`, `/dmca`, `/abuse`, mailto links) → registrar abuse (RDAP) → hosting abuse (RDAP of the site's IP). Every address is labelled with its source. A ready removal request (text + `mailto:`) is generated per domain.

## Result shape (`GET /api/scan/{id}` → `result`)
`matches[]`: `domain, page_url, image_url, alt_image_urls, videos[{url,kind}], title, match_type (exact|near_duplicate|structural|probable), confidence, category (strong|possible), verified_on_page, found_via, contact{network, emails[{email,source}], removal_pages[]}` ·
`notices[]` · `related_domains[]` · `coverage{summary, domains{…}}` · `stats`.

## Tests (all included, all passing)
```bash
python tests/test_e2e.py       # 25 checks: 7 fake sites with different layouts, hidden edited copies, blocked/dead/clean sites
python tests/test_server.py    # API: validation, background job, polling, result
python tests/eval_matcher.py   # matcher: 26 edits x 9 targets -> 98.3% recall, 0/218 false positives
```
The tests use local fake sites because real ones can't be fetched from a build sandbox. **Real-site behaviour is the part you must verify yourself.**

## Fast mass scan (91 sites) — the controls

One master limit, everything else shapes how that time is spent:

```bash
python cli.py scan photo.jpg --profile quick                     # ~90 s  : fast sweep, hash matching
python cli.py scan photo.jpg                                     # ~240 s : balanced (default)
python cli.py scan photo.jpg --profile deep                      # ~900 s : deep, SIFT on every image
python cli.py scan photo.jpg --time-budget 120                   # your own hard time limit (seconds)
python cli.py scan photo.jpg --max-sites 30 --out r1.json        # only 30 sites this run ...
python cli.py scan photo.jpg --resume r1.json --max-sites 30     # ... then the NEXT sites that were not reached
python cli.py scan photo.jpg --skip-sites 60                     # skip the first 60, scan the rest
python cli.py scan photo.jpg --site-pages 60 --site-images 800   # per-site depth
python cli.py profiles                                           # table of what each profile sets
```

| Control | Meaning |
|---|---|
| `time_budget` | HARD wall-clock limit for the whole scan (seconds). The scan always returns by then. |
| `max_sites` / `skip_sites` | how many sites to scan this run / how many to skip first. Result carries `remaining_domains`. |
| `--resume result.json` (CLI), `resume_scan_id` (API) | scan exactly the sites the previous run did not reach |
| `site_parallel` | sites crawled at once (default 16) |
| `site_time` | seconds per site; `0` = automatic fair share of the time that is left |
| `site_pages`, `site_images`, `page_assets`, `structured_assets`, `sitemap_files` | per-site depth |
| `bonus_pages`, `bonus_images` | extra depth for sites that matched, and sister sites |
| `geometric` | `0` hash only · `1` hash+SIFT on every image · `2` hash sweep first, SIFT re-check of cached images with the time that is left |
| `min_side_px` | skip icons/spacers (decided from the image header, the download is aborted early) |
| `stop_after_strong` | stop early once N strong matches exist |
| `css_backgrounds` | also read stylesheets for CSS background images |

Any option can also be set with an env var `CE_<NAME>` (e.g. `CE_TIME_BUDGET=120`), as a form field on `POST /api/scan`
(`GET /api/options` lists them), or in the UI (speed profile, time limit, sites to scan, skip, advanced limits).

### How the time is spent
1. **Sweep** – every selected site gets a time-boxed slice (fair share of what is left). `site_parallel` sites run at once; a free slot immediately takes the next site. Dead / hanging sites are abandoned after ~7 s, and a host that fails 5 requests in a row is skipped for the rest of the scan.
2. **Pipeline** – each site crawls and checks images at the same time. Links are ordered by what has been *yielding new images* (dead-end patterns are demoted, pagination is promoted); sitemap / WP-API / RSS thumbnails go first.
3. **Continuation rounds** – sites that were cut short by a limit are resumed, most productive first, until the budget is used. Matched sites (and sister sites) get the bonus budget.
4. **Second look** (`geometric=2`) – images the fast hash sweep did not match are cached on disk and re-checked with the geometric matcher (finds heavily edited copies) in priority order with whatever time is left, concurrently with the crawl.
5. **Verify + contacts** – bounded by the same budget.

Result additions: `sites{selected, scanned, not_reached, not_selected}`, `remaining_domains`, `options` (what was actually used),
`coverage.domains[d].cut_by` = `time | images | pages | null` (tells you which limit to raise for that site),
`stats.second_look{queued, checked}`.

Fixes versus the previous mass scan: the 25 000-image cap was one shared pool (fast sites starved slow ones) → now per site;
the "already seen" set was global, so a sister site on the same CDN lost its match → now per site, with a shared verdict cache;
images over the per-page cap were marked seen and silently dropped; no per-site time limit (one hanging site stalled the whole pass);
crawl and image checking ran in lock-step. The geometric matcher now uses one matrix product instead of brute-force matching
(~8x faster, same rule: ratio test + mutual best + RANSAC; recall unchanged at 231/234, 0 false positives).

## Tuning (env vars, prefix `CE_`)
All options above plus network settings: `GLOBAL_CONCURRENCY` (64) · `PER_HOST_CONCURRENCY` (6) · `HTTP_TIMEOUT` · `RETRIES` · `LIVE_CONTACT_LOOKUP` · `RDAP_LOOKUP` · `CPU_WORKERS` (default: CPU count).
`PAGES_PER_DOMAIN` / `BONUS_PAGES` / `MAX_CANDIDATES` / `SCAN_TIMEOUT` are only used by the single-site mode now.

## Tests
```bash
python tests/test_e2e.py       # 25 checks, 7 fake site layouts
python tests/test_mass.py      # 91 sites: slow / hanging / blocked / dead; time limit, max_sites, skip, resume
python tests/test_server.py    # API incl. profiles, max_sites, resume
python tests/eval_matcher.py   # matcher regression
```

## Known limits
* Sites that render everything with JavaScript expose no images to a plain HTTP crawler (sitemaps/RSS/API help when present). A headless browser could be added as an optional fetcher.
* Bot protection (Cloudflare challenges, 403/429) is detected and reported as `blocked`; it is not bypassed. ISP-level blocking of these domains (common in some countries) shows as `blocked`/`unreachable`: run from a network that can reach them.
* Matching uses thumbnails/posters/main images, not video frames. Video URLs are reported but the video itself is not downloaded or frame-matched.
* RDAP lookups and live contact scraping depend on third-party servers; they are best-effort.
* Scans are held in memory (last 30 kept); restart clears them.
* `SSRF guard` is on by default (public IPs only). `CE_ALLOW_PRIVATE=1` disables it and exists for the local test sites only.


## Deep inspection of exactly one website

The `single` command is an isolated inspection mode. It does **not** use the 91-site
intelligence list, does not search related domains, and does not follow external HTML
links. It accepts one website URL and crawls that exact host only. Images hosted on
external CDNs but embedded in pages on the target site can be downloaded as image
assets; those CDN hosts are never crawled as websites.

From the `core-engine` directory:

```powershell
python cli.py single .\path\to\reference.jpg https://example.com/ `
  --max-pages 500 `
  --max-images 15000 `
  --assets-per-page 250 `
  --sitemap-limit 40
```

If you omit `--outdir`, results are written to a timestamped folder under
`inspection-results/`.

The deep mode increases discovery budgets compared with the normal multi-site scan:
up to 500 HTML pages, 40 sitemap documents, 15,000 unique image URLs and 250 image
candidates per page by default. You can raise or lower these limits. The scan remains
bounded; it does not mean every URL on a site is guaranteed to be discoverable.

Output files:
- `scan-summary.json`: counts, limits and crawl statistics.
- `crawl-log.jsonl`: timestamped per-step event stream, including full page and image URLs.
- `pages.jsonl`: each visited page.
- `discovered-images.jsonl`: every unique discovered image URL, download outcome, saved file,
  pHash/dHash/aHash, hash distances and match decision.
- `matches.jsonl`: matched image records only.
- `images/`: downloaded usable candidate images.
- `reference-fingerprints.json`: reference hashes and generated variants.

The engine's existing pHash/dHash/aHash, crop/window and geometric SIFT/RANSAC matcher
is reused without changing its matching thresholds. Hash distances are Hamming distances;
lower values indicate more similar fingerprints. A missing match record does not mean
an image was not examined: check `discovered-images.jsonl` for every candidate and its
reason/status.

The crawler stays on the exact host from the supplied URL. It follows the existing
same-site link and sitemap discovery logic and uses the existing SSRF/network size
guards. It does not bypass login walls, CAPTCHAs, paywalls or access controls. Respect
the target site's robots.txt, terms and applicable law; the engine's current robots.txt
support is used for sitemap discovery, not a full Allow/Disallow policy evaluator.
