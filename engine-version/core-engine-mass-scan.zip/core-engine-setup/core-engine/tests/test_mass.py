"""Mass scan: 91 local sites (normal / slow / hanging / blocked / dead, copy hidden at different depths).
Checks the things that matter at scale: finishes inside the time budget, finds the copies, never stalls on bad
sites, and `max_sites` / `skip_sites` / `remaining_domains` behave."""
import asyncio, sys, time
sys.path.insert(0, ".")
from PIL import Image

from engine import config
config.ALLOW_PRIVATE = True
config.RDAP_LOOKUP = False
config.LIVE_CONTACT_LOOKUP = False

from engine.contacts import Contacts
from engine.options import Options
from engine.scan import Scanner
from tests.fakesites import Site, page, TARGET_PATH
from tests.variants import distractors, jpeg, thumb, watermark

N_IMG, PER_PAGE, PAGES = 60, 12, 8


def make_sites(target):
    dis = distractors()
    blobs = [jpeg(thumb(im, 320), 78) for im in dis.values()]
    copy = jpeg(thumb(watermark(target), 320), 80)
    sites, kinds = [], []

    def listing(s, copy_page=None):
        for k in range(N_IMG):
            s.add(f"/img/{k}.jpg", blobs[k % len(blobs)], "image/jpeg")
        if copy_page:
            s.add("/img/hidden.jpg", copy, "image/jpeg")
        for p in range(1, PAGES + 1):
            cells = []
            for j in range(PER_PAGE):
                k = (p * PER_PAGE + j) % N_IMG
                cells.append(f'<a href="/video/{p}-{j}-some-long-video-title"><img src="/img/{k}.jpg" alt="clip"></a>')
            if p == copy_page:
                cells.append('<a href="/video/hidden-clip-title"><img src="/img/hidden.jpg" alt="hot"></a>')
            nxt = f'<a href="/page/{p + 1}/">Next</a>' if p < PAGES else ""
            body = page("".join(cells) + nxt)
            s.add("/" if p == 1 else f"/page/{p}/", body)

    plan = (["copy"] * 6 + ["normal"] * 54 + ["slow"] * 6 + ["hang"] * 6 + ["blocked"] * 5 + ["dead"] * 14)
    copy_pages = iter([1, 2, 3, 4, 5, 6])
    dead_port = iter(range(2, 40))
    for kind in plan:
        s = Site(kind)
        if kind == "dead":
            s.port = next(dead_port)                  # nothing listens on these ports
            sites.append(s); kinds.append(kind)
            continue
        if kind == "blocked":
            s.add("*", "forbidden", "text/plain", 403)
        elif kind == "hang":
            s.delay = 40.0
            s.add("*", page("<p>x</p>"))
        else:
            if kind == "slow":
                s.delay = 0.35
            listing(s, next(copy_pages) if kind == "copy" else None)
        s.start()
        sites.append(s); kinds.append(kind)
    return sites, kinds


async def main():
    target = Image.open(TARGET_PATH).convert("RGB")
    sites, kinds = make_sites(target)
    for s in sites:                                   # lightweight latency on every working site
        if s.name in ("copy", "normal"):
            s.delay = 0.03
    rows = [{"domain": s.domain, "network": "", "provider_type": "", "video_provider": ""} for s in sites]
    copy_domains = {s.domain for s in sites if s.name == "copy"}
    data = open(TARGET_PATH, "rb").read()
    ok = True

    def check(name, cond, detail=""):
        nonlocal ok
        ok &= bool(cond)
        print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))

    try:
        sc = Scanner(rows=rows, contacts=Contacts())
        BUDGET = 100          # the 91 fake servers share this process (and 1 core) with the scanner, so give it room
        t0 = time.time()
        res = await sc.scan(data, options=Options.make("balanced", time_budget=BUDGET))
        el = time.time() - t0
        found = {m["domain"] for m in res["matches"]} & copy_domains
        cov = res["coverage"]["summary"]
        print(f"91 sites: {el:.1f}s  found {len(found)}/6  candidates={res['stats']['candidates_compared']}  "
              f"requests={res['stats']['requests']}  coverage={cov}  truncated={res['stats']['truncated']}")
        check("finishes inside the time budget", el <= BUDGET + 4, f"{el:.1f}s <= {BUDGET}s")
        check("finds the hidden copy on every copy site", len(found) == 6, f"{len(found)}/6")
        check("no match on any non-copy site", all(m["domain"] in copy_domains for m in res["matches"]))
        hang = [res["coverage"]["domains"][x.domain] for x in sites if x.name == "hang"]
        check("hanging sites were abandoned quickly (not 40s each)", all(h["status"] == "unreachable" and h["seconds"] < 25 for h in hang),
              str([h["seconds"] for h in hang]))
        check("dead/blocked sites reported", cov["blocked"] >= 4 and cov["unreachable"] >= 10, str(cov))
        check("every site accounted for", sum(cov.values()) == 91, str(sum(cov.values())))

        # ── site-count control + remaining ──
        r1 = await sc.scan(data, options=Options.make("quick", time_budget=40, max_sites=20))
        check("max_sites=20 scans only 20", r1["sites"]["selected"] == 20 and len(r1["remaining_domains"]) == 71,
              f"selected={r1['sites']['selected']} remaining={len(r1['remaining_domains'])}")
        r2 = await sc.scan(data, domains=r1["remaining_domains"], options=Options.make("quick", time_budget=40, max_sites=30))
        check("resume with remaining_domains continues where it stopped",
              r2["sites"]["selected"] == 30 and len(r2["remaining_domains"]) == 41 and not (set(r2["coverage"]["domains"]) & set(r1["coverage"]["domains"])),
              f"remaining={len(r2['remaining_domains'])}")
        r3 = await sc.scan(data, options=Options.make("quick", time_budget=40, skip_sites=80))
        check("skip_sites=80 leaves 11", r3["sites"]["selected"] == 11 and r3["sites"]["skipped_by_offset"] == 80)

        # ── hard time limit with a budget far too small for everything ──
        t0 = time.time()
        r4 = await sc.scan(data, options=Options.make("balanced", time_budget=12))
        el = time.time() - t0
        check("tiny budget still returns on time and reports what was not reached", el <= 12 + 4 and r4["stats"]["truncated"] is not None or r4["remaining_domains"] is not None,
              f"{el:.1f}s not_reached={len(r4['sites']['not_reached'])} scanned={r4['sites']['scanned']}")
        print("\nALL PASSED" if ok else "\nSOME CHECKS FAILED")
        return 0 if ok else 1
    finally:
        for s in sites:
            if s.server:
                s.stop()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
