"""Local fake sites that mimic real layouts. Each hides an edited copy of the target image."""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PIL import ImageOps

from tests.variants import distractors, jpeg, thumb, watermark

from pathlib import Path
TARGET_PATH = str(Path(__file__).parent / "assets" / "target.jpg")


class Site:
    def __init__(self, name):
        self.name = name
        self.routes: dict[str, tuple[int, str, bytes]] = {}
        self.server = None
        self.port = 0
        self.hits = 0
        self.delay = 0.0                       # artificial latency per request (seconds)

    @property
    def domain(self):
        return f"127.0.0.1:{self.port}"

    @property
    def base(self):
        return f"http://{self.domain}"

    def add(self, path, body, ctype="text/html", status=200):
        self.routes[path] = (status, ctype, body.encode() if isinstance(body, str) else body)

    def start(self):
        site = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                site.hits += 1
                if site.delay:
                    time.sleep(site.delay)
                path = self.path
                r = site.routes.get(path) or site.routes.get(path.split("?")[0]) or site.routes.get("*")
                if r is None:
                    r = (404, "text/plain", b"not found")
                self.send_response(r[0])
                self.send_header("Content-Type", r[1])
                self.send_header("Content-Length", str(len(r[2])))
                self.end_headers()
                self.wfile.write(r[2])

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def stop(self):
        if self.server:
            self.server.shutdown()


def page(body, head=""):
    return f"<html><head><title>Site</title>{head}</head><body>{body}</body></html>"


def build(target_img):
    from PIL import Image
    dis = distractors()
    names = list(dis)

    def d(i, w=320):                       # i-th unrelated thumbnail
        return jpeg(thumb(dis[names[i % len(names)]], w), 78)

    copy_wm = jpeg(thumb(watermark(target_img), 320), 80)
    copy_mirror = jpeg(thumb(ImageOps.mirror(target_img), 320), 80)
    w, h = target_img.size
    copy_crop = jpeg(thumb(target_img.crop((int(w * .15), int(h * .15), int(w * .85), int(h * .85))), 320), 80)
    copy_small = jpeg(thumb(target_img, 140), 70)
    copy_full = jpeg(thumb(target_img, 640), 85)
    sites: dict[str, Site] = {}

    def new(name):
        s = Site(name)
        s.start()
        sites[name] = s
        return s

    # A: paginated listing; copy on page 2 inside <a>; detail page has video + og:image
    A = new("paginated")
    for i in range(6):
        A.add(f"/img/a{i}.jpg", d(i), "image/jpeg")
    A.add("/img/target_wm.jpg", copy_wm, "image/jpeg")
    A.add("/img/target_full.jpg", copy_full, "image/jpeg")
    A.add("/", page("".join(f'<a href="/video/{i}-some-long-video-title-{i}"><img src="/img/a{i}.jpg" alt="clip {i}"></a>' for i in range(6))
                    + '<a href="/page/2/">Next</a>'))
    A.add("/page/2/", page('<a href="/video/777-target-video-title"><img src="/img/target_wm.jpg" alt="Hot clip 777"></a>'
                           + "".join(f'<a href="/video/{i}-some-long-video-title-{i}"><img src="/img/a{i}.jpg"></a>' for i in range(2, 4))))
    A.add("/video/777-target-video-title", page('<video controls><source src="/media/777.mp4" type="video/mp4"></video>',
                                                 '<meta property="og:image" content="/img/target_full.jpg">'))

    # B: nearly empty homepage, everything in a VIDEO sitemap; /dmca has an email (live contact scrape)
    B = new("sitemap")
    B.add("/img/b_t.jpg", copy_mirror, "image/jpeg")
    for i in range(5):
        B.add(f"/img/b{i}.jpg", d(i + 3), "image/jpeg")
    B.add("/", page("<h1>Welcome</h1><p>Loading...</p>"))
    B.add("/robots.txt", f"User-agent: *\nSitemap: {B.base}/sitemap.xml\n", "text/plain")
    items = "".join(f"<url><loc>{B.base}/watch/{i}</loc><video:video><video:thumbnail_loc>{B.base}/img/b{i}.jpg</video:thumbnail_loc>"
                    f"<video:title>Other {i}</video:title><video:content_loc>{B.base}/media/b{i}.mp4</video:content_loc></video:video></url>" for i in range(5))
    items += (f"<url><loc>{B.base}/watch/secret-9</loc><video:video><video:thumbnail_loc>{B.base}/img/b_t.jpg</video:thumbnail_loc>"
              f"<video:title>Secret nine</video:title><video:content_loc>{B.base}/media/secret9.mp4</video:content_loc></video:video></url>")
    B.add("/sitemap.xml", f'<?xml version="1.0"?><urlset xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">{items}</urlset>', "application/xml")
    B.add("/dmca", page("<p>Send DMCA notices to <a href='mailto:dmca@siteb.test'>dmca@siteb.test</a></p>"))

    # C: WordPress REST API
    C = new("wordpress")
    C.add("/img/c_t.jpg", copy_crop, "image/jpeg")
    for i in range(4):
        C.add(f"/img/c{i}.jpg", d(i + 6), "image/jpeg")
    C.add("/", page("<p>blog</p>"))
    posts = []
    for i in range(4):
        posts.append({"link": f"{C.base}/p/{i}/", "title": {"rendered": f"Post {i}"}, "content": {"rendered": ""},
                      "_embedded": {"wp:featuredmedia": [{"source_url": f"{C.base}/img/c{i}.jpg"}]}})
    posts.append({"link": f"{C.base}/p/leak/", "title": {"rendered": "Leaked &amp; viral"}, "content": {"rendered": ""},
                  "_embedded": {"wp:featuredmedia": [{"source_url": f"{C.base}/img/c_t.jpg"}]}})
    C.add("/wp-json/wp/v2/posts?per_page=30&page=1&_embed=wp:featuredmedia", json.dumps(posts), "application/json")

    # D: RSS feed only
    D = new("rss")
    D.add("/img/d_t.jpg", jpeg(thumb(__import__("tests.variants", fromlist=["letterbox"]).letterbox(target_img), 320), 80), "image/jpeg")
    for i in range(3):
        D.add(f"/img/d{i}.jpg", d(i + 1), "image/jpeg")
    D.add("/", page("<p>news</p>"))
    feed = "".join(f"<item><title>N{i}</title><link>{D.base}/n/{i}</link><media:thumbnail url=\"{D.base}/img/d{i}.jpg\"/></item>" for i in range(3))
    feed += f"<item><title>Hot</title><link>{D.base}/n/hot</link><media:thumbnail url=\"{D.base}/img/d_t.jpg\"/></item>"
    D.add("/feed/", f'<?xml version="1.0"?><rss xmlns:media="http://search.yahoo.com/mrss/"><channel>{feed}</channel></rss>', "application/xml")

    # E: lazy-load + srcset + JSON-LD
    E = new("lazy")
    E.add("/img/e_t.jpg", copy_small, "image/jpeg")
    for i in range(4):
        E.add(f"/img/e{i}.jpg", d(i + 8), "image/jpeg")
    ld = json.dumps({"@type": "VideoObject", "name": "Lazy video", "thumbnailUrl": f"{E.base}/img/e_t.jpg",
                     "contentUrl": f"{E.base}/media/lazy.mp4", "url": f"{E.base}/v/lazy"})
    E.add("/", page("".join(f'<img src="data:image/gif;base64,R0lGOD" data-src="/img/e{i}.jpg">' for i in range(4)),
                    f'<script type="application/ld+json">{ld}</script>'))

    # F: copy two clicks deep (home -> category -> video page with <img>)
    F = new("deep")
    F.add("/img/f_t.jpg", copy_wm, "image/jpeg")
    F.add("/img/f0.jpg", d(2), "image/jpeg")
    F.add("/", page('<a href="/category/viral-videos">Viral videos</a><a href="/about">about</a>'))
    F.add("/category/viral-videos", page('<a href="/video/55-hidden-clip-title">hidden clip title here</a><img src="/img/f0.jpg">'))
    F.add("/video/55-hidden-clip-title", page('<img src="/img/f_t.jpg"><video src="/media/55.mp4"></video>'))

    # I: related sister site (same network as A): copy sits at the END of a long pagination chain
    I = new("related_deep")
    I.add("/img/i_t.jpg", copy_mirror, "image/jpeg")
    for i in range(6):
        I.add(f"/img/i{i}.jpg", d(i + 4), "image/jpeg")
    I.add("/", page('<a href="/page/2/">next</a><img src="/img/i0.jpg">'))
    for n in range(2, 6):
        nxt = f'<a href="/page/{n + 1}/">next</a>'
        I.add(f"/page/{n}/", page(f'<img src="/img/i{n % 6}.jpg">{nxt}'))
    I.add("/page/6/", page('<a href="/video/42-the-reupload-clip"><img src="/img/i_t.jpg"></a>'))
    I.add("/video/42-the-reupload-clip", page('<video src="/media/42.mp4"></video>'))

    # G: clean site (no copies at all)
    G = new("clean")
    for i in range(6):
        G.add(f"/img/g{i}.jpg", d(i + 5), "image/jpeg")
    G.add("/", page("".join(f'<a href="/v/{i}-video-number-{i}"><img src="/img/g{i}.jpg"></a>' for i in range(6))))

    # H: blocks bots
    H = new("blocked")
    H.add("*", "Forbidden", "text/plain", status=403)
    return sites
