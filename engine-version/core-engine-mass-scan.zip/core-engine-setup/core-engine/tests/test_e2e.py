"""End-to-end test: upload an image, crawl local fake sites, find every hidden copy, no false positives."""
import asyncio, sys, time
sys.path.insert(0, ".")
from PIL import Image

from engine import config
config.ALLOW_PRIVATE = True
config.RDAP_LOOKUP = False
from engine.options import Options
OPTS = Options.make('balanced', site_pages=3, bonus_pages=12, time_budget=90)   # small on purpose: sister site's copy is only reachable in pass 2

from engine.contacts import Contacts
from engine.scan import Scanner
from tests.fakesites import build, TARGET_PATH


async def main():
    target = Image.open(TARGET_PATH).convert("RGB")
    sites = build(target)
    try:
        rows = [{"domain": s.domain, "network": "NetOne" if n in ("paginated", "related_deep") else "", "provider_type": "", "video_provider": ""}
                for n, s in sites.items()]
        rows.append({"domain": "127.0.0.1:9", "network": "", "provider_type": "", "video_provider": ""})   # nothing listens here
        contacts = Contacts()
        contacts.takedown[sites["paginated"].domain] = {"contact_email": "abuse@sitea.test", "removal_page_url": "https://sitea.test/remove",
                                                         "removal_type": "form", "data_quality": "3"}
        sc = Scanner(rows=rows, contacts=contacts)
        t0 = time.time()
        res = await sc.scan(open(TARGET_PATH, "rb").read(), progress=None, options=OPTS)
        print(f"scan finished in {time.time()-t0:.1f}s  candidates={res['stats']['candidates_compared']} requests={res['stats']['requests']}")
        by = {}
        for m in res["matches"]:
            by.setdefault(m["domain"], []).append(m)
        ok = True

        def check(name, cond, detail=""):
            nonlocal ok
            ok &= bool(cond)
            print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))

        for name in ("paginated", "sitemap", "wordpress", "rss", "lazy", "deep", "related_deep"):
            ms = by.get(sites[name].domain, [])
            check(f"found copy on '{name}' site", ms, ", ".join(f"{m['match_type']}/{m['found_via']}/{m['confidence']:.0f}" for m in ms))
        for name in ("clean", "blocked"):
            check(f"no match on '{name}' site", sites[name].domain not in by)
        check("no match on dead site", "127.0.0.1:9" not in by)

        a = by.get(sites["paginated"].domain, [{}])[0]
        check("paginated: page URL is the video page", "/video/777" in (a.get("page_url") or ""), a.get("page_url", ""))
        check("paginated: direct video URL extracted", any(v["url"].endswith("777.mp4") and v["kind"] == "direct" for v in a.get("videos", [])), str(a.get("videos")))
        check("paginated: verified on page via og:image", a.get("verified_on_page") is True)
        check("paginated: title captured", bool(a.get("title")), str(a.get("title")))
        b = by.get(sites["sitemap"].domain, [{}])[0]
        check("sitemap: video URL from sitemap", any("secret9.mp4" in v["url"] for v in b.get("videos", [])), str(b.get("videos")))
        c = by.get(sites["wordpress"].domain, [{}])[0]
        check("wordpress: found via wp API", c.get("found_via") == "wp", c.get("found_via", ""))
        e = by.get(sites["lazy"].domain, [{}])[0]
        check("lazy: video from JSON-LD", any("lazy.mp4" in v["url"] for v in e.get("videos", [])), str(e.get("videos")))
        i = by.get(sites["related_deep"].domain, [{}])[0]
        check("related_deep: only reachable via adaptive pass 2", sites["related_deep"].domain in res["related_domains"], str(res["related_domains"]))

        emails = {n["domain"]: n["to"] for n in res["notices"]}
        check("contact: dataset email used", emails.get(sites["paginated"].domain) == "abuse@sitea.test", str(emails.get(sites["paginated"].domain)))
        check("contact: live scrape found /dmca email", emails.get(sites["sitemap"].domain) == "dmca@siteb.test", str(emails.get(sites["sitemap"].domain)))
        n = next(n for n in res["notices"] if n["domain"] == sites["paginated"].domain)
        check("notice has mailto + URLs", n["mailto"].startswith("mailto:abuse@sitea.test") and "/video/777" in n["body"])

        cov = res["coverage"]["domains"]
        check("coverage: blocked site reported as blocked", cov[sites["blocked"].domain]["status"] == "blocked", cov[sites["blocked"].domain]["status"])
        check("coverage: dead site reported unreachable", cov["127.0.0.1:9"]["status"] == "unreachable", cov["127.0.0.1:9"]["status"])
        check("coverage: clean site checked", cov[sites["clean"].domain]["status"] == "checked")
        print("\nALL PASSED" if ok else "\nSOME CHECKS FAILED")
        return 0 if ok else 1
    finally:
        for s in sites.values():
            s.stop()

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
